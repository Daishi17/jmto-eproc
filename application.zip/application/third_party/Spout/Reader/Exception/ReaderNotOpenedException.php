<?php

namespace Box\Spout\Reader\Exception;

/**
 * Class ReaderNotOpenedException
 */
class ReaderNotOpenedException extends ReaderException
{
}

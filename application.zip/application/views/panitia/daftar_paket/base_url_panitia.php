<!-- GET RUP PAKET FINAL -->
<!-- url_get_rup_finalisasi -->
<input type="hidden" name="url_get_rup_finalisasi" value="<?= base_url('panitia/daftar_paket/daftar_paket/get_rup_terfinalisasi') ?>">

<!-- by rup -->
<input type="hidden" name="url_by_id_rup" value="<?= base_url('panitia/daftar_paket/daftar_paket/by_id_rup/') ?>">

<!-- url_buat_paket_penyedia -->
<input type="hidden" name="url_buat_paket_penyedia" value="<?= base_url('panitia/daftar_paket/daftar_paket/form_daftar_paket/') ?>">
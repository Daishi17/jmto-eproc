<!-- url evaluasi ya -->
<input type="hidden" name="url_byid_mengikuti" value="<?= base_url('panitia/info_tender/informasi_tender/get_byid_mengikuti/') ?>">
<input type="hidden" name="url_simpan_evaluasi_kualifikasi" value="<?= base_url('panitia/info_tender/informasi_tender/simpan_evaluasi_kualifikasi/') ?>">
<input type="hidden" name="url_simpan_evaluasi_penawaran" value="<?= base_url('panitia/info_tender/informasi_tender/simpan_evaluasi_penawaran/') ?>">
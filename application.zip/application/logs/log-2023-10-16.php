<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-16 19:33:30 --> 404 Page Not Found: Informasi_tender/evaluasi
ERROR - 2023-10-16 19:33:38 --> 404 Page Not Found: Informasi_tender/evaluasi
ERROR - 2023-10-16 19:33:48 --> 404 Page Not Found: Informasi_tender/evaluasi
ERROR - 2023-10-16 19:33:51 --> 404 Page Not Found: panitia/Informasi_tender/evaluasi
ERROR - 2023-10-16 19:34:07 --> 404 Page Not Found: panitia/Informasi_tender/info_tender
ERROR - 2023-10-16 19:52:53 --> 404 Page Not Found: panitia/info_tender/Informasi_tender/evaluasi_detail
ERROR - 2023-10-16 19:56:11 --> 404 Page Not Found: panitia/info_tender/Informasi_tender/evaluasi_detail
ERROR - 2023-10-16 21:14:59 --> 404 Page Not Found: panitia/info_tender/Beranda/index
ERROR - 2023-10-16 21:15:44 --> 404 Page Not Found: panitia/info_tender/Beranda/index

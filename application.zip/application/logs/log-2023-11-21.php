<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-21 15:17:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-11-21 15:17:45 --> Unable to connect to the database
ERROR - 2023-11-21 22:18:05 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 182
ERROR - 2023-11-21 22:18:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 999
ERROR - 2023-11-21 22:18:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 952
ERROR - 2023-11-21 22:18:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1230
ERROR - 2023-11-21 22:19:31 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 183
ERROR - 2023-11-21 22:19:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1000
ERROR - 2023-11-21 22:19:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 953
ERROR - 2023-11-21 22:19:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1231
ERROR - 2023-11-21 23:23:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 529
ERROR - 2023-11-21 23:23:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 531
ERROR - 2023-11-21 23:23:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 533
ERROR - 2023-11-21 23:23:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 535
ERROR - 2023-11-21 23:23:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 537
ERROR - 2023-11-21 23:24:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 529
ERROR - 2023-11-21 23:24:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 531
ERROR - 2023-11-21 23:24:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 533
ERROR - 2023-11-21 23:24:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 535
ERROR - 2023-11-21 23:24:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 537
ERROR - 2023-11-21 23:31:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 449
ERROR - 2023-11-21 23:31:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-11-21 23:33:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 449
ERROR - 2023-11-21 23:33:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-11-21 17:22:40 --> 404 Page Not Found: panitia/info_tender/Informasi_tender_terbatas_pra_2_file/informasi_pengadaan
ERROR - 2023-11-21 17:26:10 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-21 17:26:47 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-21 17:31:21 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-21 17:55:43 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-21 17:57:27 --> 404 Page Not Found: panitia/info_tender/Dokumen_cross_tender/index
ERROR - 2023-11-21 17:57:33 --> 404 Page Not Found: panitia/info_tender/Dokumen_cross_tender/index

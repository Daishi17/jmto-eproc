<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-26 22:43:45 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\laragon\www\jmto-eproc\application\libraries\Role_login.php 21

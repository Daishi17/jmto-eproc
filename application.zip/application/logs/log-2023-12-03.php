<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-03 08:08:09 --> 404 Page Not Found: panitia/beranda/Ome/index
ERROR - 2023-12-03 08:08:11 --> 404 Page Not Found: panitia/beranda/Home/index
ERROR - 2023-12-03 08:08:16 --> 404 Page Not Found: panitia/Home/index
ERROR - 2023-12-03 08:09:41 --> 404 Page Not Found: panitia/beranda/Dashboard/index
ERROR - 2023-12-03 08:09:44 --> 404 Page Not Found: panitia/Dashboard/index
ERROR - 2023-12-03 08:10:40 --> 404 Page Not Found: Dashboard/index
ERROR - 2023-12-03 08:12:41 --> 404 Page Not Found: panitia/Dshboard/index
ERROR - 2023-12-03 14:24:09 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 281
ERROR - 2023-12-03 14:24:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1053
ERROR - 2023-12-03 14:24:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1100
ERROR - 2023-12-03 14:24:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1338
ERROR - 2023-12-03 14:35:24 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 281
ERROR - 2023-12-03 14:35:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1343
ERROR - 2023-12-03 14:35:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1105
ERROR - 2023-12-03 14:35:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1058
ERROR - 2023-12-03 14:35:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1343
ERROR - 2023-12-03 14:35:59 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 281
ERROR - 2023-12-03 14:35:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1105
ERROR - 2023-12-03 14:36:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1058
ERROR - 2023-12-03 14:36:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1058
ERROR - 2023-12-03 14:36:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1343
ERROR - 2023-12-03 14:36:08 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 281
ERROR - 2023-12-03 14:36:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1105
ERROR - 2023-12-03 14:36:29 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 281
ERROR - 2023-12-03 14:36:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1058
ERROR - 2023-12-03 14:36:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1105
ERROR - 2023-12-03 14:36:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1343
ERROR - 2023-12-03 08:44:53 --> 404 Page Not Found: File_paket/Paket%20Finalisasi%20E%20Tender
ERROR - 2023-12-03 15:01:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IN(NULL, 0)' at line 4 - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '175'
AND `tbl_rup`.`total_hps_rup` != IN(NULL, 0)
ERROR - 2023-12-03 15:01:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IN(NULL, 0)' at line 4 - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '175'
AND `tbl_rup`.`total_hps_rup` != IN(NULL, 0)
ERROR - 2023-12-03 15:01:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IN(NULL, 0)' at line 4 - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '175'
AND `tbl_rup`.`total_hps_rup` != IN(NULL, 0)
ERROR - 2023-12-03 15:44:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1250
ERROR - 2023-12-03 15:44:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1489
ERROR - 2023-12-03 15:44:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1203
ERROR - 2023-12-03 15:44:10 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 09:47:58 --> 404 Page Not Found: Uth/index
ERROR - 2023-12-03 15:49:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1489
ERROR - 2023-12-03 15:49:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1203
ERROR - 2023-12-03 15:49:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1250
ERROR - 2023-12-03 15:49:35 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 15:50:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1489
ERROR - 2023-12-03 15:50:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1203
ERROR - 2023-12-03 15:50:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1250
ERROR - 2023-12-03 15:50:28 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 15:54:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1489
ERROR - 2023-12-03 15:54:09 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 15:54:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1250
ERROR - 2023-12-03 15:54:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1203
ERROR - 2023-12-03 15:58:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1491
ERROR - 2023-12-03 15:58:18 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 15:58:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1205
ERROR - 2023-12-03 15:58:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1252
ERROR - 2023-12-03 15:59:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1252
ERROR - 2023-12-03 15:59:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1205
ERROR - 2023-12-03 15:59:25 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 15:59:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1491
ERROR - 2023-12-03 16:02:56 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:02:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:02:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:02:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:03:21 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:03:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:03:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:03:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:04:31 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:04:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:04:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:04:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:06:31 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:06:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:06:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:06:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:08:07 --> Severity: Notice --> Undefined variable: row_rup C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\daftar_paket.php 299
ERROR - 2023-12-03 16:08:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\daftar_paket.php 299
ERROR - 2023-12-03 16:08:08 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:08:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:08:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:08:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:11:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:11:14 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:11:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:11:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 10:11:23 --> 404 Page Not Found: panitia/daftar_paket/Undefinedttd_digital_erlanggapdf/index
ERROR - 2023-12-03 10:12:13 --> 404 Page Not Found: panitia/daftar_paket/Undefinedttd_digital_erlanggapdf/index
ERROR - 2023-12-03 16:12:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:12:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:12:17 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:12:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:12:57 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:12:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:12:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:12:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:17:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:17:49 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:17:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:17:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:18:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:18:46 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:21:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:21:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:21:30 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:21:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:22:32 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:22:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:22:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:22:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:23:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:23:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:23:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:23:05 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:24:56 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:24:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:24:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:24:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:26:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:26:24 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:26:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:26:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:26:47 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:26:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:26:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:26:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:27:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:27:47 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:27:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:27:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:28:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 748
ERROR - 2023-12-03 16:28:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 749
ERROR - 2023-12-03 16:28:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 748
ERROR - 2023-12-03 16:28:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 749
ERROR - 2023-12-03 16:28:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 748
ERROR - 2023-12-03 16:28:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 749
ERROR - 2023-12-03 16:28:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 748
ERROR - 2023-12-03 16:28:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 749
ERROR - 2023-12-03 16:28:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:28:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:28:56 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:28:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:30:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:30:12 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:30:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:30:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:30:58 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:30:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:30:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:30:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:32:05 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:32:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:32:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:32:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:33:02 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:33:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:33:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:33:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:33:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:33:30 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:33:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:33:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:45:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 748
ERROR - 2023-12-03 16:45:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 749
ERROR - 2023-12-03 16:45:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 748
ERROR - 2023-12-03 16:45:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 749
ERROR - 2023-12-03 16:45:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 748
ERROR - 2023-12-03 16:45:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 749
ERROR - 2023-12-03 16:45:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 748
ERROR - 2023-12-03 16:45:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 749
ERROR - 2023-12-03 16:46:35 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:46:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:46:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:46:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 17:39:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:39:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:40:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 17:40:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 17:40:42 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 17:40:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 17:40:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:40:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:40:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:40:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:40:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:40:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:40:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:40:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:40:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:40:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:40:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:40:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:40:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:40:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:40:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:40:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:40:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:40:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:40:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:40:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:40:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:40:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:41:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 17:41:42 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 17:41:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 17:41:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 17:41:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:41:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:41:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:41:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:41:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:41:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:41:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:41:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:41:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:41:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:41:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:41:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:41:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:41:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:41:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:41:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:41:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:41:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:41:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:41:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:41:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:41:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:42:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:42:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:42:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:42:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:42:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:42:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:42:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:42:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:42:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:42:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:42:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:42:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:42:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:42:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:42:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:42:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:42:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:42:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:42:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:42:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:42:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:42:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:42:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 17:42:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 17:42:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 17:42:47 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 17:47:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:47:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:47:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:47:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:47:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:47:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:47:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:47:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:47:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:47:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:47:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:47:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:47:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:47:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:47:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:47:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:47:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:47:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:47:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:47:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:47:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:47:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:49:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 17:49:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 17:49:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 17:49:53 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 73
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 74
ERROR - 2023-12-03 17:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 73
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 74
ERROR - 2023-12-03 17:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 73
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 74
ERROR - 2023-12-03 17:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 73
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 74
ERROR - 2023-12-03 17:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 73
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 74
ERROR - 2023-12-03 17:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 73
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 74
ERROR - 2023-12-03 17:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 73
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 74
ERROR - 2023-12-03 17:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 73
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 74
ERROR - 2023-12-03 17:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 73
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 74
ERROR - 2023-12-03 17:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 73
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 74
ERROR - 2023-12-03 17:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 73
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 74
ERROR - 2023-12-03 17:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 73
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 74
ERROR - 2023-12-03 17:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 73
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 74
ERROR - 2023-12-03 17:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 73
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 74
ERROR - 2023-12-03 17:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 73
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 74
ERROR - 2023-12-03 17:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 73
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 74
ERROR - 2023-12-03 17:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 73
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 74
ERROR - 2023-12-03 17:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 73
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 74
ERROR - 2023-12-03 17:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 73
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 74
ERROR - 2023-12-03 17:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 73
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 74
ERROR - 2023-12-03 17:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 73
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 74
ERROR - 2023-12-03 17:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 73
ERROR - 2023-12-03 17:51:43 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 74
ERROR - 2023-12-03 17:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:53:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:53:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:53:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:53:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:53:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:53:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:53:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:53:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:53:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:53:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:53:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:53:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:53:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:53:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:53:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:53:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:53:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:53:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:53:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:53:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:53:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:53:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:55:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:55:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:55:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:55:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:55:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:55:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:55:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:55:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:55:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:55:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:55:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:55:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:55:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:55:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:55:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:55:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:55:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:55:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:55:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:55:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:55:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 17:55:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 92
ERROR - 2023-12-03 18:12:27 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 77
ERROR - 2023-12-03 18:12:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 77
ERROR - 2023-12-03 12:13:15 --> 404 Page Not Found: Ayth/index
ERROR - 2023-12-03 18:18:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 748
ERROR - 2023-12-03 18:18:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 749
ERROR - 2023-12-03 18:19:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 748
ERROR - 2023-12-03 18:19:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 749
ERROR - 2023-12-03 18:19:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 748
ERROR - 2023-12-03 18:19:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 749
ERROR - 2023-12-03 18:19:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 748
ERROR - 2023-12-03 18:19:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 749
ERROR - 2023-12-03 18:19:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 748
ERROR - 2023-12-03 18:19:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 749
ERROR - 2023-12-03 18:19:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 748
ERROR - 2023-12-03 18:19:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 749
ERROR - 2023-12-03 18:19:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 748
ERROR - 2023-12-03 18:19:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 749
ERROR - 2023-12-03 18:19:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 748
ERROR - 2023-12-03 18:19:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 749
ERROR - 2023-12-03 18:19:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1252
ERROR - 2023-12-03 18:19:22 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 283
ERROR - 2023-12-03 18:19:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1205
ERROR - 2023-12-03 18:19:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1491
ERROR - 2023-12-03 18:46:08 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\xampp\htdocs\jmto-eproc\application\libraries\Role_login.php 21
ERROR - 2023-12-03 18:46:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 18:46:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 18:46:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 18:46:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 18:46:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 18:46:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 18:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 18:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 18:48:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 18:48:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 18:48:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 18:48:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 18:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 18:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 18:48:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 18:48:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 18:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 18:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 18:49:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 18:49:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 18:49:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 18:49:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 18:49:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 18:49:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 18:50:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 763
ERROR - 2023-12-03 18:50:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 764
ERROR - 2023-12-03 18:50:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 763
ERROR - 2023-12-03 18:50:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 764
ERROR - 2023-12-03 18:50:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 763
ERROR - 2023-12-03 18:50:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 764
ERROR - 2023-12-03 18:50:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 763
ERROR - 2023-12-03 18:50:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 764
ERROR - 2023-12-03 18:51:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 763
ERROR - 2023-12-03 18:51:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 764
ERROR - 2023-12-03 18:51:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 763
ERROR - 2023-12-03 18:51:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 764
ERROR - 2023-12-03 18:51:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 763
ERROR - 2023-12-03 18:51:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 764
ERROR - 2023-12-03 18:51:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 763
ERROR - 2023-12-03 18:51:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 764
ERROR - 2023-12-03 18:51:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 763
ERROR - 2023-12-03 18:51:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 764
ERROR - 2023-12-03 18:51:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 763
ERROR - 2023-12-03 18:51:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 764
ERROR - 2023-12-03 18:51:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 763
ERROR - 2023-12-03 18:51:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 764
ERROR - 2023-12-03 18:51:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 763
ERROR - 2023-12-03 18:51:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 764
ERROR - 2023-12-03 18:52:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 763
ERROR - 2023-12-03 18:52:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 764
ERROR - 2023-12-03 18:52:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 763
ERROR - 2023-12-03 18:52:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 764
ERROR - 2023-12-03 18:52:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 763
ERROR - 2023-12-03 18:52:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 764
ERROR - 2023-12-03 18:52:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 743
ERROR - 2023-12-03 18:52:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 744
ERROR - 2023-12-03 18:52:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 763
ERROR - 2023-12-03 18:52:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 764
ERROR - 2023-12-03 18:52:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 763
ERROR - 2023-12-03 18:52:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 764
ERROR - 2023-12-03 18:52:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 763
ERROR - 2023-12-03 18:52:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 764
ERROR - 2023-12-03 18:52:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 763
ERROR - 2023-12-03 18:52:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 764
ERROR - 2023-12-03 18:52:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 763
ERROR - 2023-12-03 18:52:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 764
ERROR - 2023-12-03 18:53:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 763
ERROR - 2023-12-03 18:53:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 764
ERROR - 2023-12-03 18:53:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 763
ERROR - 2023-12-03 18:53:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 764
ERROR - 2023-12-03 18:53:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 763
ERROR - 2023-12-03 18:53:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 764
ERROR - 2023-12-03 18:53:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 18:53:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 18:53:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 18:53:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 18:53:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 18:53:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 18:53:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 18:53:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:02:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:02:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:02:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:02:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:02:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:02:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:02:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:02:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:02:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:02:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:03:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:03:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:03:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:03:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:03:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:03:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:03:26 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '175'
ERROR - 2023-12-03 19:03:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:03:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:03:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:03:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:03:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:03:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:03:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:03:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:04:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:04:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:04:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:04:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:04:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:04:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:04:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:04:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:05:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:05:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:05:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:05:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:05:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:05:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:05:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:05:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:08:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:08:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:08:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:08:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:08:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:08:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:09:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:09:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:09:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:09:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:09:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:09:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:09:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:09:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:09:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:09:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:09:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:09:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:09:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:09:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:09:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:09:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:09:41 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_jadwal_rup`
WHERE `id_rup` = '175'
AND `nama_jadwal_rup` = 'Penetapan Pemenang'
ERROR - 2023-12-03 19:09:41 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '175'
AND `tbl_vendor_mengikuti_paket`.`sts_mengikuti_paket` = 1
ORDER BY `tbl_vendor_mengikuti_paket`.`id_rup` DESC
 LIMIT 10
ERROR - 2023-12-03 19:09:41 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_ba_tender`
WHERE `tbl_ba_tender`.`id_rup` = '175'
ERROR - 2023-12-03 19:09:41 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '175'
ERROR - 2023-12-03 19:09:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:09:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:10:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:10:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:10:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:10:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:10:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:10:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:10:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-03 19:10:24 --> Unable to connect to the database
ERROR - 2023-12-03 19:10:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-03 19:10:35 --> Unable to connect to the database
ERROR - 2023-12-03 19:10:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-03 19:10:58 --> Unable to connect to the database
ERROR - 2023-12-03 19:11:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:11:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:11:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:11:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:11:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-03 19:11:11 --> Unable to connect to the database
ERROR - 2023-12-03 19:11:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-03 19:11:14 --> Unable to connect to the database
ERROR - 2023-12-03 19:11:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:11:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:11:39 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_jadwal_rup`
WHERE `id_rup` = '175'
AND `nama_jadwal_rup` = 'Evaluasi Dokumen Kualifikasi'
ERROR - 2023-12-03 19:11:39 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '44ade515201f4753ac430c2f398ae889'
ERROR - 2023-12-03 19:11:39 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '175'
ERROR - 2023-12-03 19:11:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:11:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:11:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:11:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:11:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-03 19:11:52 --> Unable to connect to the database
ERROR - 2023-12-03 19:12:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-03 19:12:02 --> Unable to connect to the database
ERROR - 2023-12-03 19:12:10 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_jadwal_rup`
WHERE `id_rup` = '175'
AND `nama_jadwal_rup` = 'Pembukaan dan Evaluasi Penawaran File I : Administrasi dan Teknis'
ERROR - 2023-12-03 19:12:10 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '175'
ERROR - 2023-12-03 19:12:10 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '175'
AND `tbl_vendor_mengikuti_paket`.`sts_mengikuti_paket` = 1
ORDER BY `tbl_vendor_mengikuti_paket`.`id_rup` DESC
 LIMIT 10
ERROR - 2023-12-03 19:12:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-03 19:12:32 --> Unable to connect to the database
ERROR - 2023-12-03 19:12:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:12:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:12:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:12:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:12:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:12:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:12:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-03 19:12:48 --> Unable to connect to the database
ERROR - 2023-12-03 19:12:59 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '44ade515201f4753ac430c2f398ae889'
ERROR - 2023-12-03 19:13:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:13:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:13:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:13:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:13:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:13:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:13:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:13:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:14:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:14:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:14:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-03 19:14:15 --> Unable to connect to the database
ERROR - 2023-12-03 19:14:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:14:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:14:40 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_jadwal_rup`
WHERE `id_rup` = '175'
AND `nama_jadwal_rup` = 'Download Dokumen Pengadaan'
ERROR - 2023-12-03 19:14:40 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_ba_tender`
WHERE `tbl_ba_tender`.`id_rup` = '175'
ERROR - 2023-12-03 19:14:40 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '44ade515201f4753ac430c2f398ae889'
ERROR - 2023-12-03 19:14:40 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '175'
AND `tbl_vendor_mengikuti_paket`.`sts_mengikuti_paket` = 1
ORDER BY `tbl_vendor_mengikuti_paket`.`id_rup` DESC
 LIMIT 10
ERROR - 2023-12-03 19:14:40 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '175'
ERROR - 2023-12-03 19:14:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-03 19:14:50 --> Unable to connect to the database
ERROR - 2023-12-03 19:14:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:14:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:14:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:14:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:15:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:15:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:15:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:15:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:15:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-03 19:15:25 --> Unable to connect to the database
ERROR - 2023-12-03 19:17:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:17:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:17:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:17:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:17:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:17:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:17:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:17:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:18:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-03 19:18:25 --> Unable to connect to the database
ERROR - 2023-12-03 19:18:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-03 19:18:36 --> Unable to connect to the database
ERROR - 2023-12-03 19:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:18:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-03 19:18:55 --> Unable to connect to the database
ERROR - 2023-12-03 19:19:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-03 19:19:05 --> Unable to connect to the database
ERROR - 2023-12-03 19:19:06 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '175'
AND `tbl_vendor_mengikuti_paket`.`sts_mengikuti_paket` = 1
ERROR - 2023-12-03 19:19:06 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '44ade515201f4753ac430c2f398ae889'
ERROR - 2023-12-03 19:19:06 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '175'
AND `tbl_vendor_mengikuti_paket`.`sts_mengikuti_paket` = 1
ORDER BY `tbl_vendor_mengikuti_paket`.`id_rup` DESC
 LIMIT 10
ERROR - 2023-12-03 19:19:07 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '44ade515201f4753ac430c2f398ae889'
ERROR - 2023-12-03 19:19:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:19:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:19:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:19:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:19:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-03 19:19:52 --> Unable to connect to the database
ERROR - 2023-12-03 19:20:04 --> Query error: MySQL server has gone away - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `sts_aanwijzing_penawaran` = 1
WHERE `id_vendor` = '119'
AND `id_rup` = '175'
ERROR - 2023-12-03 19:20:04 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '44ade515201f4753ac430c2f398ae889'
ERROR - 2023-12-03 19:20:04 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '44ade515201f4753ac430c2f398ae889'
ERROR - 2023-12-03 19:20:04 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '175'
ERROR - 2023-12-03 19:20:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-03 19:20:19 --> Unable to connect to the database
ERROR - 2023-12-03 19:20:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:20:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:20:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:20:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:20:48 --> Query error: MySQL server has gone away - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `sts_aanwijzing_penawaran` = 1
WHERE `id_vendor` = '119'
AND `id_rup` = '175'
ERROR - 2023-12-03 19:20:48 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '44ade515201f4753ac430c2f398ae889'
ERROR - 2023-12-03 19:20:48 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_ba_tender`
WHERE `tbl_ba_tender`.`id_rup` = '175'
ERROR - 2023-12-03 19:20:48 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '44ade515201f4753ac430c2f398ae889'
ERROR - 2023-12-03 19:20:48 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '175'
ERROR - 2023-12-03 19:21:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-03 19:21:39 --> Unable to connect to the database
ERROR - 2023-12-03 19:31:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:31:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:31:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:31:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:31:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:31:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:32:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:32:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:32:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-03 19:32:29 --> Unable to connect to the database
ERROR - 2023-12-03 13:33:11 --> 404 Page Not Found: Assets/img
ERROR - 2023-12-03 19:33:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-03 19:33:12 --> Unable to connect to the database
ERROR - 2023-12-03 19:33:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-03 19:33:39 --> Unable to connect to the database
ERROR - 2023-12-03 19:33:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-03 19:33:44 --> Unable to connect to the database
ERROR - 2023-12-03 19:34:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-03 19:34:06 --> Unable to connect to the database
ERROR - 2023-12-03 19:34:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-03 19:34:25 --> Unable to connect to the database
ERROR - 2023-12-03 19:34:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-03 19:34:55 --> Unable to connect to the database
ERROR - 2023-12-03 13:34:56 --> 404 Page Not Found: Assets/img
ERROR - 2023-12-03 19:35:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-03 19:35:12 --> Unable to connect to the database
ERROR - 2023-12-03 19:35:16 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan_penawaran`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan_penawaran`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '175'
ERROR - 2023-12-03 19:35:16 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan_penawaran`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan_penawaran`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '175'
ERROR - 2023-12-03 19:35:16 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan_penawaran`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan_penawaran`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '175'
ERROR - 2023-12-03 19:35:16 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan_penawaran`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan_penawaran`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '175'
ERROR - 2023-12-03 19:35:16 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan_penawaran`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan_penawaran`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '175'
ERROR - 2023-12-03 13:35:21 --> 404 Page Not Found: Assets/img
ERROR - 2023-12-03 19:35:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:35:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:35:52 --> Query error: MySQL server has gone away - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `sts_aanwijzing_penawaran` = 1
WHERE `id_vendor` = '119'
AND `id_rup` = '175'
ERROR - 2023-12-03 19:35:52 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan_penawaran`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan_penawaran`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '175'
ERROR - 2023-12-03 19:35:52 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan_penawaran`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan_penawaran`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '175'
ERROR - 2023-12-03 19:35:52 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan_penawaran`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan_penawaran`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '175'
ERROR - 2023-12-03 19:35:52 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan_penawaran`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan_penawaran`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '175'
ERROR - 2023-12-03 19:36:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:36:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:36:23 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '44ade515201f4753ac430c2f398ae889'
ERROR - 2023-12-03 19:36:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:36:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:36:47 --> Query error: MySQL server has gone away - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `sts_aanwijzing_penawaran` = 1
WHERE `id_vendor` = '119'
AND `id_rup` = '175'
ERROR - 2023-12-03 19:36:47 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '44ade515201f4753ac430c2f398ae889'
ERROR - 2023-12-03 19:36:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:36:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:36:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:36:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:36:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:36:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:37:12 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '44ade515201f4753ac430c2f398ae889'
ERROR - 2023-12-03 19:37:12 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_ba_tender`
WHERE `tbl_ba_tender`.`id_rup` = '175'
ERROR - 2023-12-03 19:37:12 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '175'
AND `tbl_vendor_mengikuti_paket`.`sts_mengikuti_paket` = 1
ORDER BY `tbl_vendor_mengikuti_paket`.`id_rup` DESC
 LIMIT 10
ERROR - 2023-12-03 19:38:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:38:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:38:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:38:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:38:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:38:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:38:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:38:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:39:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:39:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:40:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:40:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:40:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:40:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:40:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:40:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:47:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 608
ERROR - 2023-12-03 19:47:16 --> Severity: Warning --> Division by zero C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 650
ERROR - 2023-12-03 19:47:17 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `nilai_penawaran` = '0', `ev_penawaran_teknis` = '80', `ev_penawaran_hps` = '0', `ev_penawaran_biaya` = NAN
WHERE `id_vendor_mengikuti_paket` = '50'
ERROR - 2023-12-03 19:51:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:51:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:51:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:51:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:51:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:51:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:51:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:51:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:54:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 608
ERROR - 2023-12-03 19:54:26 --> Severity: Warning --> Division by zero C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 650
ERROR - 2023-12-03 19:54:26 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `nilai_penawaran` = '0', `ev_penawaran_teknis` = '70', `ev_penawaran_hps` = '0', `ev_penawaran_biaya` = NAN
WHERE `id_vendor_mengikuti_paket` = '50'
ERROR - 2023-12-03 19:58:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:58:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:58:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:58:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:58:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:58:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 19:58:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 19:58:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 20:00:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 20:00:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 20:00:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 20:00:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 20:00:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 20:00:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 20:00:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 20:00:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 20:05:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 20:05:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 20:05:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 20:05:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 20:05:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 20:05:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 20:05:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 20:05:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 20:05:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 20:05:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 20:05:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 20:05:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 20:06:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 20:06:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 20:06:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 761
ERROR - 2023-12-03 20:06:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 762
ERROR - 2023-12-03 20:19:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1252
ERROR - 2023-12-03 20:19:01 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 283
ERROR - 2023-12-03 20:19:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 20:19:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1205
ERROR - 2023-12-03 20:21:44 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 283
ERROR - 2023-12-03 20:21:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1205
ERROR - 2023-12-03 20:21:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1252
ERROR - 2023-12-03 20:21:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 15:59:10 --> 404 Page Not Found: Rekanan_terundang/get_datatable_pengajuan_perubahan_dokumen
ERROR - 2023-12-03 22:41:39 --> Query error: MySQL server has gone away - Invalid query: SELECT `sts_validasi`
FROM `tbl_vendor_pemilik`
WHERE `sts_validasi` IN(0, 2, 3)
AND `id_vendor` = '130'
 LIMIT 1

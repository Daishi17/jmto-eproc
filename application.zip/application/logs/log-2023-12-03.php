<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-03 08:08:09 --> 404 Page Not Found: panitia/beranda/Ome/index
ERROR - 2023-12-03 08:08:11 --> 404 Page Not Found: panitia/beranda/Home/index
ERROR - 2023-12-03 08:08:16 --> 404 Page Not Found: panitia/Home/index
ERROR - 2023-12-03 08:09:41 --> 404 Page Not Found: panitia/beranda/Dashboard/index
ERROR - 2023-12-03 08:09:44 --> 404 Page Not Found: panitia/Dashboard/index
ERROR - 2023-12-03 08:10:40 --> 404 Page Not Found: Dashboard/index
ERROR - 2023-12-03 08:12:41 --> 404 Page Not Found: panitia/Dshboard/index
ERROR - 2023-12-03 14:24:09 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 281
ERROR - 2023-12-03 14:24:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1053
ERROR - 2023-12-03 14:24:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1100
ERROR - 2023-12-03 14:24:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1338
ERROR - 2023-12-03 14:35:24 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 281
ERROR - 2023-12-03 14:35:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1343
ERROR - 2023-12-03 14:35:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1105
ERROR - 2023-12-03 14:35:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1058
ERROR - 2023-12-03 14:35:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1343
ERROR - 2023-12-03 14:35:59 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 281
ERROR - 2023-12-03 14:35:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1105
ERROR - 2023-12-03 14:36:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1058
ERROR - 2023-12-03 14:36:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1058
ERROR - 2023-12-03 14:36:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1343
ERROR - 2023-12-03 14:36:08 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 281
ERROR - 2023-12-03 14:36:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1105
ERROR - 2023-12-03 14:36:29 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 281
ERROR - 2023-12-03 14:36:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1058
ERROR - 2023-12-03 14:36:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1105
ERROR - 2023-12-03 14:36:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1343
ERROR - 2023-12-03 08:44:53 --> 404 Page Not Found: File_paket/Paket%20Finalisasi%20E%20Tender
ERROR - 2023-12-03 15:01:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IN(NULL, 0)' at line 4 - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '175'
AND `tbl_rup`.`total_hps_rup` != IN(NULL, 0)
ERROR - 2023-12-03 15:01:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IN(NULL, 0)' at line 4 - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '175'
AND `tbl_rup`.`total_hps_rup` != IN(NULL, 0)
ERROR - 2023-12-03 15:01:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IN(NULL, 0)' at line 4 - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '175'
AND `tbl_rup`.`total_hps_rup` != IN(NULL, 0)
ERROR - 2023-12-03 15:44:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1250
ERROR - 2023-12-03 15:44:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1489
ERROR - 2023-12-03 15:44:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1203
ERROR - 2023-12-03 15:44:10 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 09:47:58 --> 404 Page Not Found: Uth/index
ERROR - 2023-12-03 15:49:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1489
ERROR - 2023-12-03 15:49:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1203
ERROR - 2023-12-03 15:49:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1250
ERROR - 2023-12-03 15:49:35 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 15:50:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1489
ERROR - 2023-12-03 15:50:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1203
ERROR - 2023-12-03 15:50:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1250
ERROR - 2023-12-03 15:50:28 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 15:54:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1489
ERROR - 2023-12-03 15:54:09 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 15:54:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1250
ERROR - 2023-12-03 15:54:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1203
ERROR - 2023-12-03 15:58:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1491
ERROR - 2023-12-03 15:58:18 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 15:58:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1205
ERROR - 2023-12-03 15:58:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1252
ERROR - 2023-12-03 15:59:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1252
ERROR - 2023-12-03 15:59:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1205
ERROR - 2023-12-03 15:59:25 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 15:59:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1491
ERROR - 2023-12-03 16:02:56 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:02:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:02:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:02:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:03:21 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:03:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:03:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:03:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:04:31 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:04:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:04:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:04:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:06:31 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:06:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:06:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:06:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:08:07 --> Severity: Notice --> Undefined variable: row_rup C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\daftar_paket.php 299
ERROR - 2023-12-03 16:08:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\daftar_paket\daftar_paket.php 299
ERROR - 2023-12-03 16:08:08 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:08:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:08:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:08:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:11:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:11:14 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:11:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:11:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 10:11:23 --> 404 Page Not Found: panitia/daftar_paket/Undefinedttd_digital_erlanggapdf/index
ERROR - 2023-12-03 10:12:13 --> 404 Page Not Found: panitia/daftar_paket/Undefinedttd_digital_erlanggapdf/index
ERROR - 2023-12-03 16:12:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251
ERROR - 2023-12-03 16:12:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:12:17 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:12:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:12:57 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 282
ERROR - 2023-12-03 16:12:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-03 16:12:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1204
ERROR - 2023-12-03 16:12:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1251

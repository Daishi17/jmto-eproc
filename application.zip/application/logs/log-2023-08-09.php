<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-09 12:00:53 --> Severity: error --> Exception: Call to undefined method M_Rekanan_tervalidasi::get_row_lainnya() C:\laragon\www\jmto-eproc\application\controllers\validator\Rekanan_tervalidasi.php 313
ERROR - 2023-08-09 12:01:01 --> Severity: error --> Exception: Call to undefined method M_Rekanan_tervalidasi::get_row_lainnya() C:\laragon\www\jmto-eproc\application\controllers\validator\Rekanan_tervalidasi.php 313
ERROR - 2023-08-09 12:07:13 --> 404 Page Not Found: validator/Rekanan_tervalidasi/encryption_skdp
ERROR - 2023-08-09 12:15:09 --> Severity: error --> Exception: Call to undefined method M_Rekanan_tervalidasi::get_row_izin_lain() C:\laragon\www\jmto-eproc\application\controllers\validator\Rekanan_tervalidasi.php 313
ERROR - 2023-08-09 12:15:27 --> Severity: error --> Exception: Call to undefined method M_Rekanan_tervalidasi::get_row_izin_lain() C:\laragon\www\jmto-eproc\application\controllers\validator\Rekanan_tervalidasi.php 313
ERROR - 2023-08-09 12:16:21 --> Severity: error --> Exception: Call to undefined method M_Rekanan_tervalidasi::get_row_izin_lain() C:\laragon\www\jmto-eproc\application\controllers\validator\Rekanan_tervalidasi.php 313
ERROR - 2023-08-09 12:16:29 --> Severity: error --> Exception: Call to undefined method M_Rekanan_tervalidasi::get_row_izin_lain() C:\laragon\www\jmto-eproc\application\controllers\validator\Rekanan_tervalidasi.php 313
ERROR - 2023-08-09 05:23:12 --> 404 Page Not Found: Images/bg
ERROR - 2023-08-09 05:27:01 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-09 12:30:08 --> Severity: Notice --> Undefined property: Fm_jenis_pengadaan::$M_unit_kerja C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_pengadaan.php 14
ERROR - 2023-08-09 12:30:08 --> Severity: error --> Exception: Call to a member function kode() on null C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_pengadaan.php 14
ERROR - 2023-08-09 12:33:25 --> Severity: Notice --> Undefined variable: kode_jenis_pengadaan C:\laragon\www\jmto-eproc\application\views\administrator\file_master\fm_jenis_pengadaan.php 151
ERROR - 2023-08-09 05:38:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-09 05:38:16 --> Unable to connect to the database
ERROR - 2023-08-09 12:44:37 --> Query error: Unknown column 'user_edited' in 'field list' - Invalid query: UPDATE `tbl_jenis_pengadaan` SET `sts_aktif` = 2, `user_edited` = 'Administrator', `time_edited` = '2023-08-09 12:44'
WHERE `id_jenis_pengadaan` = '001'
ERROR - 2023-08-09 12:44:41 --> Query error: Unknown column 'user_edited' in 'field list' - Invalid query: UPDATE `tbl_jenis_pengadaan` SET `sts_aktif` = 2, `user_edited` = 'Administrator', `time_edited` = '2023-08-09 12:44'
WHERE `id_jenis_pengadaan` IS NULL
ERROR - 2023-08-09 12:45:02 --> Query error: Unknown column 'time_edited' in 'field list' - Invalid query: UPDATE `tbl_jenis_pengadaan` SET `sts_aktif` = 2, `user_edited` = 'Administrator', `time_edited` = '2023-08-09 12:45'
WHERE `id_jenis_pengadaan` = '001'
ERROR - 2023-08-09 12:45:06 --> Query error: Unknown column 'time_edited' in 'field list' - Invalid query: UPDATE `tbl_jenis_pengadaan` SET `sts_aktif` = 2, `user_edited` = 'Administrator', `time_edited` = '2023-08-09 12:45'
WHERE `id_jenis_pengadaan` IS NULL
ERROR - 2023-08-09 14:33:13 --> Severity: Notice --> Undefined variable: kode_jns_pengadaan C:\laragon\www\jmto-eproc\application\views\administrator\file_master\fm_metode_pengadaan.php 192
ERROR - 2023-08-09 07:41:11 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=12724 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-09 07:41:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-09 07:41:11 --> Unable to connect to the database
ERROR - 2023-08-09 08:06:47 --> 404 Page Not Found: Images/bg
ERROR - 2023-08-09 08:11:57 --> 404 Page Not Found: Images/bg
ERROR - 2023-08-09 09:07:57 --> 404 Page Not Found: Images/bg
ERROR - 2023-08-09 17:25:09 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=12724 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-09 17:25:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-09 17:25:09 --> Unable to connect to the database
ERROR - 2023-08-09 17:25:11 --> Unable to connect to the database
ERROR - 2023-08-09 10:37:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-09 10:37:46 --> Unable to connect to the database
ERROR - 2023-08-09 10:37:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-09 10:37:56 --> Unable to connect to the database
ERROR - 2023-08-09 10:37:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-09 10:37:58 --> Unable to connect to the database
ERROR - 2023-08-09 10:38:56 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=12724 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-09 10:38:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-09 10:38:56 --> Unable to connect to the database
ERROR - 2023-08-09 11:37:50 --> 404 Page Not Found: Images/bg
ERROR - 2023-08-09 12:39:30 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=12724 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-09 12:39:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-09 12:39:30 --> Unable to connect to the database
ERROR - 2023-08-09 12:39:50 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=12724 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-09 12:39:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-09 12:39:50 --> Unable to connect to the database
ERROR - 2023-08-09 12:40:26 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=12724 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-09 12:40:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-09 12:40:26 --> Unable to connect to the database
ERROR - 2023-08-09 23:45:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '= '6'' at line 6 - Invalid query: SELECT *
FROM `tbl_panitia`
LEFT JOIN `tbl_manajemen_user` ON `tbl_manajemen_user`.`id_manajemen_user` = `tbl_panitia`.`id_manajemen_user`
LEFT JOIN `tbl_pegawai` ON `tbl_pegawai`.`id_pegawai` = `tbl_manajemen_user`.`id_pegawai`
WHERE `tbl_panitia`.`id_rup` = '19'
AND `tbl_pegawai`. = '6'
ERROR - 2023-08-09 23:45:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '= '6'' at line 6 - Invalid query: SELECT *
FROM `tbl_panitia`
LEFT JOIN `tbl_manajemen_user` ON `tbl_manajemen_user`.`id_manajemen_user` = `tbl_panitia`.`id_manajemen_user`
LEFT JOIN `tbl_pegawai` ON `tbl_pegawai`.`id_pegawai` = `tbl_manajemen_user`.`id_pegawai`
WHERE `tbl_panitia`.`id_rup` = '19'
AND `tbl_pegawai`. = '6'
ERROR - 2023-08-09 23:45:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '= '6'' at line 6 - Invalid query: SELECT *
FROM `tbl_panitia`
LEFT JOIN `tbl_manajemen_user` ON `tbl_manajemen_user`.`id_manajemen_user` = `tbl_panitia`.`id_manajemen_user`
LEFT JOIN `tbl_pegawai` ON `tbl_pegawai`.`id_pegawai` = `tbl_manajemen_user`.`id_pegawai`
WHERE `tbl_panitia`.`id_rup` = '19'
AND `tbl_pegawai`. = '6'
ERROR - 2023-08-09 18:27:39 --> 404 Page Not Found: Images/bg
ERROR - 2023-08-09 18:50:12 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=16976 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-09 18:50:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-09 18:50:12 --> Unable to connect to the database
ERROR - 2023-08-09 18:50:19 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=16976 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-09 18:50:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-09 18:50:19 --> Unable to connect to the database
ERROR - 2023-08-09 18:50:36 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=16976 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-09 18:50:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-09 18:50:36 --> Unable to connect to the database
ERROR - 2023-08-09 18:50:57 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=16976 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-09 18:50:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-09 18:50:57 --> Unable to connect to the database

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-07 00:03:09 --> Severity: Warning --> Illegal string offset 'kode' C:\laragon\www\jmto-eproc\application\views\administrator\file_master\fm_mjm_user.php 161
ERROR - 2023-08-07 00:19:34 --> Severity: error --> Exception: Too few arguments to function Fm_mjm_user::get_bynip(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 23
ERROR - 2023-08-07 00:24:31 --> Severity: error --> Exception: Too few arguments to function Fm_mjm_user::get_bynip(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 23
ERROR - 2023-08-07 00:24:34 --> Severity: error --> Exception: Too few arguments to function Fm_mjm_user::get_bynip(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 23
ERROR - 2023-08-07 00:24:56 --> Severity: error --> Exception: Too few arguments to function Fm_mjm_user::get_bynip(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 23
ERROR - 2023-08-07 00:36:54 --> Severity: error --> Exception: Too few arguments to function Fm_mjm_user::get_byid(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 23
ERROR - 2023-08-07 01:06:14 --> Severity: Notice --> Undefined property: Fm_mjm_user::$M_unit_area C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 66
ERROR - 2023-08-07 01:06:14 --> Severity: error --> Exception: Call to a member function kode() on null C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 66
ERROR - 2023-08-07 01:06:30 --> Severity: Notice --> Undefined property: stdClass::$kode_section C:\laragon\www\jmto-eproc\application\models\M_master\M_mjm_user.php 25
ERROR - 2023-08-07 01:07:01 --> Severity: Notice --> Undefined property: stdClass::$kode_mjm_user C:\laragon\www\jmto-eproc\application\models\M_master\M_mjm_user.php 25
ERROR - 2023-08-07 01:07:19 --> Severity: Notice --> Undefined property: stdClass::$kode_mjm_user C:\laragon\www\jmto-eproc\application\models\M_master\M_mjm_user.php 25
ERROR - 2023-08-07 01:29:35 --> Severity: Notice --> Undefined index: role C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 74
ERROR - 2023-08-07 01:29:36 --> Severity: Notice --> Undefined variable: response C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 94
ERROR - 2023-08-07 01:33:48 --> Severity: Notice --> Undefined index: role C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 74
ERROR - 2023-08-07 01:45:11 --> Severity: Notice --> Undefined variable: output C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 68
ERROR - 2023-08-07 01:48:53 --> Severity: Notice --> Undefined index: role C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 90
ERROR - 2023-08-07 01:53:16 --> Severity: Notice --> Undefined index: nama_pegawai C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 94
ERROR - 2023-08-07 01:54:01 --> Severity: Notice --> Undefined index: nama_pegawai C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 94
ERROR - 2023-08-07 01:54:08 --> Severity: Notice --> Undefined index: nama_pegawai C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 94
ERROR - 2023-08-07 01:54:52 --> Query error: Column 'id_pegawai' in where clause is ambiguous - Invalid query: SELECT *
FROM `tbl_manajemen_user`
LEFT JOIN `tbl_pegawai` ON `tbl_pegawai`.`id_pegawai` = `tbl_manajemen_user`.`id_pegawai`
WHERE `id_pegawai` = '5 '
ERROR - 2023-08-07 02:03:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 88
ERROR - 2023-08-07 02:03:08 --> Severity: Notice --> Undefined variable: response C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 109
ERROR - 2023-08-07 02:03:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 88
ERROR - 2023-08-07 02:03:35 --> Severity: Notice --> Undefined variable: response C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 109
ERROR - 2023-08-07 02:03:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 88
ERROR - 2023-08-07 02:03:53 --> Severity: Notice --> Undefined variable: response C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 109
ERROR - 2023-08-07 02:19:41 --> Severity: Notice --> Undefined property: stdClass::$nama_departemen C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 46
ERROR - 2023-08-07 02:19:41 --> Severity: Notice --> Undefined property: stdClass::$nama_section C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 47
ERROR - 2023-08-07 02:19:41 --> Severity: Notice --> Undefined property: stdClass::$nama_departemen C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 46
ERROR - 2023-08-07 02:19:41 --> Severity: Notice --> Undefined property: stdClass::$nama_section C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 47
ERROR - 2023-08-07 02:19:41 --> Severity: Notice --> Undefined property: stdClass::$nama_departemen C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 46
ERROR - 2023-08-07 02:19:41 --> Severity: Notice --> Undefined property: stdClass::$nama_section C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 47
ERROR - 2023-08-07 02:19:41 --> Severity: Notice --> Undefined property: stdClass::$nama_departemen C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 46
ERROR - 2023-08-07 02:19:41 --> Severity: Notice --> Undefined property: stdClass::$nama_section C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 47
ERROR - 2023-08-07 02:19:45 --> Severity: Notice --> Undefined property: stdClass::$nama_departemen C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 46
ERROR - 2023-08-07 02:19:45 --> Severity: Notice --> Undefined property: stdClass::$nama_section C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 47
ERROR - 2023-08-07 02:19:45 --> Severity: Notice --> Undefined property: stdClass::$nama_departemen C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 46
ERROR - 2023-08-07 02:19:45 --> Severity: Notice --> Undefined property: stdClass::$nama_section C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 47
ERROR - 2023-08-07 02:19:45 --> Severity: Notice --> Undefined property: stdClass::$nama_departemen C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 46
ERROR - 2023-08-07 02:19:45 --> Severity: Notice --> Undefined property: stdClass::$nama_section C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 47
ERROR - 2023-08-07 02:19:45 --> Severity: Notice --> Undefined property: stdClass::$nama_departemen C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 46
ERROR - 2023-08-07 02:19:45 --> Severity: Notice --> Undefined property: stdClass::$nama_section C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 47
ERROR - 2023-08-07 02:40:46 --> Severity: error --> Exception: Too few arguments to function Fm_mjm_user::get_byid(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 99
ERROR - 2023-08-07 02:40:49 --> Severity: error --> Exception: Too few arguments to function Fm_mjm_user::get_byid(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 99
ERROR - 2023-08-07 02:41:03 --> Severity: error --> Exception: Too few arguments to function Fm_mjm_user::get_byid(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 99
ERROR - 2023-08-07 02:42:55 --> Severity: error --> Exception: Too few arguments to function Fm_mjm_user::get_byid(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 99
ERROR - 2023-08-07 02:43:05 --> Severity: error --> Exception: Too few arguments to function Fm_mjm_user::get_byid(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 99

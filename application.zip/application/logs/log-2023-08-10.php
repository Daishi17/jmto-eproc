<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-10 01:54:19 --> Severity: error --> Exception: Call to undefined method M_rup::count_all_rup_paket() C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_buat_paket.php 51
ERROR - 2023-08-10 01:54:23 --> Severity: error --> Exception: Call to undefined method M_rup::count_all_rup_paket() C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_buat_paket.php 51
ERROR - 2023-08-10 01:54:30 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 85
ERROR - 2023-08-10 01:54:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 85
ERROR - 2023-08-10 01:54:30 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 85
ERROR - 2023-08-10 01:54:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 85
ERROR - 2023-08-10 01:54:30 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 85
ERROR - 2023-08-10 01:54:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 85
ERROR - 2023-08-10 01:54:30 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 85
ERROR - 2023-08-10 01:54:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 85
ERROR - 2023-08-10 01:54:30 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 85
ERROR - 2023-08-10 01:54:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 85
ERROR - 2023-08-10 01:54:30 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 85
ERROR - 2023-08-10 01:54:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 85
ERROR - 2023-08-10 01:54:30 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 85
ERROR - 2023-08-10 01:54:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 85
ERROR - 2023-08-10 01:54:30 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 85
ERROR - 2023-08-10 01:54:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 85
ERROR - 2023-08-10 01:54:30 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 85
ERROR - 2023-08-10 01:54:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 85
ERROR - 2023-08-10 01:54:30 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 114
ERROR - 2023-08-10 01:54:30 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 115
ERROR - 2023-08-10 01:54:30 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 115
ERROR - 2023-08-10 01:54:30 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_buat_paket.php 35
ERROR - 2023-08-10 01:54:30 --> Severity: Notice --> Undefined index: draw C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_buat_paket.php 50
ERROR - 2023-08-10 01:54:30 --> Severity: error --> Exception: Call to undefined method M_rup::count_all_rup_paket() C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_buat_paket.php 51
ERROR - 2023-08-10 01:54:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 128
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 129
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 129
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_buat_paket.php 35
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Undefined index: draw C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_buat_paket.php 50
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99
ERROR - 2023-08-10 01:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rup\M_rup.php 99

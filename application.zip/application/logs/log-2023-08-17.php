<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-17 16:51:58 --> Severity: Warning --> mysqli::query(): (HY000/2006): MySQL server has gone away C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 315
ERROR - 2023-08-17 16:51:58 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_sbu`
ORDER BY `tbl_sbu`.`id_sbu` ASC
ERROR - 2023-08-17 16:53:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-17 16:53:56 --> Unable to connect to the database
ERROR - 2023-08-17 17:28:18 --> Severity: Notice --> Undefined property: Fm_unit_area::$M_unit_kerja C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_area.php 45
ERROR - 2023-08-17 17:28:18 --> Severity: error --> Exception: Call to a member function update_data() on null C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_area.php 45
ERROR - 2023-08-17 17:35:48 --> Severity: Notice --> Undefined property: stdClass::$nama_departeen C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_area.php 128
ERROR - 2023-08-17 17:35:48 --> Severity: Notice --> Undefined property: stdClass::$nama_departeen C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_area.php 128
ERROR - 2023-08-17 17:35:48 --> Severity: Notice --> Undefined property: stdClass::$nama_departeen C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_area.php 128
ERROR - 2023-08-17 17:35:48 --> Severity: Notice --> Undefined property: stdClass::$nama_departeen C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_area.php 128
ERROR - 2023-08-17 17:35:48 --> Severity: Notice --> Undefined property: stdClass::$nama_departeen C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_area.php 128
ERROR - 2023-08-17 17:35:48 --> Severity: Notice --> Undefined property: stdClass::$nama_departeen C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_area.php 128
ERROR - 2023-08-17 17:35:48 --> Severity: Notice --> Undefined property: stdClass::$nama_departeen C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_area.php 128
ERROR - 2023-08-17 17:35:48 --> Severity: Notice --> Undefined property: stdClass::$nama_departeen C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_area.php 128
ERROR - 2023-08-17 17:35:48 --> Severity: Notice --> Undefined property: stdClass::$nama_departeen C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_area.php 128
ERROR - 2023-08-17 17:35:48 --> Severity: Notice --> Undefined property: stdClass::$nama_departeen C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_area.php 128
ERROR - 2023-08-17 17:37:02 --> Query error: SELECT command denied to user 'u1064384_eprocjmto'@'180.252.160.148' for table `tbl_section`.`sts_aktif` - Invalid query: SELECT *
FROM (`id_section`, `kode_section`, `nama_departemen`, `tbl_section`.`sts_aktif`)
LEFT JOIN `tbl_departemen` ON `tbl_section`.`id_departemen` = `tbl_departemen`.`id_departemen`
ORDER BY `kode_section` ASC
 LIMIT 10
ERROR - 2023-08-17 17:37:42 --> Severity: Notice --> Undefined property: stdClass::$nama_section C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_area.php 127
ERROR - 2023-08-17 17:37:42 --> Severity: Notice --> Undefined property: stdClass::$nama_section C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_area.php 127
ERROR - 2023-08-17 17:37:42 --> Severity: Notice --> Undefined property: stdClass::$nama_section C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_area.php 127
ERROR - 2023-08-17 17:37:42 --> Severity: Notice --> Undefined property: stdClass::$nama_section C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_area.php 127
ERROR - 2023-08-17 17:37:42 --> Severity: Notice --> Undefined property: stdClass::$nama_section C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_area.php 127
ERROR - 2023-08-17 17:37:42 --> Severity: Notice --> Undefined property: stdClass::$nama_section C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_area.php 127
ERROR - 2023-08-17 17:37:42 --> Severity: Notice --> Undefined property: stdClass::$nama_section C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_area.php 127
ERROR - 2023-08-17 17:37:42 --> Severity: Notice --> Undefined property: stdClass::$nama_section C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_area.php 127
ERROR - 2023-08-17 17:37:42 --> Severity: Notice --> Undefined property: stdClass::$nama_section C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_area.php 127
ERROR - 2023-08-17 17:37:42 --> Severity: Notice --> Undefined property: stdClass::$nama_section C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_area.php 127
ERROR - 2023-08-17 10:45:08 --> 404 Page Not Found: administrator/Fm_karyawan/nonaktif
ERROR - 2023-08-17 17:46:06 --> Severity: Notice --> Undefined property: Fm_karyawan::$M_unit_area C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_karyawan.php 95
ERROR - 2023-08-17 17:46:06 --> Severity: error --> Exception: Call to a member function update_data() on null C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_karyawan.php 95
ERROR - 2023-08-17 17:46:53 --> Query error: Unknown column 'sts_aktif' in 'field list' - Invalid query: UPDATE `tbl_pegawai` SET `sts_aktif` = 2, `user_created` = 'Validator 1', `date_created` = '2023-08-17 17:46'
WHERE `id_pegawai` = '7'
ERROR - 2023-08-17 17:54:55 --> Severity: Notice --> Undefined property: Fm_mjm_user::$M_karyawan C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 67
ERROR - 2023-08-17 17:54:55 --> Severity: error --> Exception: Call to a member function update_data() on null C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 67
ERROR - 2023-08-17 17:55:09 --> Query error: Unknown column 'date_created' in 'field list' - Invalid query: UPDATE `tbl_manajemen_user` SET `status` = 2, `date_created` = '2023-08-17 17:55'
WHERE `id_manajemen_user` IS NULL
ERROR - 2023-08-17 17:55:31 --> Query error: Column 'id_pegawai' in order clause is ambiguous - Invalid query: SELECT *
FROM `tbl_manajemen_user`
LEFT JOIN `tbl_pegawai` ON `tbl_pegawai`.`id_pegawai` = `tbl_manajemen_user`.`id_pegawai`
ORDER BY `id_pegawai` ASC
 LIMIT 10
ERROR - 2023-08-17 11:00:27 --> 404 Page Not Found: Images/bg
ERROR - 2023-08-17 18:27:14 --> 404 Page Not Found: administrator/Fm_jenis_jadwal/get_byid
ERROR - 2023-08-17 18:28:24 --> 404 Page Not Found: administrator/Fm_jenis_jadwal/get_byid
ERROR - 2023-08-17 18:54:21 --> 404 Page Not Found: administrator/Fm_jenis_jadwal/get_jadwal21
ERROR - 2023-08-17 18:54:25 --> 404 Page Not Found: administrator/Fm_jenis_jadwal/get_jadwal21

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-21 03:40:16 --> 404 Page Not Found: Images/bg

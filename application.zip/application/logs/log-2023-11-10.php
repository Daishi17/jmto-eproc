<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-10 00:17:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 914
ERROR - 2023-11-10 00:17:31 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 172
ERROR - 2023-11-10 00:17:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 961
ERROR - 2023-11-10 00:17:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1188
ERROR - 2023-11-10 00:17:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 914
ERROR - 2023-11-10 00:17:36 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 172
ERROR - 2023-11-10 00:17:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1188
ERROR - 2023-11-10 00:17:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 961
ERROR - 2023-11-10 00:18:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 914
ERROR - 2023-11-10 00:18:23 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 172
ERROR - 2023-11-10 00:18:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1188
ERROR - 2023-11-10 00:18:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 961
ERROR - 2023-11-10 00:28:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 35
ERROR - 2023-11-10 00:28:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 58
ERROR - 2023-11-10 00:28:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 72
ERROR - 2023-11-10 00:28:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 86
ERROR - 2023-11-10 00:28:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 100
ERROR - 2023-11-10 00:28:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 114
ERROR - 2023-11-10 00:28:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 128
ERROR - 2023-11-10 00:28:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 142
ERROR - 2023-11-10 00:28:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 156
ERROR - 2023-11-10 00:28:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 170
ERROR - 2023-11-10 00:28:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 184
ERROR - 2023-11-10 00:28:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 198
ERROR - 2023-11-10 00:28:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 212
ERROR - 2023-11-10 00:28:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 227
ERROR - 2023-11-10 00:28:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 241
ERROR - 2023-11-10 00:28:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 256
ERROR - 2023-11-10 00:28:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 270
ERROR - 2023-11-10 00:28:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 284
ERROR - 2023-11-10 00:28:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 299
ERROR - 2023-11-10 00:28:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 313
ERROR - 2023-11-10 00:28:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 328
ERROR - 2023-11-10 00:28:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 35
ERROR - 2023-11-10 00:28:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 58
ERROR - 2023-11-10 00:28:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 72
ERROR - 2023-11-10 00:28:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 86
ERROR - 2023-11-10 00:28:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 100
ERROR - 2023-11-10 00:28:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 114
ERROR - 2023-11-10 00:28:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 128
ERROR - 2023-11-10 00:28:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 142
ERROR - 2023-11-10 00:28:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 156
ERROR - 2023-11-10 00:28:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 170
ERROR - 2023-11-10 00:28:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 184
ERROR - 2023-11-10 00:28:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 198
ERROR - 2023-11-10 00:28:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 212
ERROR - 2023-11-10 00:28:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 227
ERROR - 2023-11-10 00:28:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 241
ERROR - 2023-11-10 00:28:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 256
ERROR - 2023-11-10 00:28:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 270
ERROR - 2023-11-10 00:28:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 284
ERROR - 2023-11-10 00:28:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 299
ERROR - 2023-11-10 00:28:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 313
ERROR - 2023-11-10 00:28:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 328
ERROR - 2023-11-10 00:28:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 35
ERROR - 2023-11-10 00:28:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 58
ERROR - 2023-11-10 00:28:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 72
ERROR - 2023-11-10 00:28:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 86
ERROR - 2023-11-10 00:28:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 100
ERROR - 2023-11-10 00:28:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 114
ERROR - 2023-11-10 00:28:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 128
ERROR - 2023-11-10 00:28:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 142
ERROR - 2023-11-10 00:28:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 156
ERROR - 2023-11-10 00:28:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 170
ERROR - 2023-11-10 00:28:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 184
ERROR - 2023-11-10 00:28:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 198
ERROR - 2023-11-10 00:28:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 212
ERROR - 2023-11-10 00:28:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 227
ERROR - 2023-11-10 00:28:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 241
ERROR - 2023-11-10 00:28:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 256
ERROR - 2023-11-10 00:28:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 270
ERROR - 2023-11-10 00:28:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 284
ERROR - 2023-11-10 00:28:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 299
ERROR - 2023-11-10 00:28:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 313
ERROR - 2023-11-10 00:28:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 328
ERROR - 2023-11-10 00:29:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 35
ERROR - 2023-11-10 00:29:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 58
ERROR - 2023-11-10 00:29:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 72
ERROR - 2023-11-10 00:29:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 86
ERROR - 2023-11-10 00:29:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 100
ERROR - 2023-11-10 00:29:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 114
ERROR - 2023-11-10 00:29:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 128
ERROR - 2023-11-10 00:29:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 142
ERROR - 2023-11-10 00:29:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 156
ERROR - 2023-11-10 00:29:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 170
ERROR - 2023-11-10 00:29:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 184
ERROR - 2023-11-10 00:29:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 198
ERROR - 2023-11-10 00:29:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 212
ERROR - 2023-11-10 00:29:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 227
ERROR - 2023-11-10 00:29:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 241
ERROR - 2023-11-10 00:29:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 256
ERROR - 2023-11-10 00:29:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 270
ERROR - 2023-11-10 00:29:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 284
ERROR - 2023-11-10 00:29:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 299
ERROR - 2023-11-10 00:29:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 313
ERROR - 2023-11-10 00:29:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 328
ERROR - 2023-11-10 00:29:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 35
ERROR - 2023-11-10 00:30:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 33
ERROR - 2023-11-10 00:30:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 33
ERROR - 2023-11-10 00:32:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 35
ERROR - 2023-11-10 00:32:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 58
ERROR - 2023-11-10 00:32:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 72
ERROR - 2023-11-10 00:32:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 86
ERROR - 2023-11-10 00:32:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 100
ERROR - 2023-11-10 00:32:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 114
ERROR - 2023-11-10 00:32:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 128
ERROR - 2023-11-10 00:32:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 142
ERROR - 2023-11-10 00:32:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 156
ERROR - 2023-11-10 00:32:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 170
ERROR - 2023-11-10 00:32:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 184
ERROR - 2023-11-10 00:32:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 198
ERROR - 2023-11-10 00:32:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 212
ERROR - 2023-11-10 00:32:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 227
ERROR - 2023-11-10 00:32:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 241
ERROR - 2023-11-10 00:32:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 256
ERROR - 2023-11-10 00:32:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 270
ERROR - 2023-11-10 00:32:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 284
ERROR - 2023-11-10 00:32:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 299
ERROR - 2023-11-10 00:32:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 313
ERROR - 2023-11-10 00:32:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 328
ERROR - 2023-11-10 00:33:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 35
ERROR - 2023-11-10 00:33:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 58
ERROR - 2023-11-10 00:33:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 72
ERROR - 2023-11-10 00:33:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 86
ERROR - 2023-11-10 00:33:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 100
ERROR - 2023-11-10 00:33:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 114
ERROR - 2023-11-10 00:33:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 128
ERROR - 2023-11-10 00:33:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 142
ERROR - 2023-11-10 00:33:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 156
ERROR - 2023-11-10 00:33:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 170
ERROR - 2023-11-10 00:33:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 184
ERROR - 2023-11-10 00:33:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 198
ERROR - 2023-11-10 00:33:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 212
ERROR - 2023-11-10 00:33:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 227
ERROR - 2023-11-10 00:33:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 241
ERROR - 2023-11-10 00:33:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 256
ERROR - 2023-11-10 00:33:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 270
ERROR - 2023-11-10 00:33:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 284
ERROR - 2023-11-10 00:33:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 299
ERROR - 2023-11-10 00:33:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 313
ERROR - 2023-11-10 00:33:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 328
ERROR - 2023-11-10 00:40:06 --> Query error: Unknown column 'nama_program_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `tbl_rup`.`sts_rup` = 1
AND `tbl_rup`.`sts_rup_buat_paket` IN(1, 2)
AND   (
`id_rup` LIKE '%RUP UMROH HAJI%' ESCAPE '!'
OR  `kode_rup` LIKE '%RUP UMROH HAJI%' ESCAPE '!'
OR  `tahun_rup` LIKE '%RUP UMROH HAJI%' ESCAPE '!'
OR  `nama_program_rup` LIKE '%RUP UMROH HAJI%' ESCAPE '!'
OR  `kode_departemen` LIKE '%RUP UMROH HAJI%' ESCAPE '!'
OR  `total_pagu_rup` LIKE '%RUP UMROH HAJI%' ESCAPE '!'
OR  `id_rup` LIKE '%RUP UMROH HAJI%' ESCAPE '!'
OR  `id_rup` LIKE '%RUP UMROH HAJI%' ESCAPE '!'
OR  `id_rup` LIKE '%RUP UMROH HAJI%' ESCAPE '!'
 )
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2023-11-10 00:40:09 --> Query error: Unknown column 'nama_program_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `tbl_rup`.`sts_rup` = 1
AND `tbl_rup`.`sts_rup_buat_paket` IN(1, 2)
AND   (
`id_rup` LIKE '%RUP UMROH HAJI%' ESCAPE '!'
OR  `kode_rup` LIKE '%RUP UMROH HAJI%' ESCAPE '!'
OR  `tahun_rup` LIKE '%RUP UMROH HAJI%' ESCAPE '!'
OR  `nama_program_rup` LIKE '%RUP UMROH HAJI%' ESCAPE '!'
OR  `kode_departemen` LIKE '%RUP UMROH HAJI%' ESCAPE '!'
OR  `total_pagu_rup` LIKE '%RUP UMROH HAJI%' ESCAPE '!'
OR  `id_rup` LIKE '%RUP UMROH HAJI%' ESCAPE '!'
OR  `id_rup` LIKE '%RUP UMROH HAJI%' ESCAPE '!'
OR  `id_rup` LIKE '%RUP UMROH HAJI%' ESCAPE '!'
 )
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10, 10
ERROR - 2023-11-10 00:40:47 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 171
ERROR - 2023-11-10 00:40:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 921
ERROR - 2023-11-10 00:40:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1194
ERROR - 2023-11-10 00:40:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 968
ERROR - 2023-11-10 00:42:52 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 171
ERROR - 2023-11-10 00:42:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 921
ERROR - 2023-11-10 00:42:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 968
ERROR - 2023-11-10 00:42:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1194
ERROR - 2023-11-10 00:44:57 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 171
ERROR - 2023-11-10 00:44:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 921
ERROR - 2023-11-10 00:44:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 968
ERROR - 2023-11-10 00:44:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1194
ERROR - 2023-11-10 00:48:07 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 171
ERROR - 2023-11-10 00:48:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 921
ERROR - 2023-11-10 00:48:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 968
ERROR - 2023-11-10 00:48:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1194
ERROR - 2023-11-10 00:48:37 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 171
ERROR - 2023-11-10 00:48:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 921
ERROR - 2023-11-10 00:48:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 968
ERROR - 2023-11-10 00:48:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1194
ERROR - 2023-11-10 00:49:34 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 171
ERROR - 2023-11-10 00:49:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 968
ERROR - 2023-11-10 00:49:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1194
ERROR - 2023-11-10 00:49:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 921
ERROR - 2023-11-10 00:51:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 921
ERROR - 2023-11-10 00:51:09 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 171
ERROR - 2023-11-10 00:51:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 968
ERROR - 2023-11-10 00:51:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1194
ERROR - 2023-11-10 01:07:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 932
ERROR - 2023-11-10 01:07:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 933
ERROR - 2023-11-10 01:07:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 932
ERROR - 2023-11-10 01:07:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 933
ERROR - 2023-11-10 01:07:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 932
ERROR - 2023-11-10 01:07:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 933
ERROR - 2023-11-10 01:07:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 932
ERROR - 2023-11-10 01:07:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 933
ERROR - 2023-11-10 01:08:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 932
ERROR - 2023-11-10 01:08:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 933
ERROR - 2023-11-10 01:08:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 932
ERROR - 2023-11-10 01:08:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 933
ERROR - 2023-11-10 01:08:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 932
ERROR - 2023-11-10 01:08:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 933
ERROR - 2023-11-10 01:08:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 932
ERROR - 2023-11-10 01:08:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 933
ERROR - 2023-11-10 01:08:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 932
ERROR - 2023-11-10 01:08:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 933
ERROR - 2023-11-10 01:08:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 932
ERROR - 2023-11-10 01:08:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 933
ERROR - 2023-11-10 01:08:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 932
ERROR - 2023-11-10 01:08:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 933
ERROR - 2023-11-10 01:08:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 932
ERROR - 2023-11-10 01:08:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 933
ERROR - 2023-11-10 01:08:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 932
ERROR - 2023-11-10 01:08:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 933
ERROR - 2023-11-10 01:08:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 932
ERROR - 2023-11-10 01:08:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 933
ERROR - 2023-11-10 01:08:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 932
ERROR - 2023-11-10 01:08:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 933
ERROR - 2023-11-10 01:08:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 932
ERROR - 2023-11-10 01:08:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 933
ERROR - 2023-11-10 01:32:17 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 579
ERROR - 2023-11-10 01:32:17 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 579
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1245
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1246
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1246
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 368
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Undefined index: draw C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 416
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216
ERROR - 2023-11-10 01:33:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1216

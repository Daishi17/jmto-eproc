<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-14 00:29:42 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 01:16:01 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 01:25:23 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 00:03:26 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 00:04:16 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 02:26:24 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 02:27:26 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 02:27:44 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 02:27:55 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 02:28:00 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 02:28:01 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 02:30:25 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 02:31:11 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 02:33:50 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 02:34:30 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 02:38:11 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 02:38:53 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 02:41:10 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 02:41:41 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 02:43:41 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 02:44:12 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 02:45:20 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 02:46:35 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 02:46:54 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 02:46:54 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 02:47:01 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 02:54:46 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 02:56:32 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 02:58:47 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 03:00:30 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 03:02:59 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 03:05:15 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 10:29:33 --> Query error: Unknown column 'id_kbli' in 'where clause' - Invalid query: SELECT *
FROM `tbl_sbu`
WHERE   (
`id_kbli` LIKE '%E%' ESCAPE '!'
OR  `kode_kbli` LIKE '%E%' ESCAPE '!'
OR  `nama_kbli` LIKE '%E%' ESCAPE '!'
OR  `id_kbli` LIKE '%E%' ESCAPE '!'
 )
ORDER BY `tbl_sbu`.`id_sbu` ASC
 LIMIT 10
ERROR - 2023-07-14 10:29:39 --> Query error: Unknown column 'id_kbli' in 'where clause' - Invalid query: SELECT *
FROM `tbl_sbu`
WHERE   (
`id_kbli` LIKE '%e%' ESCAPE '!'
OR  `kode_kbli` LIKE '%e%' ESCAPE '!'
OR  `nama_kbli` LIKE '%e%' ESCAPE '!'
OR  `id_kbli` LIKE '%e%' ESCAPE '!'
 )
ORDER BY `tbl_sbu`.`id_sbu` ASC
 LIMIT 10
ERROR - 2023-07-14 10:29:42 --> Query error: Unknown column 'id_kbli' in 'where clause' - Invalid query: SELECT *
FROM `tbl_sbu`
WHERE   (
`id_kbli` LIKE '%el%' ESCAPE '!'
OR  `kode_kbli` LIKE '%el%' ESCAPE '!'
OR  `nama_kbli` LIKE '%el%' ESCAPE '!'
OR  `id_kbli` LIKE '%el%' ESCAPE '!'
 )
ORDER BY `tbl_sbu`.`id_sbu` ASC
 LIMIT 10
ERROR - 2023-07-14 10:31:18 --> Severity: Notice --> Undefined variable: order_sbu /home/u1064384/public_html/jmto-eproc.kintekindo.net/application/models/M_master/M_master.php 93
ERROR - 2023-07-14 10:31:18 --> Severity: Notice --> Undefined property: Data_sbu::$ /home/u1064384/public_html/jmto-eproc.kintekindo.net/system/core/Model.php 74
ERROR - 2023-07-14 10:31:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/u1064384/public_html/jmto-eproc.kintekindo.net/application/models/M_master/M_master.php 93
ERROR - 2023-07-14 10:31:18 --> Severity: Notice --> Undefined variable: order_sbu /home/u1064384/public_html/jmto-eproc.kintekindo.net/application/models/M_master/M_master.php 93
ERROR - 2023-07-14 10:31:18 --> Severity: Notice --> Undefined property: Data_sbu::$ /home/u1064384/public_html/jmto-eproc.kintekindo.net/system/core/Model.php 74
ERROR - 2023-07-14 10:31:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/u1064384/public_html/jmto-eproc.kintekindo.net/application/models/M_master/M_master.php 93
ERROR - 2023-07-14 06:44:01 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 06:49:02 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-14 06:57:37 --> 404 Page Not Found: Images/bg

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-02 14:49:26 --> 404 Page Not Found: Images/bg
ERROR - 2023-08-02 14:50:04 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 14:50:16 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 14:50:19 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 14:50:21 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 14:50:22 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 14:50:25 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 14:50:50 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:06:12 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:07:39 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:07:40 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:07:41 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:07:42 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:07:43 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:07:45 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:07:48 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:07:50 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:07:52 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:07:55 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:08:08 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:08:09 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:08:11 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:08:45 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:09:03 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:09:05 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:09:07 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:10:04 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:10:06 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:10:13 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:10:18 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:11:01 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:11:13 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:11:15 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:20:30 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:21:19 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:22:01 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:22:06 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:22:08 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:22:55 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 22:24:51 --> Severity: Compile Error --> Cannot declare class Fm_unit_kerja, because the name is already in use C:\laragon\www\jmto-eproc\application\models\M_master\M_unit_kerja.php 4
ERROR - 2023-08-02 15:25:05 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:25:36 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 22:30:12 --> Severity: error --> Exception: Call to undefined method M_unit_kerja::kode() C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_kerja.php 15
ERROR - 2023-08-02 22:30:19 --> Severity: error --> Exception: Too few arguments to function M_unit_kerja::kode(), 0 passed in C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_kerja.php on line 15 and exactly 1 expected C:\laragon\www\jmto-eproc\application\models\M_master\M_unit_kerja.php 6
ERROR - 2023-08-02 22:31:07 --> Query error: Unknown column 'kd_lokasi' in 'order clause' - Invalid query: SELECT RIGHT(tbl_departemen.kode_departemen, 3) as kode_departemen
FROM `tbl_departemen`
ORDER BY `kd_lokasi` DESC
 LIMIT 1
ERROR - 2023-08-02 22:31:16 --> Severity: Notice --> Undefined property: stdClass::$kd_lokasi C:\laragon\www\jmto-eproc\application\models\M_master\M_unit_kerja.php 15
ERROR - 2023-08-02 15:31:16 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 22:31:24 --> Severity: Notice --> Undefined property: stdClass::$kd_lokasi C:\laragon\www\jmto-eproc\application\models\M_master\M_unit_kerja.php 15
ERROR - 2023-08-02 15:31:24 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 22:31:27 --> Severity: Notice --> Undefined property: stdClass::$kd_lokasi C:\laragon\www\jmto-eproc\application\models\M_master\M_unit_kerja.php 15
ERROR - 2023-08-02 15:31:27 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:31:41 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:31:53 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:32:04 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:32:38 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:33:37 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:33:41 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:34:03 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:34:40 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:36:05 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:36:55 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:37:12 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:37:43 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:37:59 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:38:30 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:38:52 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:39:39 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:44:13 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:44:41 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:44:53 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:50:05 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:50:31 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:51:25 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 15:59:29 --> Severity: Warning --> mysqli::set_charset(): Error executing query C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 285
ERROR - 2023-08-02 15:59:29 --> Unable to set database connection charset: utf8
ERROR - 2023-08-02 16:00:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-02 16:00:40 --> Unable to connect to the database
ERROR - 2023-08-02 16:01:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-02 16:01:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-02 16:01:50 --> Unable to connect to the database
ERROR - 2023-08-02 16:01:50 --> Unable to connect to the database
ERROR - 2023-08-02 16:01:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-02 16:01:57 --> Unable to connect to the database
ERROR - 2023-08-02 16:01:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-02 16:01:58 --> Unable to connect to the database
ERROR - 2023-08-02 16:02:29 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-02 16:02:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-02 16:02:29 --> Unable to connect to the database
ERROR - 2023-08-02 23:35:49 --> Severity: Notice --> Undefined offset: 3 C:\laragon\www\jmto-eproc\application\models\M_master\M_unit_kerja.php 35
ERROR - 2023-08-02 23:35:49 --> Severity: Notice --> Undefined offset: 3 C:\laragon\www\jmto-eproc\application\models\M_master\M_unit_kerja.php 35
ERROR - 2023-08-02 16:40:06 --> 404 Page Not Found: administrator/Data_lokasi/byid
ERROR - 2023-08-02 16:40:20 --> 404 Page Not Found: administrator/Data_lokasi/byid
ERROR - 2023-08-02 16:42:16 --> 404 Page Not Found: administrator/Data_lokasi/byid
ERROR - 2023-08-02 16:43:06 --> 404 Page Not Found: administrator/Data_lokasi/byid
ERROR - 2023-08-02 16:45:28 --> 404 Page Not Found: administrator/Data_lokasi/byid
ERROR - 2023-08-02 17:12:20 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 17:12:25 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 17:12:40 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 17:12:42 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 17:12:58 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 17:14:12 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 17:14:19 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 17:14:26 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 17:16:07 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 17:17:39 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 17:32:04 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 17:42:40 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 17:42:43 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 17:42:55 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 17:42:58 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 17:54:38 --> 404 Page Not Found: Assets/plugins-lte
ERROR - 2023-08-02 18:04:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-02 18:04:45 --> Unable to connect to the database
ERROR - 2023-08-02 18:04:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): An established connection was aborted by the software in your host machine.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-08-02 18:04:52 --> Unable to connect to the database
ERROR - 2023-08-02 18:28:35 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 20:17:59 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 20:18:03 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 20:18:36 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 20:18:38 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 20:18:41 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-02 22:21:38 --> 404 Page Not Found: administrator/Fm_karyawan/byid
ERROR - 2023-08-02 22:21:46 --> 404 Page Not Found: administrator/Fm_karyawan/byid

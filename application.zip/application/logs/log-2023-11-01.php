<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-01 00:10:30 --> Query error: Unknown column 'tbl_vendor_mengikuti_paket' in 'where clause' - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '155'
AND `tbl_vendor_mengikuti_paket` > 60
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2023-11-01 00:10:35 --> Query error: Unknown column 'tbl_vendor_mengikuti_paket' in 'where clause' - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '155'
AND `tbl_vendor_mengikuti_paket` > 60
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2023-11-01 00:11:01 --> Query error: Unknown column 'tbl_vendor_mengikuti_paket' in 'where clause' - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '155'
AND `tbl_vendor_mengikuti_paket` > 60
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2023-11-01 00:11:15 --> Query error: Unknown column 'tbl_vendor_mengikuti_paket' in 'where clause' - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '155'
AND `tbl_vendor_mengikuti_paket` > 60
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2023-11-01 01:02:47 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-11-01 01:02:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-11-01 01:02:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-11-01 01:02:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-11-01 01:34:54 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-11-01 01:34:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-11-01 01:34:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-11-01 01:34:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167

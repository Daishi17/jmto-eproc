<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-16 06:19:16 --> 404 Page Not Found: Images/bg

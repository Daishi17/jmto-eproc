<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-06 23:56:40 --> Severity: Notice --> Undefined index: nama_karyawan C:\laragon\www\jmto-eproc\application\views\administrator\file_master\fm_mjm_user.php 172
ERROR - 2023-08-06 23:56:40 --> Severity: Notice --> Undefined index: nama_karyawan C:\laragon\www\jmto-eproc\application\views\administrator\file_master\fm_mjm_user.php 172
ERROR - 2023-08-06 23:56:40 --> Severity: Notice --> Undefined index: nama_karyawan C:\laragon\www\jmto-eproc\application\views\administrator\file_master\fm_mjm_user.php 172
ERROR - 2023-08-06 23:56:40 --> Severity: Notice --> Undefined index: nama_karyawan C:\laragon\www\jmto-eproc\application\views\administrator\file_master\fm_mjm_user.php 172
ERROR - 2023-08-06 23:56:40 --> Severity: Notice --> Undefined index: nama_karyawan C:\laragon\www\jmto-eproc\application\views\administrator\file_master\fm_mjm_user.php 172
ERROR - 2023-08-06 18:46:29 --> Severity: error --> Exception: syntax error, unexpected 'role' (T_STRING) C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_mjm_user.php 85
ERROR - 2023-08-06 19:32:45 --> 404 Page Not Found: administrator/Fm_mjm_user/get_byid_mjm

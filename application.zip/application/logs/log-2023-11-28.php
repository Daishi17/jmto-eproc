<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-28 23:57:11 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\xampp\htdocs\jmto-eproc\application\libraries\Role_login.php 21
ERROR - 2023-11-28 23:57:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1331
ERROR - 2023-11-28 23:57:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1093
ERROR - 2023-11-28 23:57:42 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 276
ERROR - 2023-11-28 23:57:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1046
ERROR - 2023-11-28 23:57:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1046
ERROR - 2023-11-28 23:57:58 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 276
ERROR - 2023-11-28 23:57:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1093
ERROR - 2023-11-28 23:57:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1331
ERROR - 2023-11-28 23:58:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1046
ERROR - 2023-11-28 23:58:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1093
ERROR - 2023-11-28 23:58:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1331
ERROR - 2023-11-28 23:58:32 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 276
ERROR - 2023-11-28 23:59:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 748
ERROR - 2023-11-28 23:59:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 749
ERROR - 2023-11-28 23:59:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 748
ERROR - 2023-11-28 23:59:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 749
ERROR - 2023-11-28 23:59:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 748
ERROR - 2023-11-28 23:59:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 749
ERROR - 2023-11-28 23:59:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 748
ERROR - 2023-11-28 23:59:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 749
ERROR - 2023-11-28 17:59:46 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-28 21:29:40 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-28 21:30:34 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-28 21:30:37 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-28 21:30:51 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-28 21:32:11 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-28 21:37:20 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-28 21:38:38 --> 404 Page Not Found: Assets/img

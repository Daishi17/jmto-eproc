<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-18 06:13:39 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-18 06:15:04 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-18 08:17:22 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-18 09:29:14 --> 404 Page Not Found: Images/bg

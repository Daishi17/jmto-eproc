<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-01 20:55:05 --> 404 Page Not Found: Assets/js
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-01 20:55:05 --> 404 Page Not Found: Assets/css
ERROR - 2023-08-01 20:56:17 --> 404 Page Not Found: Assets/css
ERROR - 2023-08-01 20:58:40 --> 404 Page Not Found: Assets/css
ERROR - 2023-08-01 20:58:40 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-01 20:58:42 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-01 20:58:43 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-01 20:58:44 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-01 20:58:45 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-01 20:58:47 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-01 20:58:49 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-01 20:58:50 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-01 20:58:51 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-01 20:58:52 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-01 20:58:55 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-01 20:59:12 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-01 20:59:21 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-01 20:59:23 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-01 20:59:23 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-01 20:59:26 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-01 20:59:29 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-01 20:59:35 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-01 20:59:49 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-01 21:00:04 --> 404 Page Not Found: Assets/css
ERROR - 2023-08-01 21:00:04 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-01 21:00:09 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-01 21:00:23 --> 404 Page Not Found: Assets/css
ERROR - 2023-08-01 21:00:23 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-01 21:00:49 --> 404 Page Not Found: Assets/css
ERROR - 2023-08-01 21:01:28 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-01 21:02:05 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-01 21:03:35 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-01 21:03:36 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-01 21:09:50 --> 404 Page Not Found: Images/bg
ERROR - 2023-08-01 21:10:40 --> 404 Page Not Found: Images/bg
ERROR - 2023-08-01 21:11:17 --> 404 Page Not Found: Images/bg

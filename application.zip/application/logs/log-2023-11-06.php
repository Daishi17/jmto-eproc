<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-06 11:07:53 --> Query error: Unknown column 'tbl_vendor_siujk.sts_validais' in 'field list' - Invalid query: SELECT `tbl_vendor_siup`.`sts_validasi`, `tbl_vendor_nib`.`sts_validasi`, `tbl_vendor_sbu`.`sts_validasi`, `tbl_vendor_sbu`.`sts_validasi`, `tbl_vendor_siujk`.`sts_validais`, `tbl_vendor_skdp`.`sts_validasi`, `tbl_vendor_izin_lain`.`sts_validasi`, `tbl_vendor_akta_pendirian`.`sts_validasi`, `tbl_vendor_akta_perubahan`.`sts_validasi`, `tbl_vendor_pemilik`.`sts_validasi`, `tbl_vendor_pengurus`.`sts_validasi`, `tbl_vendor_pengalaman`.`sts_validasi`, `tbl_vendor_sppkp`.`sts_validasi`, `tbl_vendor_npwp`.`sts_validasi`, `tbl_vendor_spt`.`sts_validasi`, `tbl_vendor_neraca_keuangan`.`sts_validasi`, `tbl_vendor_keuangan`.`sts_validasi`
FROM `tbl_vendor`
JOIN `tbl_vendor_siup` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_siup`.`id_vendor`
JOIN `tbl_vendor_nib` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_nib`.`id_vendor`
JOIN `tbl_vendor_sbu` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_sbu`.`id_vendor`
JOIN `tbl_vendor_siujk` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_siujk`.`id_vendor`
JOIN `tbl_vendor_skdp` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_skdp`.`id_vendor`
JOIN `tbl_vendor_izin_lain` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_izin_lain`.`id_vendor`
JOIN `tbl_vendor_akta_pendirian` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_akta_pendirian`.`id_vendor`
JOIN `tbl_vendor_akta_perubahan` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_akta_perubahan`.`id_vendor`
JOIN `tbl_vendor_pemilik` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_pemilik`.`id_vendor`
JOIN `tbl_vendor_pengurus` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_pengurus`.`id_vendor`
JOIN `tbl_vendor_pengalaman` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_pengalaman`.`id_vendor`
JOIN `tbl_vendor_sppkp` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_sppkp`.`id_vendor`
JOIN `tbl_vendor_npwp` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_npwp`.`id_vendor`
JOIN `tbl_vendor_spt` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_spt`.`id_vendor`
JOIN `tbl_vendor_neraca_keuangan` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_neraca_keuangan`.`id_vendor`
JOIN `tbl_vendor_keuangan` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_keuangan`.`id_vendor`
WHERE `tbl_vendor`.`id_vendor` = '54'
AND `tbl_vendor_siup`.`sts_validasi` = 1
AND `tbl_vendor_nib`.`sts_validasi` = 1
AND `tbl_vendor_sbu`.`sts_validasi` = 1
AND `tbl_vendor_siujk`.`sts_validasi` = 1
AND `tbl_vendor_skdp`.`sts_validasi` = 1
AND `tbl_vendor_izin_lain`.`sts_validasi` = 1
AND `tbl_vendor_akta_pendirian`.`sts_validasi` = 1
AND `tbl_vendor_akta_perubahan`.`sts_validasi` = 1
AND `tbl_vendor_pemilik`.`sts_validasi` = 1
AND `tbl_vendor_pengurus`.`sts_validasi` = 1
AND `tbl_vendor_pengalaman`.`sts_validasi` = 1
AND `tbl_vendor_sppkp`.`sts_validasi` = 1
AND `tbl_vendor_npwp`.`sts_validasi` = 1
AND `tbl_vendor_spt`.`sts_validasi` = 1
AND `tbl_vendor_neraca_keuangan`.`sts_validasi` = 1
AND `tbl_vendor_keuangan`.`sts_validasi` = 1
ERROR - 2023-11-06 11:07:57 --> Query error: Unknown column 'tbl_vendor_siujk.sts_validais' in 'field list' - Invalid query: SELECT `tbl_vendor_siup`.`sts_validasi`, `tbl_vendor_nib`.`sts_validasi`, `tbl_vendor_sbu`.`sts_validasi`, `tbl_vendor_sbu`.`sts_validasi`, `tbl_vendor_siujk`.`sts_validais`, `tbl_vendor_skdp`.`sts_validasi`, `tbl_vendor_izin_lain`.`sts_validasi`, `tbl_vendor_akta_pendirian`.`sts_validasi`, `tbl_vendor_akta_perubahan`.`sts_validasi`, `tbl_vendor_pemilik`.`sts_validasi`, `tbl_vendor_pengurus`.`sts_validasi`, `tbl_vendor_pengalaman`.`sts_validasi`, `tbl_vendor_sppkp`.`sts_validasi`, `tbl_vendor_npwp`.`sts_validasi`, `tbl_vendor_spt`.`sts_validasi`, `tbl_vendor_neraca_keuangan`.`sts_validasi`, `tbl_vendor_keuangan`.`sts_validasi`
FROM `tbl_vendor`
JOIN `tbl_vendor_siup` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_siup`.`id_vendor`
JOIN `tbl_vendor_nib` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_nib`.`id_vendor`
JOIN `tbl_vendor_sbu` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_sbu`.`id_vendor`
JOIN `tbl_vendor_siujk` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_siujk`.`id_vendor`
JOIN `tbl_vendor_skdp` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_skdp`.`id_vendor`
JOIN `tbl_vendor_izin_lain` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_izin_lain`.`id_vendor`
JOIN `tbl_vendor_akta_pendirian` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_akta_pendirian`.`id_vendor`
JOIN `tbl_vendor_akta_perubahan` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_akta_perubahan`.`id_vendor`
JOIN `tbl_vendor_pemilik` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_pemilik`.`id_vendor`
JOIN `tbl_vendor_pengurus` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_pengurus`.`id_vendor`
JOIN `tbl_vendor_pengalaman` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_pengalaman`.`id_vendor`
JOIN `tbl_vendor_sppkp` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_sppkp`.`id_vendor`
JOIN `tbl_vendor_npwp` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_npwp`.`id_vendor`
JOIN `tbl_vendor_spt` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_spt`.`id_vendor`
JOIN `tbl_vendor_neraca_keuangan` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_neraca_keuangan`.`id_vendor`
JOIN `tbl_vendor_keuangan` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_keuangan`.`id_vendor`
WHERE `tbl_vendor`.`id_vendor` = '54'
AND `tbl_vendor_siup`.`sts_validasi` = 1
AND `tbl_vendor_nib`.`sts_validasi` = 1
AND `tbl_vendor_sbu`.`sts_validasi` = 1
AND `tbl_vendor_siujk`.`sts_validasi` = 1
AND `tbl_vendor_skdp`.`sts_validasi` = 1
AND `tbl_vendor_izin_lain`.`sts_validasi` = 1
AND `tbl_vendor_akta_pendirian`.`sts_validasi` = 1
AND `tbl_vendor_akta_perubahan`.`sts_validasi` = 1
AND `tbl_vendor_pemilik`.`sts_validasi` = 1
AND `tbl_vendor_pengurus`.`sts_validasi` = 1
AND `tbl_vendor_pengalaman`.`sts_validasi` = 1
AND `tbl_vendor_sppkp`.`sts_validasi` = 1
AND `tbl_vendor_npwp`.`sts_validasi` = 1
AND `tbl_vendor_spt`.`sts_validasi` = 1
AND `tbl_vendor_neraca_keuangan`.`sts_validasi` = 1
AND `tbl_vendor_keuangan`.`sts_validasi` = 1
ERROR - 2023-11-06 06:35:55 --> 404 Page Not Found: Assets_landing/bootstrap.min.css.map
ERROR - 2023-11-06 06:35:55 --> 404 Page Not Found: Css/style.css.map
ERROR - 2023-11-06 06:35:55 --> 404 Page Not Found: Assets_landing/jarallax.min.js.map
ERROR - 2023-11-06 06:35:55 --> 404 Page Not Found: Assets_landing/jarallax-video.min.js.map
ERROR - 2023-11-06 16:02:13 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\laragon\www\jmto-eproc\application\libraries\Role_login.php 21
ERROR - 2023-11-06 16:02:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 895
ERROR - 2023-11-06 16:02:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 942
ERROR - 2023-11-06 16:02:39 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 171
ERROR - 2023-11-06 16:02:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1168
ERROR - 2023-11-06 16:03:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 895
ERROR - 2023-11-06 16:03:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 942
ERROR - 2023-11-06 16:03:17 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 171
ERROR - 2023-11-06 16:03:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1168
ERROR - 2023-11-06 16:05:30 --> Query error: Column 'id_rup' in order clause is ambiguous - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_panitia` ON `tbl_rup`.`id_rup` = `tbl_panitia`.`id_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `tbl_rup`.`status_paket_diumumkan` = 1
AND `tbl_rup`.`id_metode_pengadaan` = 1
AND `tbl_panitia`.`id_manajemen_user` = '26'
ORDER BY `id_rup` ASC
 LIMIT 10
ERROR - 2023-11-06 09:07:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-11-06 09:07:08 --> Unable to connect to the database
ERROR - 2023-11-06 09:07:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-11-06 09:07:10 --> Unable to connect to the database
ERROR - 2023-11-06 09:07:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-11-06 09:07:12 --> Unable to connect to the database
ERROR - 2023-11-06 09:07:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-11-06 09:07:16 --> Unable to connect to the database
ERROR - 2023-11-06 09:07:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-11-06 09:07:24 --> Unable to connect to the database
ERROR - 2023-11-06 16:07:33 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 171
ERROR - 2023-11-06 16:07:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 895
ERROR - 2023-11-06 16:07:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 942
ERROR - 2023-11-06 16:07:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1168
ERROR - 2023-11-06 09:08:22 --> 404 Page Not Found: File_paket/Testing%20paket%20terbaru%20(november)
ERROR - 2023-11-06 16:18:48 --> Severity: error --> Exception: Call to undefined method M_panitia::gettable_syarat_tambahan() C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 334
ERROR - 2023-11-06 16:18:53 --> Severity: error --> Exception: Call to undefined method M_panitia::gettable_syarat_tambahan() C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 334
ERROR - 2023-11-06 16:19:05 --> Severity: error --> Exception: Call to undefined method M_panitia::gettable_syarat_tambahan() C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 334
ERROR - 2023-11-06 16:31:50 --> Severity: error --> Exception: Call to undefined method M_panitia::gettable_syarat_tambahan() C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 334
ERROR - 2023-11-06 16:32:37 --> Query error: Unknown column 'tbl_rup.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_rup`.`id_rup` = '156'
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2023-11-06 16:32:58 --> Query error: Unknown column 'tbl_rup.id_rup' in 'order clause' - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '156'
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2023-11-06 16:34:07 --> Query error: Unknown column 'tbl_rup.id_rup' in 'order clause' - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '156'
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2023-11-06 16:35:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 27
ERROR - 2023-11-06 16:35:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 28
ERROR - 2023-11-06 16:35:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 29
ERROR - 2023-11-06 16:35:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 30
ERROR - 2023-11-06 16:35:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 31
ERROR - 2023-11-06 16:35:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 3
ERROR - 2023-11-06 16:35:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 11
ERROR - 2023-11-06 16:35:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 14
ERROR - 2023-11-06 16:35:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 17
ERROR - 2023-11-06 16:35:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 20
ERROR - 2023-11-06 16:35:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 23
ERROR - 2023-11-06 16:35:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 26
ERROR - 2023-11-06 16:35:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 44
ERROR - 2023-11-06 16:35:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 48
ERROR - 2023-11-06 16:35:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 52
ERROR - 2023-11-06 16:35:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 52
ERROR - 2023-11-06 16:35:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 57
ERROR - 2023-11-06 16:35:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 193
ERROR - 2023-11-06 16:35:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 198
ERROR - 2023-11-06 16:35:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 396
ERROR - 2023-11-06 09:42:13 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-06 09:42:33 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-06 16:44:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 29
ERROR - 2023-11-06 16:44:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 30
ERROR - 2023-11-06 16:44:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 31
ERROR - 2023-11-06 16:44:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 32
ERROR - 2023-11-06 16:44:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 33
ERROR - 2023-11-06 16:44:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 3
ERROR - 2023-11-06 16:44:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 11
ERROR - 2023-11-06 16:44:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 14
ERROR - 2023-11-06 16:44:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 17
ERROR - 2023-11-06 16:44:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 20
ERROR - 2023-11-06 16:44:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 23
ERROR - 2023-11-06 16:44:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 26
ERROR - 2023-11-06 16:44:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 44
ERROR - 2023-11-06 16:44:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 48
ERROR - 2023-11-06 16:44:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 52
ERROR - 2023-11-06 16:44:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 52
ERROR - 2023-11-06 16:44:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 57
ERROR - 2023-11-06 16:44:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 193
ERROR - 2023-11-06 16:44:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 198
ERROR - 2023-11-06 16:44:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 396
ERROR - 2023-11-06 16:47:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 29
ERROR - 2023-11-06 16:47:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 30
ERROR - 2023-11-06 16:47:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 31
ERROR - 2023-11-06 16:47:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 32
ERROR - 2023-11-06 16:47:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 33
ERROR - 2023-11-06 16:47:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 3
ERROR - 2023-11-06 16:47:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 11
ERROR - 2023-11-06 16:47:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 14
ERROR - 2023-11-06 16:47:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 17
ERROR - 2023-11-06 16:47:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 20
ERROR - 2023-11-06 16:47:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 23
ERROR - 2023-11-06 16:47:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 26
ERROR - 2023-11-06 16:47:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 44
ERROR - 2023-11-06 16:47:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 48
ERROR - 2023-11-06 16:47:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 52
ERROR - 2023-11-06 16:47:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 52
ERROR - 2023-11-06 16:47:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 57
ERROR - 2023-11-06 16:47:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 193
ERROR - 2023-11-06 16:47:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 198
ERROR - 2023-11-06 16:47:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 396
ERROR - 2023-11-06 16:48:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 29
ERROR - 2023-11-06 16:48:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 30
ERROR - 2023-11-06 16:48:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 31
ERROR - 2023-11-06 16:48:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 32
ERROR - 2023-11-06 16:48:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 33
ERROR - 2023-11-06 16:48:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 3
ERROR - 2023-11-06 16:48:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 11
ERROR - 2023-11-06 16:48:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 14
ERROR - 2023-11-06 16:48:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 17
ERROR - 2023-11-06 16:48:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 20
ERROR - 2023-11-06 16:48:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 23
ERROR - 2023-11-06 16:48:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 26
ERROR - 2023-11-06 16:48:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 44
ERROR - 2023-11-06 16:48:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 48
ERROR - 2023-11-06 16:48:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 52
ERROR - 2023-11-06 16:48:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 52
ERROR - 2023-11-06 16:48:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 57
ERROR - 2023-11-06 16:48:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 193
ERROR - 2023-11-06 16:48:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 198
ERROR - 2023-11-06 16:48:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 396
ERROR - 2023-11-06 16:48:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 29
ERROR - 2023-11-06 16:48:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 30
ERROR - 2023-11-06 16:48:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 31
ERROR - 2023-11-06 16:48:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 32
ERROR - 2023-11-06 16:48:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 33
ERROR - 2023-11-06 16:48:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 3
ERROR - 2023-11-06 16:48:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 11
ERROR - 2023-11-06 16:48:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 14
ERROR - 2023-11-06 16:48:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 17
ERROR - 2023-11-06 16:48:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 20
ERROR - 2023-11-06 16:48:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 23
ERROR - 2023-11-06 16:48:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 26
ERROR - 2023-11-06 16:48:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 44
ERROR - 2023-11-06 16:48:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 48
ERROR - 2023-11-06 16:48:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 52
ERROR - 2023-11-06 16:48:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 52
ERROR - 2023-11-06 16:48:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 57
ERROR - 2023-11-06 16:48:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 193
ERROR - 2023-11-06 16:48:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 198
ERROR - 2023-11-06 16:48:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 396
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 29
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 30
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 31
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 32
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 33
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 3
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 11
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 14
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 17
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 20
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 23
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 26
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 44
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 48
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 52
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 52
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 57
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 193
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 198
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 396
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 29
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 30
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 31
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 32
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 33
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 3
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 11
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 14
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 17
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 20
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 23
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 26
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 44
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 48
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 52
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 52
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 57
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 193
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 198
ERROR - 2023-11-06 16:48:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 396
ERROR - 2023-11-06 16:50:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 29
ERROR - 2023-11-06 16:50:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 30
ERROR - 2023-11-06 16:50:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 31
ERROR - 2023-11-06 16:50:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 32
ERROR - 2023-11-06 16:50:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 33
ERROR - 2023-11-06 16:50:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 3
ERROR - 2023-11-06 16:50:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 11
ERROR - 2023-11-06 16:50:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 14
ERROR - 2023-11-06 16:50:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 17
ERROR - 2023-11-06 16:50:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 20
ERROR - 2023-11-06 16:50:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 23
ERROR - 2023-11-06 16:50:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 26
ERROR - 2023-11-06 16:50:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 44
ERROR - 2023-11-06 16:50:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 48
ERROR - 2023-11-06 16:50:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 52
ERROR - 2023-11-06 16:50:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 52
ERROR - 2023-11-06 16:50:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 57
ERROR - 2023-11-06 16:50:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 193
ERROR - 2023-11-06 16:50:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 198
ERROR - 2023-11-06 16:50:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 396
ERROR - 2023-11-06 09:51:46 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-06 16:51:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 29
ERROR - 2023-11-06 16:51:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 30
ERROR - 2023-11-06 16:51:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 31
ERROR - 2023-11-06 16:51:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 32
ERROR - 2023-11-06 16:51:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 33
ERROR - 2023-11-06 16:51:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 3
ERROR - 2023-11-06 16:51:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 11
ERROR - 2023-11-06 16:51:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 14
ERROR - 2023-11-06 16:51:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 17
ERROR - 2023-11-06 16:51:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 20
ERROR - 2023-11-06 16:51:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 23
ERROR - 2023-11-06 16:51:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 26
ERROR - 2023-11-06 16:51:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 44
ERROR - 2023-11-06 16:51:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 48
ERROR - 2023-11-06 16:51:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 52
ERROR - 2023-11-06 16:51:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 52
ERROR - 2023-11-06 16:51:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 57
ERROR - 2023-11-06 16:51:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 193
ERROR - 2023-11-06 16:51:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 198
ERROR - 2023-11-06 16:51:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 396
ERROR - 2023-11-06 16:52:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 29
ERROR - 2023-11-06 16:52:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 30
ERROR - 2023-11-06 16:52:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 31
ERROR - 2023-11-06 16:52:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 32
ERROR - 2023-11-06 16:52:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 33
ERROR - 2023-11-06 16:52:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 3
ERROR - 2023-11-06 16:52:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 11
ERROR - 2023-11-06 16:52:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 14
ERROR - 2023-11-06 16:52:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 17
ERROR - 2023-11-06 16:52:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 20
ERROR - 2023-11-06 16:52:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 23
ERROR - 2023-11-06 16:52:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 26
ERROR - 2023-11-06 16:52:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 44
ERROR - 2023-11-06 16:52:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 48
ERROR - 2023-11-06 16:52:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 52
ERROR - 2023-11-06 16:52:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 52
ERROR - 2023-11-06 16:52:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 57
ERROR - 2023-11-06 16:52:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 193
ERROR - 2023-11-06 16:52:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 198
ERROR - 2023-11-06 16:52:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 396
ERROR - 2023-11-06 17:03:03 --> Severity: Notice --> Undefined property: Informasi_tender::$order_dokumen_dokumen_syarat_tambahan C:\laragon\www\jmto-eproc\system\core\Model.php 74
ERROR - 2023-11-06 17:03:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1192
ERROR - 2023-11-06 17:03:04 --> Severity: Notice --> Undefined property: Informasi_tender::$order_dokumen_dokumen_syarat_tambahan C:\laragon\www\jmto-eproc\system\core\Model.php 74
ERROR - 2023-11-06 17:03:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1192
ERROR - 2023-11-06 17:04:09 --> Severity: Notice --> Undefined property: Informasi_tender::$order_dokumen_dokumen_syarat_tambahan C:\laragon\www\jmto-eproc\system\core\Model.php 74
ERROR - 2023-11-06 17:04:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1192
ERROR - 2023-11-06 17:04:09 --> Severity: Notice --> Undefined property: Informasi_tender::$order_dokumen_dokumen_syarat_tambahan C:\laragon\www\jmto-eproc\system\core\Model.php 74
ERROR - 2023-11-06 17:04:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1192
ERROR - 2023-11-06 17:04:22 --> Severity: Notice --> Undefined property: Informasi_tender::$order_dokumen_dokumen_syarat_tambahan C:\laragon\www\jmto-eproc\system\core\Model.php 74
ERROR - 2023-11-06 17:04:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1192
ERROR - 2023-11-06 17:04:22 --> Severity: Notice --> Undefined property: Informasi_tender::$order_dokumen_dokumen_syarat_tambahan C:\laragon\www\jmto-eproc\system\core\Model.php 74
ERROR - 2023-11-06 17:04:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1192
ERROR - 2023-11-06 17:05:44 --> Query error: Unknown column 'tbl_vendor_mengikuti_paket.id_rup' in 'order clause' - Invalid query: SELECT *
FROM `tbl_vendor_syarat_tambahan`
WHERE `tbl_vendor_syarat_tambahan`.`id_rup` = '156'
AND `tbl_vendor_syarat_tambahan`.`id_vendor` = '156'
ORDER BY `tbl_vendor_mengikuti_paket`.`id_rup` DESC
 LIMIT 10
ERROR - 2023-11-06 17:08:52 --> Severity: Notice --> Undefined property: stdClass::$id_vendor_mengikuti_paket C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 383
ERROR - 2023-11-06 17:08:52 --> Severity: Notice --> Undefined property: stdClass::$id_vendor_mengikuti_paket C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 383
ERROR - 2023-11-06 17:11:17 --> Severity: Notice --> Undefined offset: 3 C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1214
ERROR - 2023-11-06 17:11:17 --> Severity: Notice --> Undefined offset: 3 C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1214
ERROR - 2023-11-06 17:19:28 --> Severity: Notice --> Undefined offset: 3 C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1151
ERROR - 2023-11-06 17:19:28 --> Severity: Notice --> Undefined offset: 3 C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1151
ERROR - 2023-11-06 17:30:07 --> Query error: Unknown column 'tbl_vendor_syarat_tambahan.id_vendor_mengikuti_paket' in 'where clause' - Invalid query: SELECT *
FROM `tbl_vendor_syarat_tambahan`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_syarat_tambahan`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_syarat_tambahan`.`id_vendor_mengikuti_paket` = '7'
ERROR - 2023-11-06 17:30:10 --> Query error: Unknown column 'tbl_vendor_syarat_tambahan.id_vendor_mengikuti_paket' in 'where clause' - Invalid query: SELECT *
FROM `tbl_vendor_syarat_tambahan`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_syarat_tambahan`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_syarat_tambahan`.`id_vendor_mengikuti_paket` = '7'
ERROR - 2023-11-06 17:42:06 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 262
ERROR - 2023-11-06 17:42:06 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 267
ERROR - 2023-11-06 17:42:06 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `nilai_penawaran` = NULL, `ev_penawaran_teknis` = NULL, `ev_penawaran_hps` = NAN, `ev_penawaran_biaya` = NAN
WHERE `id_vendor_mengikuti_paket` IS NULL
ERROR - 2023-11-06 17:42:10 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 262
ERROR - 2023-11-06 17:42:10 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 267
ERROR - 2023-11-06 17:42:10 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `nilai_penawaran` = NULL, `ev_penawaran_teknis` = NULL, `ev_penawaran_hps` = NAN, `ev_penawaran_biaya` = NAN
WHERE `id_vendor_mengikuti_paket` IS NULL
ERROR - 2023-11-06 11:05:02 --> 404 Page Not Found: File_paket/Testing%20paket%20terbaru%20(november)
ERROR - 2023-11-06 18:07:07 --> Query error: Unknown column 'tbl_vendor_syarat_tambahan.sts_validasi' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tbl_vendor_syarat_tambahan`
WHERE `tbl_vendor_syarat_tambahan`.`id_rup` = '156'
AND `tbl_vendor_syarat_tambahan`.`id_vendor` = '54'
AND `tbl_vendor_syarat_tambahan`.`sts_validasi` = 1
ERROR - 2023-11-06 18:14:30 --> Severity: Notice --> Undefined offset: 3 C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1151
ERROR - 2023-11-06 18:14:30 --> Severity: Notice --> Undefined offset: 3 C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1151
ERROR - 2023-11-06 11:23:34 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-06 23:47:33 --> Severity: error --> Exception: Call to undefined method M_panitia::gettable_evaluasi_hea_tkdn() C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 202
ERROR - 2023-11-06 16:49:08 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-06 23:49:25 --> Severity: error --> Exception: Call to undefined method M_panitia::gettable_evaluasi_hea_tkdn() C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 202
ERROR - 2023-11-06 23:50:30 --> Severity: error --> Exception: Call to undefined method M_panitia::gettable_evaluasi_hea_tkdn() C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 202
ERROR - 2023-11-06 23:53:00 --> Severity: error --> Exception: Call to undefined method M_panitia::gettable_evaluasi_hea_tkdn() C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 202

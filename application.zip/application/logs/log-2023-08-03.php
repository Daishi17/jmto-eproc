<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-03 00:36:01 --> Query error: Table 'u1064384_eprocjmto.tbl_unit_area' doesn't exist - Invalid query: SELECT RIGHT(tbl_unit_area.id_departemen, 3) as id_departemen
FROM `tbl_unit_area`
ORDER BY `id_departemen` DESC
 LIMIT 1
ERROR - 2023-08-03 00:36:27 --> Query error: Unknown column 'tbl_section.id_departemen' in 'field list' - Invalid query: SELECT RIGHT(tbl_section.id_departemen, 3) as id_departemen
FROM `tbl_section`
ORDER BY `id_departemen` DESC
 LIMIT 1
ERROR - 2023-08-03 01:25:49 --> Severity: error --> Exception: Too few arguments to function Fm_unit_kerja::byid(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_kerja.php 135
ERROR - 2023-08-03 01:31:48 --> Severity: error --> Exception: Too few arguments to function Fm_unit_kerja::byid(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_kerja.php 135
ERROR - 2023-08-03 01:31:58 --> Severity: error --> Exception: Too few arguments to function Fm_unit_kerja::byid(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_kerja.php 135
ERROR - 2023-08-03 01:44:37 --> Query error: Unknown column 'id_departemen' in 'field list' - Invalid query: INSERT INTO `tbl_section` (`kode_section`, `nama_section`, `id_departemen`, `user_created`, `sts_aktif`) VALUES ('201.001', 'test', '1', 'Administrator', 1)
ERROR - 2023-08-03 01:44:40 --> Query error: Unknown column 'id_departemen' in 'field list' - Invalid query: INSERT INTO `tbl_section` (`kode_section`, `nama_section`, `id_departemen`, `user_created`, `sts_aktif`) VALUES ('201.001', 'test', '1', 'Administrator', 1)
ERROR - 2023-08-03 01:44:50 --> Query error: Unknown column 'id_departemen' in 'field list' - Invalid query: INSERT INTO `tbl_section` (`kode_section`, `nama_section`, `id_departemen`, `user_created`, `sts_aktif`) VALUES ('201.001', 'test', '1', 'Administrator', 1)
ERROR - 2023-08-03 01:54:29 --> Severity: error --> Exception: Too few arguments to function Fm_unit_kerja::byid(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_kerja.php 135
ERROR - 2023-08-03 01:57:28 --> Severity: Notice --> Undefined property: stdClass::$id_section C:\laragon\www\jmto-eproc\application\models\M_master\M_unit_area.php 72
ERROR - 2023-08-03 01:57:33 --> Severity: Notice --> Undefined property: stdClass::$id_section C:\laragon\www\jmto-eproc\application\models\M_master\M_unit_area.php 72
ERROR - 2023-08-03 01:57:42 --> Severity: Notice --> Undefined property: stdClass::$id_section C:\laragon\www\jmto-eproc\application\models\M_master\M_unit_area.php 72
ERROR - 2023-08-03 01:57:58 --> Severity: Notice --> Undefined property: stdClass::$id_section C:\laragon\www\jmto-eproc\application\models\M_master\M_unit_area.php 72
ERROR - 2023-08-03 01:58:03 --> Severity: Notice --> Undefined property: stdClass::$id_section C:\laragon\www\jmto-eproc\application\models\M_master\M_unit_area.php 72
ERROR - 2023-08-03 01:58:09 --> Severity: Notice --> Undefined property: stdClass::$id_section C:\laragon\www\jmto-eproc\application\models\M_master\M_unit_area.php 72
ERROR - 2023-08-03 01:58:23 --> Query error: Unknown column 'tblsection.kode_section' in 'field list' - Invalid query: SELECT RIGHT(tblsection.kode_section, 3) as kode_section
FROM `tbl_section`
ORDER BY `id_section` DESC
 LIMIT 1
ERROR - 2023-08-03 01:58:50 --> Query error: Unknown column 'tblsection.kode_section' in 'field list' - Invalid query: SELECT LEFT(tblsection.kode_section, 3) as kode_section
FROM `tbl_section`
ORDER BY `id_section` DESC
 LIMIT 1
ERROR - 2023-08-03 01:58:55 --> Severity: Notice --> Undefined property: stdClass::$id_section C:\laragon\www\jmto-eproc\application\models\M_master\M_unit_area.php 72
ERROR - 2023-08-03 03:03:01 --> 404 Page Not Found: administrator/Fm_unit_kerja/datatable_section
ERROR - 2023-08-03 03:03:05 --> 404 Page Not Found: administrator/Fm_unit_kerja/datatable_section
ERROR - 2023-08-03 03:03:17 --> 404 Page Not Found: administrator/Fm_unit_kerja/datatable_section
ERROR - 2023-08-03 03:29:07 --> Query error: Column 'sts_aktif' in order clause is ambiguous - Invalid query: SELECT *
FROM `tbl_section`
LEFT JOIN `tbl_departemen` ON `tbl_section`.`id_departemen` = `tbl_departemen`.`id_departemen`
ORDER BY `sts_aktif` ASC
 LIMIT 10
ERROR - 2023-08-03 03:54:20 --> Query error: Unknown column 'user_edited' in 'field list' - Invalid query: UPDATE `tbl_section` SET `kode_section` = NULL, `nama_section` = 'test', `id_departemen` = '1', `user_edited` = 'Administrator', `time_edited` = '2023-08-03 03:54', `sts_aktif` = 1
WHERE `id_section` = '1'
ERROR - 2023-08-03 03:54:25 --> Query error: Unknown column 'user_edited' in 'field list' - Invalid query: UPDATE `tbl_section` SET `kode_section` = NULL, `nama_section` = 'test', `id_departemen` = '1', `user_edited` = 'Administrator', `time_edited` = '2023-08-03 03:54', `sts_aktif` = 1
WHERE `id_section` = '1'
ERROR - 2023-08-03 04:10:02 --> Severity: error --> Exception: Too few arguments to function Fm_unit_kerja::byid(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_kerja.php 135
ERROR - 2023-08-03 04:11:32 --> Severity: Notice --> Undefined variable: response C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_area.php 75
ERROR - 2023-08-03 04:46:16 --> Severity: Notice --> Undefined property: Fm_karyawan::$M_unit_area C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_karyawan.php 25
ERROR - 2023-08-03 04:46:16 --> Severity: error --> Exception: Call to a member function getdatatable() on null C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_karyawan.php 25
ERROR - 2023-08-03 04:46:45 --> Query error: Column 'id_section' in order clause is ambiguous - Invalid query: SELECT *
FROM `tbl_pegawai`
LEFT JOIN `tbl_departemen` ON `tbl_pegawai`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_pegawai`.`id_section` = `tbl_section`.`id_section`
ORDER BY `id_section` DESC
 LIMIT 10
ERROR - 2023-08-03 05:25:32 --> Query error: Unknown column 'id_url' in 'field list' - Invalid query: INSERT INTO `tbl_pegawai` (`nip`, `id_url`, `nama_pegawai`, `id_departemen`, `id_section`, `email`, `no_telpon`, `id_role`, `password`, `status`, `user_created`) VALUES ('567', 'f6c64c2e86d94ce295a7bb98eeb5e099', 'Pegawai Kehidupan dua', '2', '2', 'test@gmail.com', '124124', '4', '$2y$10$ETrz13bQKgZCu02T51NdduMOMVSC0T8aOvtWEOyp8h1HIKPxnKJgO', 1, 'Administrator')

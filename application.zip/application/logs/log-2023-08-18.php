<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-18 01:17:49 --> Severity: Notice --> Undefined property: Fm_jenis_jadwal::$M_Jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 17
ERROR - 2023-08-18 01:17:49 --> Severity: error --> Exception: Call to a member function gettable_rup_paket() on null C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 17
ERROR - 2023-08-18 01:17:54 --> Severity: Notice --> Undefined property: Fm_jenis_jadwal::$M_Jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 17
ERROR - 2023-08-18 01:17:54 --> Severity: error --> Exception: Call to a member function gettable_rup_paket() on null C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 17
ERROR - 2023-08-18 01:18:10 --> Severity: Notice --> Undefined property: Fm_jenis_jadwal::$M_Jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 17
ERROR - 2023-08-18 01:18:10 --> Severity: error --> Exception: Call to a member function gettable_rup_paket() on null C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 17
ERROR - 2023-08-18 01:18:58 --> Severity: Notice --> Undefined property: Fm_jenis_jadwal::$M_Jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 17
ERROR - 2023-08-18 01:18:58 --> Severity: error --> Exception: Call to a member function gettable_rup_paket() on null C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 17
ERROR - 2023-08-18 01:19:07 --> Severity: Notice --> Undefined property: Fm_jenis_jadwal::$M_Jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 17
ERROR - 2023-08-18 01:19:07 --> Severity: error --> Exception: Call to a member function gettable_rup_paket() on null C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 17
ERROR - 2023-08-18 01:19:21 --> Severity: error --> Exception: Call to undefined method M_Jadwal::gettable_rup_paket() C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 23
ERROR - 2023-08-18 01:19:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 41
ERROR - 2023-08-18 01:19:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 43
ERROR - 2023-08-18 01:19:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 41
ERROR - 2023-08-18 01:19:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 43
ERROR - 2023-08-18 01:19:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 41
ERROR - 2023-08-18 01:19:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 43
ERROR - 2023-08-18 01:19:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 41
ERROR - 2023-08-18 01:19:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 43
ERROR - 2023-08-18 01:19:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 41
ERROR - 2023-08-18 01:19:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 43
ERROR - 2023-08-18 01:19:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 41
ERROR - 2023-08-18 01:19:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 43
ERROR - 2023-08-18 01:19:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 41
ERROR - 2023-08-18 01:19:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 43
ERROR - 2023-08-18 01:19:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 41
ERROR - 2023-08-18 01:19:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 43
ERROR - 2023-08-18 01:19:36 --> Severity: error --> Exception: Call to undefined method M_Jadwal::count_all_rup_paket() C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 59
ERROR - 2023-08-18 01:19:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:19:46 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 41
ERROR - 2023-08-18 01:19:46 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 43
ERROR - 2023-08-18 01:19:46 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 41
ERROR - 2023-08-18 01:19:46 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 43
ERROR - 2023-08-18 01:19:46 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 41
ERROR - 2023-08-18 01:19:46 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 43
ERROR - 2023-08-18 01:19:46 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 41
ERROR - 2023-08-18 01:19:46 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 43
ERROR - 2023-08-18 01:19:46 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 41
ERROR - 2023-08-18 01:19:46 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 43
ERROR - 2023-08-18 01:19:46 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 41
ERROR - 2023-08-18 01:19:46 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 43
ERROR - 2023-08-18 01:19:46 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 41
ERROR - 2023-08-18 01:19:46 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 43
ERROR - 2023-08-18 01:19:46 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 41
ERROR - 2023-08-18 01:19:46 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 43
ERROR - 2023-08-18 01:19:46 --> Severity: error --> Exception: Call to undefined method M_Jadwal::count_all_rup_paket() C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 59
ERROR - 2023-08-18 01:19:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:19:52 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 41
ERROR - 2023-08-18 01:19:52 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 43
ERROR - 2023-08-18 01:19:52 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 41
ERROR - 2023-08-18 01:19:52 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 43
ERROR - 2023-08-18 01:19:52 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 41
ERROR - 2023-08-18 01:19:52 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 43
ERROR - 2023-08-18 01:19:52 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 41
ERROR - 2023-08-18 01:19:52 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 43
ERROR - 2023-08-18 01:19:52 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 41
ERROR - 2023-08-18 01:19:52 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 43
ERROR - 2023-08-18 01:19:52 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 41
ERROR - 2023-08-18 01:19:52 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 43
ERROR - 2023-08-18 01:19:52 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 41
ERROR - 2023-08-18 01:19:52 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 43
ERROR - 2023-08-18 01:19:52 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 41
ERROR - 2023-08-18 01:19:52 --> Severity: Notice --> Undefined property: stdClass::$id_url_rup C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 43
ERROR - 2023-08-18 01:19:52 --> Severity: error --> Exception: Call to undefined method M_Jadwal::count_all_rup_paket() C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 59
ERROR - 2023-08-18 01:19:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:20:31 --> Severity: error --> Exception: Call to undefined method M_Jadwal::count_all_rup_paket() C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 59
ERROR - 2023-08-18 01:37:11 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 74
ERROR - 2023-08-18 01:37:11 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 74
ERROR - 2023-08-18 01:37:11 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 74
ERROR - 2023-08-18 01:37:11 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 74
ERROR - 2023-08-18 01:37:11 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 74
ERROR - 2023-08-18 01:37:11 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 74
ERROR - 2023-08-18 01:37:11 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 74
ERROR - 2023-08-18 01:37:11 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 74
ERROR - 2023-08-18 01:37:11 --> Severity: Notice --> Undefined index:  draw  C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 79
ERROR - 2023-08-18 01:37:19 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 74
ERROR - 2023-08-18 01:37:19 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 74
ERROR - 2023-08-18 01:37:19 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 74
ERROR - 2023-08-18 01:37:19 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 74
ERROR - 2023-08-18 01:37:19 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 74
ERROR - 2023-08-18 01:37:19 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 74
ERROR - 2023-08-18 01:37:19 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 74
ERROR - 2023-08-18 01:37:19 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 74
ERROR - 2023-08-18 01:37:19 --> Severity: Notice --> Undefined index:  draw  C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 79
ERROR - 2023-08-18 01:37:34 --> Severity: Notice --> Undefined index:  draw  C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 79
ERROR - 2023-08-18 01:42:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMI...' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25
ERROR - 2023-08-18 01:42:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMI...' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25
ERROR - 2023-08-18 01:42:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMI...' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25
ERROR - 2023-08-18 01:43:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMI...' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25
ERROR - 2023-08-18 01:43:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:43:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:43:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:43:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:43:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:43:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:43:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:43:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:43:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:43:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:43:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:43:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:43:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:43:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:43:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:43:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:43:37 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 104
ERROR - 2023-08-18 01:43:37 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:43:37 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:43:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 01:43:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:46:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMI...' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25
ERROR - 2023-08-18 01:46:05 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:46:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:46:05 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:46:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:46:05 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 104
ERROR - 2023-08-18 01:46:05 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:46:05 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:46:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 01:46:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:46:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMI...' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25
ERROR - 2023-08-18 01:46:56 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:46:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:46:56 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:46:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:46:56 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:46:56 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:46:56 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:46:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 01:46:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:47:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMI...' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25
ERROR - 2023-08-18 01:47:42 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:47:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:47:42 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:47:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:47:42 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:47:42 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:47:42 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:47:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 01:47:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:48:02 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:48:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:48:02 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:48:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:48:02 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:48:02 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:48:02 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:48:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 01:48:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:48:16 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:48:16 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:48:16 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:48:16 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:48:16 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:48:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 01:48:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:48:17 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:48:17 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:48:17 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:48:17 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:48:17 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:48:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 01:48:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:48:18 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:48:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:48:18 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:48:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:48:18 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:48:18 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:48:18 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:48:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 01:48:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:48:18 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:48:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:48:18 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:48:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:48:18 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:48:18 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:48:18 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:48:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 01:48:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:48:18 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:48:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:48:18 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:48:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:48:18 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:48:18 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:48:18 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:48:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 01:48:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:48:19 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:48:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:48:19 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:48:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:48:19 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:48:19 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:48:19 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:48:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 01:48:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:49:17 --> Severity: error --> Exception: Call to undefined method M_Jadwal::getdatatable2() C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 68
ERROR - 2023-08-18 01:49:27 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:49:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:49:27 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:49:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:49:27 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:49:27 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:49:27 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:49:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 01:49:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:50:09 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:50:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:50:09 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:50:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:50:09 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:50:09 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:50:09 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:50:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 01:50:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:50:53 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:50:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:50:53 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:50:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:50:53 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:50:53 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:50:53 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:50:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 01:50:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:51:21 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:51:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:51:21 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:51:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:51:21 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:51:21 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:51:21 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:51:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tendr`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 01:51:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:51:40 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:51:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:51:40 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:51:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:51:40 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:51:40 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:51:40 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:51:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 01:51:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:51:49 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:51:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:51:49 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:51:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:51:49 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:51:49 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:51:49 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:51:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_jadwal_tender` ASC
ERROR - 2023-08-18 01:51:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:51:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:51:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:51:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:51:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:51:50 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:51:50 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:51:50 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:51:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_jadwal_tender` ASC
ERROR - 2023-08-18 01:51:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:52:06 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:52:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:52:06 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:52:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:52:06 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:52:06 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:52:06 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:52:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `tbl_detail_jadwal_tender`.`id_jadwal_tender` = '1'
ORDER BY `id_jadw...' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `tbl_detail_jadwal_tender`.`id_jadwal_tender` = '1'
ORDER BY `id_jadwal_tender` ASC
ERROR - 2023-08-18 01:52:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:52:11 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:52:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:52:11 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:52:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:52:11 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:52:11 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:52:11 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:52:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_jadwal_tender` ASC
ERROR - 2023-08-18 01:52:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:52:26 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:52:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:52:26 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:52:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:52:26 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:52:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:52:26 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:52:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:52:26 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:52:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:52:26 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:52:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:52:26 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:52:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:52:26 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:52:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:52:26 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:52:26 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:52:26 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:52:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1)
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_jadwal_tender`.`id_jenis_pengadaan...' at line 2 - Invalid query: SELECT *
FROM (`tbl_jadwal_tender`, 1)
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_jadwal_tender`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_jadwal_tender`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
ORDER BY `kode_jadwal` ASC
ERROR - 2023-08-18 01:52:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:52:42 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:52:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:52:42 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:52:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:52:42 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:52:42 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:52:42 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:52:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_jadwal_tender` ASC
ERROR - 2023-08-18 01:52:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:53:03 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:53:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:53:03 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:53:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:53:03 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:53:03 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:53:03 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:53:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_jadwal_tender` ASC
ERROR - 2023-08-18 01:53:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:53:04 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:53:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:53:04 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:53:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:53:04 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:53:04 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:53:04 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:53:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_jadwal_tender` ASC
ERROR - 2023-08-18 01:53:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:53:07 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:53:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:53:07 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:53:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:53:07 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:53:07 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:53:07 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:53:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_jadwal_tender` ASC
ERROR - 2023-08-18 01:53:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:53:30 --> Severity: error --> Exception: Too few arguments to function Fm_jenis_jadwal::get_jadwal2(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 66
ERROR - 2023-08-18 01:53:33 --> Severity: error --> Exception: Too few arguments to function Fm_jenis_jadwal::get_jadwal2(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 66
ERROR - 2023-08-18 01:53:57 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:53:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:53:57 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:53:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:53:57 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 104
ERROR - 2023-08-18 01:53:57 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:53:57 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:53:57 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 70
ERROR - 2023-08-18 01:53:57 --> Severity: Notice --> Undefined index: draw C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 78
ERROR - 2023-08-18 01:53:57 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:53:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:53:57 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:53:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:54:41 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:54:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:54:41 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:54:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:54:41 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 104
ERROR - 2023-08-18 01:54:41 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:54:41 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:54:41 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 70
ERROR - 2023-08-18 01:54:41 --> Severity: Notice --> Undefined index: draw C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 78
ERROR - 2023-08-18 01:54:41 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:54:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:54:41 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:54:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:55:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25
ERROR - 2023-08-18 01:55:05 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:55:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:55:05 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:55:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 75
ERROR - 2023-08-18 01:55:05 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 104
ERROR - 2023-08-18 01:55:05 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:55:05 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:55:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 01:55:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:55:24 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:55:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:55:24 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:55:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:55:24 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:55:24 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:55:24 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:55:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 01:55:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:56:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMI...' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25
ERROR - 2023-08-18 01:56:20 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:56:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:56:20 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:56:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:56:20 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:56:20 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:56:20 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:56:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 01:56:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:56:55 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:56:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:56:55 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:56:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:56:55 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:56:55 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:56:55 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:56:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = 2
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = 2
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 01:56:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:57:00 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:57:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:57:00 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:57:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:57:00 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:57:00 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:57:00 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:57:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 01:57:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:57:44 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:57:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:57:44 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:57:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:57:44 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:57:44 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:57:44 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:57:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender3`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 01:57:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:57:54 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:57:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:57:54 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:57:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:57:54 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:57:54 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:57:54 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:57:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 01:57:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:57:56 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:57:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:57:56 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:57:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:57:56 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:57:56 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:57:56 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:57:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '2
WHERE `id_jadwal_tender` = '2'
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 2
WHERE `id_jadwal_tender` = '2'
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 01:57:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:58:26 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:58:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:58:26 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:58:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:58:26 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:58:26 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:58:26 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:58:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '2
WHERE `id_jadwal_tender` = '2'
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 2
WHERE `id_jadwal_tender` = '2'
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 01:58:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:59:06 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:59:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:59:06 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:59:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:59:06 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:59:06 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:59:06 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:59:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '2
WHERE `id_jadwal_tender` = '2'
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 2
WHERE `id_jadwal_tender` = '2'
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 01:59:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:59:12 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:59:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:59:12 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:59:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:59:12 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:59:12 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:59:12 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:59:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '2
WHERE `id_jadwal_tender` = '2'
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 2
WHERE `id_jadwal_tender` = '2'
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 01:59:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 01:59:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMI...' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25
ERROR - 2023-08-18 01:59:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMI...' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25
ERROR - 2023-08-18 01:59:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMI...' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25
ERROR - 2023-08-18 01:59:48 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:59:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:59:48 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:59:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 01:59:48 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 01:59:48 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:59:48 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 01:59:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 01:59:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 02:00:47 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:00:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:00:47 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:00:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:00:47 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 02:00:47 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 02:00:47 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 02:00:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 02:00:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 02:01:02 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:01:02 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:01:02 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 02:01:02 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 02:01:02 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 02:01:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '2
WHERE `id_jadwal_tender` = '2'
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 2
WHERE `id_jadwal_tender` = '2'
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 02:01:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 02:01:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:01:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:01:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:01:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:01:37 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 02:01:37 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 02:01:37 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 02:01:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '2
WHERE `id_jadwal_tender` = '2'
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 2
WHERE `id_jadwal_tender` = '2'
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 02:01:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 02:01:39 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:01:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:01:39 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:01:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:01:39 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 02:01:39 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 02:01:39 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 02:01:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '2
WHERE `id_jadwal_tender` = '2'
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 2
WHERE `id_jadwal_tender` = '2'
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 02:01:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 02:01:44 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:01:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:01:44 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:01:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:01:44 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 02:01:44 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 02:01:44 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 02:01:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 02:01:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 02:02:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:02:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:02:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:02:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:02:37 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 02:02:37 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 02:02:37 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 02:02:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 02:02:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 02:02:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMI...' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25
ERROR - 2023-08-18 02:03:03 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:03:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:03:03 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:03:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:03:03 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 02:03:03 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 02:03:03 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 02:03:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
ERROR - 2023-08-18 02:03:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 02:04:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMI...' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25
ERROR - 2023-08-18 02:05:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25
ERROR - 2023-08-18 02:06:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25
ERROR - 2023-08-18 02:10:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMI...' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25
ERROR - 2023-08-18 02:12:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMI...' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25
ERROR - 2023-08-18 02:12:07 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:12:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:12:07 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:12:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:12:07 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 02:12:07 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 02:12:07 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 02:12:07 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 71
ERROR - 2023-08-18 02:12:07 --> Severity: Notice --> Undefined index: draw C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 79
ERROR - 2023-08-18 02:12:07 --> Severity: error --> Exception: Call to undefined method M_Jadwal::_get_data_query2() C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 113
ERROR - 2023-08-18 02:12:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 02:12:22 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:12:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:12:22 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:12:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:12:22 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 105
ERROR - 2023-08-18 02:12:22 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 02:12:22 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 106
ERROR - 2023-08-18 02:12:22 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 71
ERROR - 2023-08-18 02:12:22 --> Severity: Notice --> Undefined index: draw C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 79
ERROR - 2023-08-18 02:12:22 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:12:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:12:22 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:12:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 76
ERROR - 2023-08-18 02:12:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMI...' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25
ERROR - 2023-08-18 02:15:46 --> Severity: error --> Exception: Too few arguments to function M_Jadwal::getdatatable2(), 0 passed in C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php on line 69 and exactly 1 expected C:\laragon\www\jmto-eproc\application\models\M_master\M_Jadwal.php 102
ERROR - 2023-08-18 02:16:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '2
WHERE `id_jadwal_tender` = 2
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 2
WHERE `id_jadwal_tender` = 2
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25
ERROR - 2023-08-18 02:17:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '2
WHERE `id_jadwal_tender` = 2
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 2
WHERE `id_jadwal_tender` = 2
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25
ERROR - 2023-08-18 02:17:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '2
WHERE `id_jadwal_tender` = 2
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 2
WHERE `id_jadwal_tender` = 2
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25
ERROR - 2023-08-18 02:17:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '2
WHERE `id_jadwal_tender` = 2
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 2
WHERE `id_jadwal_tender` = 2
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25
ERROR - 2023-08-18 02:20:18 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 75
ERROR - 2023-08-18 02:20:18 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 75
ERROR - 2023-08-18 02:20:18 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 75
ERROR - 2023-08-18 02:20:18 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 75
ERROR - 2023-08-18 02:20:18 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 75
ERROR - 2023-08-18 02:20:18 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 75
ERROR - 2023-08-18 02:20:18 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 75
ERROR - 2023-08-18 02:20:18 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 75
ERROR - 2023-08-18 02:20:18 --> Query error: Unknown column 'kode_section' in 'order clause' - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`
WHERE `tbl_detail_jadwal_tender`.`id_jadwal_tender` = 2
ORDER BY `kode_section` ASC
ERROR - 2023-08-18 02:20:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2023-08-18 02:20:43 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 75
ERROR - 2023-08-18 02:20:43 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 75
ERROR - 2023-08-18 02:20:43 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 75
ERROR - 2023-08-18 02:20:43 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 75
ERROR - 2023-08-18 02:20:43 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 75
ERROR - 2023-08-18 02:20:43 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 75
ERROR - 2023-08-18 02:20:43 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 75
ERROR - 2023-08-18 02:20:43 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 75
ERROR - 2023-08-18 02:21:56 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 75
ERROR - 2023-08-18 02:21:56 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 75
ERROR - 2023-08-18 02:21:56 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 75
ERROR - 2023-08-18 02:21:56 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 75
ERROR - 2023-08-18 02:21:56 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 75
ERROR - 2023-08-18 02:21:56 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 75
ERROR - 2023-08-18 02:21:56 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 75
ERROR - 2023-08-18 02:21:56 --> Severity: Notice --> Undefined property: stdClass::$nama_jadwal C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_jenis_jadwal.php 75
ERROR - 2023-08-18 02:25:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '2
WHERE `id_jadwal_tender` = '2'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMI...' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 2
WHERE `id_jadwal_tender` = '2'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25
ERROR - 2023-08-18 02:25:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `tbl_detail_jadwal_tender`.`id_jadwal_tender` = '1'
ORDER BY `id_deta...' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `tbl_detail_jadwal_tender`.`id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25
ERROR - 2023-08-18 02:25:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `tbl_detail_jadwal_tender`.`id_jadwal_tender` = '1'
ORDER BY `id_deta...' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `tbl_detail_jadwal_tender`.`id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25
ERROR - 2023-08-18 02:26:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
WHERE `tbl_detail_jadwal_tender`.`id_jadwal_tender` = '1'
ORDER BY `id_deta...' at line 2 - Invalid query: SELECT *
FROM `tbl_detail_jadwal_tender`, 1
WHERE `tbl_detail_jadwal_tender`.`id_jadwal_tender` = '1'
ORDER BY `id_detail_jadwal_tender` ASC
 LIMIT 25

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-27 15:11:07 --> Severity: error --> Exception: Call to undefined method M_Rekanan_terundang::get_result_siup_kbli() C:\laragon\www\jmto-eproc\application\controllers\validator\Rekanan_terundang.php 256

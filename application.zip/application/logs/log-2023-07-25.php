<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-25 08:22:40 --> 404 Page Not Found: Images/bg

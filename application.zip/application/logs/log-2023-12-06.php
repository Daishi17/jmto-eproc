<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-06 11:17:46 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\xampp\htdocs\jmto-eproc\application\libraries\Role_login.php 21
ERROR - 2023-12-06 12:21:24 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor`
LEFT JOIN `tbl_provinsi` ON `tbl_vendor`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kecamatan` ON `tbl_vendor`.`id_kecamatan` = `tbl_kecamatan`.`id_kecamatan`
LEFT JOIN `tbl_kabupaten` ON `tbl_vendor`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
WHERE `tbl_vendor`.`sts_aktif` = 1
AND `tbl_vendor`.`sts_terundang` IS NULL
ORDER BY `tbl_vendor`.`id_vendor` ASC
 LIMIT 10
ERROR - 2023-12-06 12:21:32 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor`
LEFT JOIN `tbl_provinsi` ON `tbl_vendor`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kecamatan` ON `tbl_vendor`.`id_kecamatan` = `tbl_kecamatan`.`id_kecamatan`
LEFT JOIN `tbl_kabupaten` ON `tbl_vendor`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
WHERE `tbl_vendor`.`sts_aktif` = 1
AND `tbl_vendor`.`sts_terundang` IS NULL
AND   (
`id_vendor` LIKE '%aliba%' ESCAPE '!'
OR  `nama_usaha` LIKE '%aliba%' ESCAPE '!'
OR  `id_jenis_usaha` LIKE '%aliba%' ESCAPE '!'
OR  `bentuk_usaha` LIKE '%aliba%' ESCAPE '!'
OR  `kualifikasi_usaha` LIKE '%aliba%' ESCAPE '!'
OR  `tgl_daftar` LIKE '%aliba%' ESCAPE '!'
OR  `id_vendor` LIKE '%aliba%' ESCAPE '!'
 )
ORDER BY `tbl_vendor`.`id_vendor` ASC
 LIMIT 10
ERROR - 2023-12-06 12:21:32 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor`
LEFT JOIN `tbl_provinsi` ON `tbl_vendor`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kecamatan` ON `tbl_vendor`.`id_kecamatan` = `tbl_kecamatan`.`id_kecamatan`
LEFT JOIN `tbl_kabupaten` ON `tbl_vendor`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
WHERE `tbl_vendor`.`sts_aktif` = 1
AND `tbl_vendor`.`sts_terundang` IS NULL
AND   (
`id_vendor` LIKE '%alibab%' ESCAPE '!'
OR  `nama_usaha` LIKE '%alibab%' ESCAPE '!'
OR  `id_jenis_usaha` LIKE '%alibab%' ESCAPE '!'
OR  `bentuk_usaha` LIKE '%alibab%' ESCAPE '!'
OR  `kualifikasi_usaha` LIKE '%alibab%' ESCAPE '!'
OR  `tgl_daftar` LIKE '%alibab%' ESCAPE '!'
OR  `id_vendor` LIKE '%alibab%' ESCAPE '!'
 )
ORDER BY `tbl_vendor`.`id_vendor` ASC
 LIMIT 10
ERROR - 2023-12-06 12:37:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IN('NULL', '0')
ORDER BY `tbl_vendor`.`id_vendor` ASC
 LIMIT 10' at line 7 - Invalid query: SELECT *
FROM `tbl_vendor`
LEFT JOIN `tbl_provinsi` ON `tbl_vendor`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kecamatan` ON `tbl_vendor`.`id_kecamatan` = `tbl_kecamatan`.`id_kecamatan`
LEFT JOIN `tbl_kabupaten` ON `tbl_vendor`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
WHERE `tbl_vendor`.`sts_aktif` = 1
AND `tbl_vendor`.`sts_terundang` = IN('NULL', '0')
ORDER BY `tbl_vendor`.`id_vendor` ASC
 LIMIT 10
ERROR - 2023-12-06 12:37:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IN('(NULL)', '0')
ORDER BY `tbl_vendor`.`id_vendor` ASC
 LIMIT 10' at line 7 - Invalid query: SELECT *
FROM `tbl_vendor`
LEFT JOIN `tbl_provinsi` ON `tbl_vendor`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kecamatan` ON `tbl_vendor`.`id_kecamatan` = `tbl_kecamatan`.`id_kecamatan`
LEFT JOIN `tbl_kabupaten` ON `tbl_vendor`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
WHERE `tbl_vendor`.`sts_aktif` = 1
AND `tbl_vendor`.`sts_terundang` = IN('(NULL)', '0')
ORDER BY `tbl_vendor`.`id_vendor` ASC
 LIMIT 10
ERROR - 2023-12-06 13:37:27 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor`
LEFT JOIN `tbl_provinsi` ON `tbl_vendor`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kecamatan` ON `tbl_vendor`.`id_kecamatan` = `tbl_kecamatan`.`id_kecamatan`
LEFT JOIN `tbl_kabupaten` ON `tbl_vendor`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
WHERE `tbl_vendor`.`sts_aktif` = 1
AND `tbl_vendor`.`sts_terundang` IS NULL
AND   (
`id_vendor` LIKE '%p%' ESCAPE '!'
OR  `nama_usaha` LIKE '%p%' ESCAPE '!'
OR  `id_jenis_usaha` LIKE '%p%' ESCAPE '!'
OR  `bentuk_usaha` LIKE '%p%' ESCAPE '!'
OR  `kualifikasi_usaha` LIKE '%p%' ESCAPE '!'
OR  `tgl_daftar` LIKE '%p%' ESCAPE '!'
OR  `id_vendor` LIKE '%p%' ESCAPE '!'
 )
ORDER BY `tbl_vendor`.`id_vendor` ASC
 LIMIT 10
ERROR - 2023-12-06 13:37:27 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor`
LEFT JOIN `tbl_provinsi` ON `tbl_vendor`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kecamatan` ON `tbl_vendor`.`id_kecamatan` = `tbl_kecamatan`.`id_kecamatan`
LEFT JOIN `tbl_kabupaten` ON `tbl_vendor`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
WHERE `tbl_vendor`.`sts_aktif` = 1
AND `tbl_vendor`.`sts_terundang` IS NULL
AND   (
`id_vendor` LIKE '%pras%' ESCAPE '!'
OR  `nama_usaha` LIKE '%pras%' ESCAPE '!'
OR  `id_jenis_usaha` LIKE '%pras%' ESCAPE '!'
OR  `bentuk_usaha` LIKE '%pras%' ESCAPE '!'
OR  `kualifikasi_usaha` LIKE '%pras%' ESCAPE '!'
OR  `tgl_daftar` LIKE '%pras%' ESCAPE '!'
OR  `id_vendor` LIKE '%pras%' ESCAPE '!'
 )
ORDER BY `tbl_vendor`.`id_vendor` ASC
 LIMIT 10
ERROR - 2023-12-06 13:38:08 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor`
LEFT JOIN `tbl_provinsi` ON `tbl_vendor`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kecamatan` ON `tbl_vendor`.`id_kecamatan` = `tbl_kecamatan`.`id_kecamatan`
LEFT JOIN `tbl_kabupaten` ON `tbl_vendor`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
WHERE `tbl_vendor`.`sts_aktif` = 1
AND `tbl_vendor`.`sts_terundang` IS NULL
AND   (
`id_vendor` LIKE '%ali%' ESCAPE '!'
OR  `nama_usaha` LIKE '%ali%' ESCAPE '!'
OR  `id_jenis_usaha` LIKE '%ali%' ESCAPE '!'
OR  `bentuk_usaha` LIKE '%ali%' ESCAPE '!'
OR  `kualifikasi_usaha` LIKE '%ali%' ESCAPE '!'
OR  `tgl_daftar` LIKE '%ali%' ESCAPE '!'
OR  `id_vendor` LIKE '%ali%' ESCAPE '!'
 )
ORDER BY `tbl_vendor`.`id_vendor` ASC
 LIMIT 10
ERROR - 2023-12-06 13:57:57 --> Unable to connect to the database
ERROR - 2023-12-06 13:58:06 --> Unable to connect to the database
ERROR - 2023-12-06 13:58:19 --> Unable to connect to the database
ERROR - 2023-12-06 13:59:07 --> Unable to connect to the database
ERROR - 2023-12-06 09:39:08 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-06 09:39:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-06 09:39:08 --> Unable to connect to the database
ERROR - 2023-12-06 10:42:53 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-06 10:42:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-06 10:42:53 --> Unable to connect to the database
ERROR - 2023-12-06 17:10:45 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor`
LEFT JOIN `tbl_provinsi` ON `tbl_vendor`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kecamatan` ON `tbl_vendor`.`id_kecamatan` = `tbl_kecamatan`.`id_kecamatan`
LEFT JOIN `tbl_kabupaten` ON `tbl_vendor`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
WHERE `tbl_vendor`.`sts_aktif` = 1
AND `tbl_vendor`.`sts_terundang` IS NULL
AND   (
`id_vendor` LIKE '%ali%' ESCAPE '!'
OR  `nama_usaha` LIKE '%ali%' ESCAPE '!'
OR  `id_jenis_usaha` LIKE '%ali%' ESCAPE '!'
OR  `bentuk_usaha` LIKE '%ali%' ESCAPE '!'
OR  `kualifikasi_usaha` LIKE '%ali%' ESCAPE '!'
OR  `tgl_daftar` LIKE '%ali%' ESCAPE '!'
OR  `id_vendor` LIKE '%ali%' ESCAPE '!'
 )
ORDER BY `tbl_vendor`.`id_vendor` ASC
 LIMIT 10
ERROR - 2023-12-06 17:10:45 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor`
LEFT JOIN `tbl_provinsi` ON `tbl_vendor`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kecamatan` ON `tbl_vendor`.`id_kecamatan` = `tbl_kecamatan`.`id_kecamatan`
LEFT JOIN `tbl_kabupaten` ON `tbl_vendor`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
WHERE `tbl_vendor`.`sts_aktif` = 1
AND `tbl_vendor`.`sts_terundang` IS NULL
AND   (
`id_vendor` LIKE '%alibab%' ESCAPE '!'
OR  `nama_usaha` LIKE '%alibab%' ESCAPE '!'
OR  `id_jenis_usaha` LIKE '%alibab%' ESCAPE '!'
OR  `bentuk_usaha` LIKE '%alibab%' ESCAPE '!'
OR  `kualifikasi_usaha` LIKE '%alibab%' ESCAPE '!'
OR  `tgl_daftar` LIKE '%alibab%' ESCAPE '!'
OR  `id_vendor` LIKE '%alibab%' ESCAPE '!'
 )
ORDER BY `tbl_vendor`.`id_vendor` ASC
 LIMIT 10
ERROR - 2023-12-06 17:23:30 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor`
LEFT JOIN `tbl_provinsi` ON `tbl_vendor`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kecamatan` ON `tbl_vendor`.`id_kecamatan` = `tbl_kecamatan`.`id_kecamatan`
LEFT JOIN `tbl_kabupaten` ON `tbl_vendor`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
WHERE `tbl_vendor`.`sts_aktif` = 1
AND `tbl_vendor`.`sts_terundang` IS NULL
AND   (
`id_vendor` LIKE '%l%' ESCAPE '!'
OR  `nama_usaha` LIKE '%l%' ESCAPE '!'
OR  `id_jenis_usaha` LIKE '%l%' ESCAPE '!'
OR  `bentuk_usaha` LIKE '%l%' ESCAPE '!'
OR  `kualifikasi_usaha` LIKE '%l%' ESCAPE '!'
OR  `tgl_daftar` LIKE '%l%' ESCAPE '!'
OR  `id_vendor` LIKE '%l%' ESCAPE '!'
 )
ORDER BY `tbl_vendor`.`id_vendor` ASC
 LIMIT 10
ERROR - 2023-12-06 17:23:30 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor`
LEFT JOIN `tbl_provinsi` ON `tbl_vendor`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kecamatan` ON `tbl_vendor`.`id_kecamatan` = `tbl_kecamatan`.`id_kecamatan`
LEFT JOIN `tbl_kabupaten` ON `tbl_vendor`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
WHERE `tbl_vendor`.`sts_aktif` = 1
AND `tbl_vendor`.`sts_terundang` IS NULL
AND   (
`id_vendor` LIKE '%lib%' ESCAPE '!'
OR  `nama_usaha` LIKE '%lib%' ESCAPE '!'
OR  `id_jenis_usaha` LIKE '%lib%' ESCAPE '!'
OR  `bentuk_usaha` LIKE '%lib%' ESCAPE '!'
OR  `kualifikasi_usaha` LIKE '%lib%' ESCAPE '!'
OR  `tgl_daftar` LIKE '%lib%' ESCAPE '!'
OR  `id_vendor` LIKE '%lib%' ESCAPE '!'
 )
ORDER BY `tbl_vendor`.`id_vendor` ASC
 LIMIT 10
ERROR - 2023-12-06 17:23:40 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor`
LEFT JOIN `tbl_provinsi` ON `tbl_vendor`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kecamatan` ON `tbl_vendor`.`id_kecamatan` = `tbl_kecamatan`.`id_kecamatan`
LEFT JOIN `tbl_kabupaten` ON `tbl_vendor`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
WHERE `tbl_vendor`.`sts_aktif` = 1
AND `tbl_vendor`.`sts_terundang` IS NULL
AND   (
`id_vendor` LIKE '%a%' ESCAPE '!'
OR  `nama_usaha` LIKE '%a%' ESCAPE '!'
OR  `id_jenis_usaha` LIKE '%a%' ESCAPE '!'
OR  `bentuk_usaha` LIKE '%a%' ESCAPE '!'
OR  `kualifikasi_usaha` LIKE '%a%' ESCAPE '!'
OR  `tgl_daftar` LIKE '%a%' ESCAPE '!'
OR  `id_vendor` LIKE '%a%' ESCAPE '!'
 )
ORDER BY `tbl_vendor`.`id_vendor` ASC
 LIMIT 10

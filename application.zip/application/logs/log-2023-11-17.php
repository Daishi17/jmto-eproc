<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484
ERROR - 2023-11-17 07:00:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1484

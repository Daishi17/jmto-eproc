<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-19 05:56:40 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-19 06:03:29 --> 404 Page Not Found: Images/bg

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-04 17:24:47 --> 404 Page Not Found: Assets/js
ERROR - 2023-08-04 17:29:28 --> 404 Page Not Found: Assets/js

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-28 18:09:25 --> 404 Page Not Found: Indexhtml/index

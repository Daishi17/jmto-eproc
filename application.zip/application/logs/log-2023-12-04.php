<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-04 19:28:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1205
ERROR - 2023-12-04 19:28:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1252
ERROR - 2023-12-04 19:28:57 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 283
ERROR - 2023-12-04 19:28:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-04 19:52:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 19:52:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 19:52:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 19:52:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 19:52:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 19:52:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 19:52:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 19:52:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 19:52:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 19:52:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 19:52:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 19:52:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 19:52:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 19:52:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 19:52:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 19:52:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 19:52:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 19:52:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 19:52:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 19:52:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 19:52:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 19:52:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 19:52:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 19:52:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 19:52:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 19:52:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 19:52:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 19:52:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 19:52:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 19:52:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 19:52:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 19:52:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 19:52:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 19:52:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 19:52:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 19:52:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 19:52:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 19:52:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 19:52:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 19:52:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 19:52:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 19:52:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 19:52:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 19:52:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 19:52:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 19:52:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 19:52:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 19:52:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 19:52:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 19:52:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 19:52:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 19:52:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 19:52:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 19:52:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 19:52:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 19:52:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 19:52:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 19:52:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 19:52:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 19:52:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 19:52:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 19:52:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 19:52:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 19:52:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 19:52:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 19:52:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 19:52:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 19:52:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 19:52:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 19:52:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 19:52:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 19:52:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 19:52:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 19:52:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 19:52:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 19:52:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 19:52:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 19:52:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 19:52:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 19:52:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 19:52:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 19:52:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 19:52:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 19:53:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 19:53:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 19:53:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 19:53:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 19:53:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 19:53:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 19:53:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 19:53:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 19:53:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 19:53:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 19:53:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 19:53:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 19:53:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 19:53:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 19:53:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 19:53:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 19:53:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\summary_tender.php 420
ERROR - 2023-12-04 19:53:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\summary_tender.php 420
ERROR - 2023-12-04 19:53:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\summary_tender.php 420
ERROR - 2023-12-04 19:53:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 19:53:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 19:53:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 19:53:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 19:53:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 19:53:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 19:53:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 19:53:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 19:53:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 19:53:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 19:53:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 19:53:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 19:53:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 19:53:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 19:53:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 19:53:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 19:53:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 19:53:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 19:53:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 19:53:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 19:53:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 19:53:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 19:53:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 19:53:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 19:53:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 19:53:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 19:53:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 19:53:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 19:53:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 19:53:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 19:53:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 19:53:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 19:53:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 19:54:25 --> Severity: Notice --> Undefined index: naam_rup C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\summary_tender.php 424
ERROR - 2023-12-04 19:54:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 19:54:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 19:54:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 19:54:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 19:54:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 19:54:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 19:54:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 19:54:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 19:54:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 19:54:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 19:54:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 19:54:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 19:54:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 19:54:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 19:54:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 19:54:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 19:54:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 19:54:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 19:54:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 19:54:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 19:54:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 19:54:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 19:54:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 19:54:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 19:54:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 19:54:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 19:54:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 19:54:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 19:54:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 19:54:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 19:54:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 19:54:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 19:54:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 19:54:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 19:54:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 19:54:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 19:54:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 19:54:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 19:54:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 19:54:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 19:54:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 19:54:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 19:54:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 19:54:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 19:54:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 19:54:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 19:54:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 19:54:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 19:54:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 19:54:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 19:54:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 19:54:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 19:54:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 19:54:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 19:54:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 19:54:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 19:54:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 19:54:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 19:54:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 19:54:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 19:54:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 19:54:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 19:54:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 19:54:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 19:54:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 19:54:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 19:58:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 19:58:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 19:58:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 19:58:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 19:58:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 19:58:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 19:58:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 19:58:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 19:58:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 19:58:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 19:58:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 19:58:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 19:58:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 19:58:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 19:58:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 19:58:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 19:58:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 19:58:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 19:58:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 19:58:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 19:58:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 19:58:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 19:58:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 19:58:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 19:58:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 19:58:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 19:58:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 19:58:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 19:58:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 19:58:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 19:58:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 19:58:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 19:58:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 19:58:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 19:58:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 19:58:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 19:58:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 19:58:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 19:58:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 19:58:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 19:58:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 19:59:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 19:59:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 19:59:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 19:59:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 19:59:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 19:59:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 19:59:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 19:59:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 19:59:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 19:59:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 19:59:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 19:59:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 19:59:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 19:59:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 19:59:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 19:59:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 19:59:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 19:59:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 19:59:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 19:59:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 19:59:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 19:59:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 19:59:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 19:59:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 19:59:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 19:59:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 19:59:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 19:59:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 19:59:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 19:59:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 19:59:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 19:59:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 19:59:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 19:59:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 19:59:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 19:59:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 19:59:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 19:59:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 19:59:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 19:59:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 19:59:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 19:59:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 19:59:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 19:59:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 19:59:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 19:59:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 19:59:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 20:00:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 20:00:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 20:00:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 20:00:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 20:00:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 20:00:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 20:00:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 20:00:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 20:00:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 20:00:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 20:00:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 20:00:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 20:00:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 20:00:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 20:00:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 20:00:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 20:00:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 20:00:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 20:00:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 20:00:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 20:00:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 20:00:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 20:00:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 20:00:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 20:00:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 20:00:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 20:00:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 20:00:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 20:00:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 20:00:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 20:00:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 20:00:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 20:00:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 20:00:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 20:00:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 20:00:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 20:00:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 20:00:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 20:00:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 20:00:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 20:00:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 20:00:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 20:00:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 20:00:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 20:00:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 20:00:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 20:00:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 20:00:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 20:00:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 20:00:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 20:00:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 20:00:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 20:00:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 20:00:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 20:00:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 20:00:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 20:00:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 20:00:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 20:00:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 20:00:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 20:00:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 20:00:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 20:00:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 20:00:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 20:00:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 20:00:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 20:00:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 20:00:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 20:00:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 20:00:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 20:00:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 20:00:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 20:00:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 20:00:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 20:00:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 20:00:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 20:01:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 20:01:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 20:01:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 20:01:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 20:01:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 20:01:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 20:01:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 20:01:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 20:01:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 20:01:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 20:01:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 20:02:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 20:02:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 20:02:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 20:02:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 20:02:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 20:02:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 20:02:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 20:02:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 20:02:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 20:02:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 20:02:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 20:02:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 20:02:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 20:02:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 20:02:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 20:02:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 20:02:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 20:02:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 20:02:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 20:02:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 20:02:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 20:02:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 20:02:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 20:02:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 20:02:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 20:02:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 20:02:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 20:02:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 20:02:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 20:02:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 20:02:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 20:02:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 20:02:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 20:02:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 20:02:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 20:02:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 20:02:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 20:02:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 20:02:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 20:02:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 20:02:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 20:02:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 20:02:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 20:02:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 20:02:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 20:02:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 20:02:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 20:02:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 20:02:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 20:02:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 20:02:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 20:02:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 20:02:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 20:02:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 20:02:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 20:02:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 20:02:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 20:02:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 20:02:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 20:02:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 20:02:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 20:02:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 20:02:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 20:02:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 20:02:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 20:02:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 20:02:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 20:02:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 20:02:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 20:02:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 20:02:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 20:02:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 20:02:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 20:02:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 20:02:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 20:02:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 20:02:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 20:02:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 20:02:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 20:02:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 20:02:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 20:02:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 20:02:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 20:02:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 20:02:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 20:02:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 20:02:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 20:02:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 20:02:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 20:02:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 20:02:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 20:02:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 20:02:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 20:02:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 20:02:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 20:02:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 20:02:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 20:02:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 20:02:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 20:02:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 20:02:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 20:02:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 20:02:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 20:02:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 20:02:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 20:02:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 20:02:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 20:02:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 20:02:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 20:02:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 20:02:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 20:02:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 20:04:53 --> Severity: Notice --> Undefined index: nama_metode_pemilian C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\summary_tender.php 464
ERROR - 2023-12-04 20:04:53 --> Severity: Notice --> Undefined index: total_hps C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\summary_tender.php 472
ERROR - 2023-12-04 20:04:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 20:04:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 20:04:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 20:04:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 20:04:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 20:04:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 20:04:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 20:04:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 20:04:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 20:04:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 20:04:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 20:04:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 20:04:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 20:04:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 20:04:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 20:04:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 20:04:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 20:04:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 20:04:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 20:04:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 20:04:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 20:04:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 20:04:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 20:04:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 20:04:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 20:04:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 20:04:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 20:04:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 20:04:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 20:04:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 20:04:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 20:04:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 20:04:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 20:04:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 20:04:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 20:04:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 20:04:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 20:04:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 20:04:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 20:04:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 20:04:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 20:05:15 --> Severity: Notice --> Undefined index: total_hps C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\summary_tender.php 472
ERROR - 2023-12-04 20:05:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 20:05:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 20:05:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 20:05:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 20:05:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 20:05:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 20:05:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 20:05:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 20:05:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 20:05:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 20:05:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 20:05:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 20:05:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 20:05:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 20:05:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 20:05:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 20:05:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 20:05:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 20:05:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 20:05:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 20:05:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 20:05:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 20:05:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 20:05:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 20:05:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 20:05:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 20:05:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 20:05:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 20:05:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 20:05:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 20:05:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 20:05:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 20:05:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 20:05:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 20:05:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 20:05:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 20:05:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 20:05:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 20:05:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 20:05:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 20:05:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 20:05:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 20:05:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 20:05:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 20:05:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 20:05:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 20:05:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 20:05:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 20:05:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 20:05:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 20:05:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 20:05:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 20:05:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 20:05:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 20:05:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 20:05:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 20:05:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 20:05:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 20:05:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 20:05:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 20:05:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 20:05:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 20:05:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 20:05:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 20:05:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 20:05:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 20:05:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 20:05:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 20:05:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 20:05:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 20:05:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 20:05:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 20:05:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 20:05:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 20:05:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 20:05:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 20:05:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 20:05:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 20:05:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 20:05:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 20:05:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 20:05:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 20:11:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 20:11:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 20:11:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 20:11:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 20:11:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 20:11:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 20:11:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 20:11:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 20:11:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 20:11:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 20:11:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 20:11:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 20:11:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 20:11:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 20:11:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 20:11:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 20:11:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 20:11:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 20:11:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 20:11:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 20:11:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 20:11:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 20:11:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 20:11:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 20:11:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 20:11:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 20:11:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 20:11:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 20:11:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 20:11:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 20:11:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 20:11:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 20:11:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 20:11:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 20:11:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 20:11:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 20:11:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 20:11:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 20:11:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 20:11:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 20:11:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 20:14:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 20:14:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 20:14:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 20:14:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 20:14:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 20:14:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 20:14:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 20:14:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 20:14:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 20:14:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 20:14:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 20:14:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 20:14:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 20:14:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 20:14:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 20:14:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 20:14:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 20:14:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 20:14:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 20:14:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 20:14:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 20:14:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 20:14:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 20:14:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 20:14:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 20:14:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 20:14:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 20:14:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 20:14:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 20:14:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 20:14:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 20:14:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 20:14:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 20:14:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 20:14:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 20:14:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 20:14:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 20:14:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 20:14:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 20:14:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 20:14:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 20:14:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 20:14:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 20:14:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 20:14:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 20:14:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 20:14:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 20:14:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 20:14:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 20:14:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 20:14:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 20:14:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 20:14:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 20:14:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 20:14:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 20:14:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 20:14:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 20:14:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 20:14:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 20:14:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 20:14:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 20:14:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 20:14:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 20:14:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 20:14:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 20:14:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 20:14:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 20:14:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 20:14:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 20:14:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 20:14:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 20:14:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 20:14:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 20:14:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 20:14:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 20:14:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 20:14:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 20:14:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 20:14:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 20:14:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 20:14:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 20:14:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 20:15:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 20:15:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 20:15:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 20:15:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 20:15:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 20:15:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 20:15:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 20:15:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 20:15:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 20:15:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 20:15:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 20:15:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 20:15:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 20:15:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 20:15:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 20:15:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 20:15:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 20:15:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 20:15:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 20:15:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 20:15:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 20:15:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 20:15:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 20:15:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 20:15:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 20:15:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 20:15:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 20:15:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 20:15:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 20:15:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 20:15:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 20:15:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 20:15:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 20:15:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 20:15:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 20:15:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 20:15:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 20:15:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 20:15:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 20:15:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 20:15:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 20:16:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 20:16:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 20:16:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 20:16:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 20:16:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 20:16:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 20:16:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 20:16:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 20:16:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 20:16:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 20:16:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 20:16:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 20:16:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 20:16:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 20:16:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 20:16:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 20:16:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 20:16:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 20:16:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 20:16:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 20:16:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 20:16:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 20:16:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 20:16:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 20:16:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 20:16:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 20:16:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 20:16:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 20:16:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 20:16:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 20:16:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 20:16:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 20:16:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 20:16:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 20:16:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 20:16:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 20:16:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 20:16:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 20:16:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 20:16:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 20:16:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 14:16:45 --> 404 Page Not Found: administrator/Sirup_rup/edit_rup
ERROR - 2023-12-04 14:16:49 --> 404 Page Not Found: administrator//index
ERROR - 2023-12-04 20:18:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 20:18:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 20:18:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 20:18:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 20:18:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 20:18:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 20:18:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 20:18:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 20:18:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 20:18:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 20:18:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 20:18:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 20:18:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 20:18:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 20:18:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 20:18:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 20:18:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 20:18:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 20:18:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 20:18:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 20:18:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 20:18:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 20:18:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 20:18:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 20:18:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 20:18:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 20:18:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 20:18:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 20:18:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 20:18:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 20:18:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 20:18:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 20:18:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 20:18:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 20:18:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 20:18:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 20:18:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 20:18:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 20:18:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 20:18:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 20:18:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 20:19:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 20:19:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 20:19:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 20:19:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 20:19:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 20:19:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 20:19:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 20:19:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 20:19:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 20:19:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 20:19:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 20:19:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 20:19:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 20:19:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 20:19:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 20:19:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 20:19:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 20:19:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 20:19:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 20:19:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 20:19:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 20:19:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 20:19:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 20:19:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 20:19:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 20:19:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 20:19:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 20:19:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 20:19:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 20:19:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 20:19:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 20:19:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 20:19:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 20:19:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 20:19:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 20:19:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 20:19:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 20:19:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 20:19:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 20:19:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 20:19:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 20:23:12 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\summary_tender.php 562
ERROR - 2023-12-04 20:23:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 20:23:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 20:23:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 20:23:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 20:23:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 20:23:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 20:23:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 20:23:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 20:23:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 20:23:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 20:23:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 20:23:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 20:23:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 20:23:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 20:23:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 20:23:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 20:23:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 20:23:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 20:23:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 20:23:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 20:23:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 20:23:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 20:23:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 20:23:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 20:23:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 20:23:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 20:23:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 20:23:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 20:23:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 20:23:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 20:23:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 20:23:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 20:23:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 20:23:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 20:23:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 20:23:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 20:23:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 20:23:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 20:23:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 20:23:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 20:23:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 20:23:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 20:23:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 20:23:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 20:23:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 20:23:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 20:23:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 20:23:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 20:23:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 20:23:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 20:23:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 20:23:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 20:23:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 20:23:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 20:23:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 20:23:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 20:23:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 20:23:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 20:23:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 20:23:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 20:23:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 20:23:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 20:23:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 20:23:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 20:23:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 20:23:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 20:23:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 20:23:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 20:23:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 20:23:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 20:23:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 20:23:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 20:23:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 20:23:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 20:23:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 20:23:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 20:23:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 20:23:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 20:23:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 20:23:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 20:23:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 20:23:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 20:27:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 20:27:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 20:27:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 20:27:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 20:27:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 20:27:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 20:27:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 20:27:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 20:27:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 20:27:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 20:27:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 20:27:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 20:27:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 20:27:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 20:27:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 20:27:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 20:27:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 20:27:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 20:27:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 20:27:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 20:27:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 20:27:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 20:27:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 20:27:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 20:27:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 20:27:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 20:27:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 20:27:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 20:27:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 20:27:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 20:27:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 20:27:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 20:27:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 20:27:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 20:27:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 20:27:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 20:27:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 20:27:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 20:27:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 20:27:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 20:27:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 20:27:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 20:27:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 20:27:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 20:27:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 20:27:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 20:27:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 20:27:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 20:27:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 20:27:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 20:27:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 20:27:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 20:27:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 20:27:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 20:27:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 20:27:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 20:27:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 20:27:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 20:27:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 20:27:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 20:27:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 20:27:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 20:27:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 20:27:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 20:27:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 20:27:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 20:27:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 20:27:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 20:27:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 20:27:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 20:27:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 20:27:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 20:27:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 20:27:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 20:27:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 20:27:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 20:27:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 20:27:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 20:27:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 20:27:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 20:27:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 20:27:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 20:31:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 20:31:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 20:31:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 20:31:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 20:31:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 20:31:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 20:31:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 20:31:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 20:31:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 20:31:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 20:31:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 20:31:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 20:31:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 20:31:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 20:31:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 20:31:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 20:31:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 20:31:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 20:31:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 20:31:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 20:31:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 20:31:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 20:31:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 20:31:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 20:31:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 20:31:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 20:31:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 20:31:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 20:31:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 20:31:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 20:31:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 20:31:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 20:31:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 20:31:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 20:31:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 20:31:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 20:31:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 20:31:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 20:31:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 20:31:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 20:31:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 20:32:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 20:32:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 20:32:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 20:32:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 20:32:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 20:32:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 20:32:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 20:32:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 20:32:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 20:32:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 20:32:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 20:32:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 20:32:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 20:32:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 20:32:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 20:32:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 20:32:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 20:32:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 20:32:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 20:32:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 20:32:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 20:32:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 20:32:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 20:32:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 20:32:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 20:32:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 20:32:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 20:32:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 20:32:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 20:32:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 20:32:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 20:32:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 20:32:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 20:32:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 20:32:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 20:32:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 20:32:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 20:32:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 20:32:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 20:32:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 20:32:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 20:33:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 20:33:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 20:33:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 20:33:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 20:33:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 20:33:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 20:33:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 20:33:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 20:33:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 20:33:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 20:33:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 20:33:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 20:33:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 20:33:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 20:33:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 20:33:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 20:33:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 20:33:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 20:33:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 20:33:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 20:33:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 20:33:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 20:33:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 20:33:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 20:33:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 20:33:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 20:33:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 20:33:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 20:33:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 20:33:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 20:33:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 20:33:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 20:33:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 20:33:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 20:33:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 20:33:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 20:33:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 20:33:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 20:33:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 20:33:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 20:33:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 20:35:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 20:35:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 20:35:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 20:35:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 20:35:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 20:35:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 20:35:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 20:35:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 20:35:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 20:35:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 20:35:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 20:35:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 20:35:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 20:35:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 20:35:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 20:35:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 20:35:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 20:35:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 20:35:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 20:35:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 20:35:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 20:35:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 20:35:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 20:35:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 20:35:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 20:35:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 20:35:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 20:35:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 20:35:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 20:35:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 20:35:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 20:35:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 20:35:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 20:35:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 20:35:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 20:35:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 20:35:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 20:35:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 20:35:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 20:35:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 20:35:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 20:40:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 20:40:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 20:40:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 20:40:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 20:40:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 20:40:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 20:40:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 20:40:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 20:40:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 20:40:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 20:40:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 20:40:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 20:40:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 20:40:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 20:40:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 20:40:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 20:40:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 20:40:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 20:40:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 20:40:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 20:40:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 20:40:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 20:40:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 20:40:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 20:40:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 20:40:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 20:40:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 20:40:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 20:40:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 20:40:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 20:40:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 20:40:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 20:40:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 20:40:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 20:40:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 20:40:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 20:40:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 20:40:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 20:40:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 20:40:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 20:40:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 20:55:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 20:55:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 20:55:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 20:55:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 20:55:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 20:55:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 20:55:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 20:55:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 20:55:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 20:55:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 20:55:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 20:55:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 20:55:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 20:55:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 20:55:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 20:55:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 20:55:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 20:55:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 20:55:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 20:55:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 20:55:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 20:55:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 20:55:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 20:55:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 20:55:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 20:55:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 20:55:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 20:55:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 20:55:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 20:55:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 20:55:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 20:55:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 20:55:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 20:55:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 20:55:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 20:55:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 20:55:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 20:55:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 20:55:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 20:55:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 20:55:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 20:59:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 20:59:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 20:59:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 20:59:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 20:59:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 20:59:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 20:59:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 20:59:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 20:59:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 20:59:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 20:59:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 20:59:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 20:59:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 20:59:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 20:59:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 20:59:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 20:59:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 20:59:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 20:59:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 20:59:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 20:59:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 20:59:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 20:59:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 20:59:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 20:59:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 20:59:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 20:59:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 20:59:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 20:59:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 20:59:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 20:59:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 20:59:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 20:59:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 20:59:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 20:59:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 20:59:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 20:59:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 20:59:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 20:59:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 20:59:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 20:59:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 20:59:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 20:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 20:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 20:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 20:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 20:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 20:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 20:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 20:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 20:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 20:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 20:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 20:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 20:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 20:59:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 20:59:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 20:59:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 20:59:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 20:59:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 20:59:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 20:59:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 20:59:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 20:59:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 20:59:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 20:59:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 20:59:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 20:59:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 20:59:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 20:59:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 20:59:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 20:59:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 20:59:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 20:59:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 20:59:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 20:59:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 20:59:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 20:59:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 20:59:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 20:59:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 20:59:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 20:59:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 21:00:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 21:00:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 21:00:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 21:00:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 21:00:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 21:00:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 21:00:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 21:00:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 21:00:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 21:00:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 21:00:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 21:00:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 21:00:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 21:00:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 21:00:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 21:00:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 21:00:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 21:00:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 21:00:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 21:00:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 21:00:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 21:00:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 21:00:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 21:00:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 21:00:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 21:00:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 21:00:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 21:00:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 21:00:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 21:00:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 21:00:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 21:00:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 21:00:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 21:00:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 21:00:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 21:00:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 21:00:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 21:00:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 21:00:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 21:00:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 21:00:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 21:00:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 21:00:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 21:00:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 21:01:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 21:01:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 21:01:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 21:01:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 21:01:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 21:01:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 21:01:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 21:01:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 21:01:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 21:01:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 21:01:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 21:01:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 21:01:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 21:01:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 21:01:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 21:01:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 21:01:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 21:01:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 21:01:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 21:01:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 21:01:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 21:01:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 21:01:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 21:01:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 21:01:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 21:01:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 21:01:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 21:01:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 21:01:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 21:01:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 21:01:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 21:01:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 21:01:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 21:01:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 21:01:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 21:01:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 21:01:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 21:01:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 21:01:08 --> Severity: Notice --> Undefined index: search C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:08 --> Severity: Notice --> Undefined index: search C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:08 --> Severity: Notice --> Undefined index: search C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:08 --> Severity: Notice --> Undefined index: search C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:08 --> Severity: Notice --> Undefined index: search C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:08 --> Severity: Notice --> Undefined index: search C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:08 --> Severity: Notice --> Undefined index: search C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:08 --> Severity: Notice --> Undefined index: search C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:08 --> Severity: Notice --> Undefined index: search C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:08 --> Severity: Notice --> Undefined index: length C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1071
ERROR - 2023-12-04 21:01:08 --> Severity: Notice --> Undefined index: length C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1072
ERROR - 2023-12-04 21:01:08 --> Severity: Notice --> Undefined index: start C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1072
ERROR - 2023-12-04 21:01:09 --> Severity: Notice --> Undefined index: start C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 109
ERROR - 2023-12-04 21:01:09 --> Severity: Notice --> Undefined index: draw C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 255
ERROR - 2023-12-04 21:01:09 --> Severity: Notice --> Undefined index: search C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:10 --> Severity: Notice --> Undefined index: search C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:10 --> Severity: Notice --> Undefined index: search C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:10 --> Severity: Notice --> Undefined index: search C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:10 --> Severity: Notice --> Undefined index: search C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:10 --> Severity: Notice --> Undefined index: search C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:10 --> Severity: Notice --> Undefined index: search C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:10 --> Severity: Notice --> Undefined index: search C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:10 --> Severity: Notice --> Undefined index: search C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 1042
ERROR - 2023-12-04 21:01:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 21:01:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 21:01:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 21:01:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 21:01:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 21:01:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 21:01:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 21:01:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 21:01:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 21:01:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 21:01:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 21:01:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 21:01:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 21:01:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 21:01:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 21:01:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 21:01:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 21:01:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 21:01:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 21:01:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 21:01:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 21:01:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 21:01:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 21:01:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 21:01:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 21:01:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 21:01:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 21:01:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 21:01:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 21:01:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 21:01:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 21:01:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 21:01:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 21:01:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 21:01:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 21:01:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 21:01:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 21:01:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 21:01:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 21:01:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 21:01:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 21:03:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 21:03:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 21:03:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 21:03:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 21:03:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 21:03:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 21:03:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 21:03:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 21:03:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 21:03:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 21:03:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 21:03:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 21:03:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 21:03:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 21:03:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 21:03:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 21:03:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 21:03:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 21:03:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 21:03:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 21:03:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 21:03:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 21:03:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 21:03:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 21:03:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 21:03:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 21:03:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 21:03:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 21:03:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 21:03:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 21:03:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 21:03:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 21:03:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 21:03:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 21:03:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 21:03:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 21:03:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 21:03:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 21:03:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 21:03:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 21:03:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 21:04:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 21:04:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 21:04:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 21:04:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 21:04:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 21:04:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 21:04:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 21:04:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 21:04:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 21:04:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 21:04:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 21:04:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 21:04:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 21:04:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 21:04:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 21:04:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 21:04:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 21:04:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 21:04:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 21:04:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 21:04:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 21:04:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 21:04:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 21:04:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 21:04:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 21:04:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 21:04:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 21:04:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 21:04:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 21:04:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 21:04:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 21:04:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 21:04:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 21:04:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 21:04:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 21:04:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 21:04:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 21:04:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 21:04:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 21:04:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 21:04:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 21:05:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 21:05:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 21:05:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 21:05:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 21:05:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 21:05:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 21:05:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 21:05:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 21:05:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 21:05:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 21:05:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 21:05:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 21:05:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 21:05:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 21:05:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 21:05:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 21:05:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 21:05:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 21:05:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 21:05:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 21:05:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 21:05:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 21:05:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 21:05:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 21:05:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 21:05:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 21:05:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 21:05:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 21:05:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 21:05:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 21:05:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 21:05:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 21:05:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 21:05:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 21:05:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 21:05:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 21:05:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 21:05:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 21:05:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 21:05:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 21:05:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 21:05:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 21:05:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 21:05:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 21:05:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 21:05:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 21:05:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 21:05:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 21:05:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 21:05:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 21:05:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 21:05:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 21:05:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 21:05:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 21:05:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 21:05:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 21:05:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 21:05:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 21:05:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 21:05:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 21:05:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 21:05:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 21:05:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 21:05:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 21:05:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 21:05:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 21:05:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 21:05:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 21:05:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 21:05:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 21:05:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 21:05:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 21:05:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 21:05:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 21:05:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 21:05:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 21:05:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 21:05:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 21:05:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 21:05:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 21:05:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 21:05:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 21:05:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 21:05:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 21:05:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 21:05:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 21:05:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 21:05:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 21:05:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 21:05:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 21:05:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 21:05:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 21:05:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 21:05:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 21:05:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 21:05:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 21:05:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 21:05:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 21:05:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 21:05:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 21:05:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 21:05:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 21:06:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 21:06:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 21:06:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 21:06:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 21:07:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 21:07:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 21:07:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 21:07:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 21:07:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 21:07:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 21:07:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 21:07:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 21:07:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 21:07:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 21:07:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 21:07:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 21:07:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 21:07:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 21:07:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 21:07:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 21:07:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 21:07:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 21:07:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 21:07:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 21:07:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 21:07:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 21:07:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 21:07:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 21:07:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 21:07:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 21:07:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 21:07:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 21:07:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 21:07:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 21:07:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 21:07:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 21:07:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 21:07:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 21:07:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 21:07:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 21:07:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 21:07:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 21:07:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 21:07:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 21:07:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 21:08:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 21:08:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 21:08:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 21:08:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 21:08:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 21:08:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 21:08:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 21:08:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 21:08:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 21:08:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 21:08:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 21:08:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 21:08:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 21:08:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 21:08:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 21:08:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 21:08:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 21:08:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 21:08:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 21:08:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 21:08:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 21:08:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 21:08:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 21:08:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 21:08:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 21:08:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 21:08:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 21:08:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 21:08:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 21:08:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 21:08:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 21:08:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 21:08:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 21:08:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 21:08:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 21:08:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 21:08:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 21:08:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 21:08:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 21:08:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 21:08:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 21:08:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 21:08:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 21:08:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 21:08:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 21:08:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 21:08:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 21:08:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 21:08:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 21:08:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 21:08:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 21:08:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 21:08:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 21:08:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 21:08:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 21:08:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 21:08:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 21:08:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 21:08:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 21:08:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 21:08:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 21:08:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 21:08:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 21:08:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 21:08:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 21:08:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 21:08:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 21:08:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 21:08:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 21:08:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 21:08:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 21:08:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 21:08:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 21:08:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 21:08:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 21:08:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 21:08:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 21:08:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 21:08:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 21:09:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 21:09:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 21:09:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 21:16:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 21:16:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 21:16:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 21:16:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 21:16:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 21:16:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 21:16:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 21:16:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 21:16:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 21:16:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 21:16:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 21:16:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 21:16:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 21:16:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 21:16:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 21:16:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 21:16:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 21:16:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 21:16:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 21:16:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 21:16:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 21:16:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 21:16:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 21:16:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 21:16:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 21:16:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 21:16:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 21:16:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 21:16:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 21:16:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 21:16:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 21:16:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 21:16:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 21:16:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 21:16:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 21:16:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 21:16:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 21:16:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 21:16:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 21:16:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 21:16:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 21:17:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 21:17:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 21:17:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 21:17:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 21:17:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 21:17:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 21:17:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 21:17:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 21:17:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 21:17:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 21:17:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 21:17:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 21:17:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 21:17:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 21:17:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 21:17:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 21:17:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 21:17:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 21:17:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 21:17:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 21:17:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 21:17:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 21:17:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 21:17:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 21:17:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 21:17:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 21:17:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 21:17:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 21:17:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 21:17:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 21:17:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 21:17:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 21:17:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 21:17:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 21:17:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 21:17:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 21:17:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 21:17:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 21:17:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 21:17:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 21:17:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 21:17:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 21:17:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 21:17:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 21:17:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 21:17:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 21:17:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 21:17:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 21:17:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 21:17:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 21:17:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 21:17:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 21:17:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 21:17:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 21:17:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 21:17:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 21:17:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 21:17:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 21:17:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 21:17:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 21:17:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 21:17:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 21:17:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 21:17:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 21:17:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 21:17:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 21:17:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 21:17:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 21:17:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 21:17:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 21:17:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 21:18:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 21:18:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 21:18:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 21:18:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 21:18:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 21:18:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 21:18:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 21:18:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 21:18:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 21:18:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 21:18:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 21:19:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 21:19:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 21:19:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 21:19:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 21:19:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 21:19:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 21:19:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 21:19:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 21:19:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 21:19:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 21:19:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 21:19:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 21:19:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 21:19:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 21:19:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 21:19:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 21:19:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 21:19:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 21:19:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 21:19:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 21:19:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 21:19:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 21:19:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 21:19:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 21:19:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 21:19:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 21:19:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 21:19:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 21:19:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 21:19:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 21:19:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 21:19:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 21:19:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 21:19:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 21:19:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 21:19:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 21:19:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 21:19:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 21:19:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 21:19:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 21:19:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 21:27:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 21:27:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 21:27:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 21:27:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 21:27:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 21:27:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 21:27:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 21:27:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 21:27:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 21:27:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 21:27:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 21:27:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 21:27:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 21:27:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 21:27:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 21:27:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 21:27:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 21:27:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 21:27:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 21:27:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 21:27:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 21:27:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 21:27:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 21:27:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 21:27:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 21:27:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 21:27:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 21:27:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 21:27:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 21:27:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 21:27:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 21:27:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 21:27:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 21:27:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 21:27:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 21:27:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 21:27:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 21:27:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 21:27:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 21:27:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 21:27:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 21:29:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 21:29:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 21:29:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 21:29:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 21:29:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 21:29:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 21:29:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 21:29:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 21:29:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 21:29:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 21:29:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 21:29:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 21:29:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 21:29:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 21:29:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 21:29:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 21:29:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 21:29:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 21:29:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 21:29:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 21:29:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 21:29:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 21:29:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 21:29:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 21:29:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 21:29:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 21:29:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 21:29:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 21:29:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 21:29:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 21:29:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 21:29:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 21:29:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 21:29:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 21:29:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 21:29:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 21:29:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 21:29:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 21:29:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 21:29:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 21:29:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 21:30:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 21:30:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 21:30:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 21:30:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 21:30:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 21:30:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 21:30:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 21:30:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 21:30:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 21:30:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 21:30:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 21:30:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 21:30:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 21:30:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 21:30:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 21:30:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 21:30:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 21:30:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 21:30:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 21:30:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 21:30:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 21:30:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 21:30:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 21:30:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 21:30:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 21:30:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 21:30:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 21:30:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 21:30:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 21:30:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 21:30:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 21:30:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 21:30:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 21:30:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 21:30:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 21:30:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 21:30:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 21:30:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 21:30:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 21:30:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 21:30:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 21:31:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 21:31:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 21:31:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 21:31:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 21:31:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 21:31:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 21:31:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 21:31:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 21:31:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 21:31:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 21:31:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 21:31:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 21:31:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 21:31:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 21:31:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 21:31:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 21:31:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 21:31:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 21:31:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 21:31:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 21:31:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 21:31:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 21:31:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 21:31:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 21:31:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 21:31:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 21:31:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 21:31:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 21:31:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 21:31:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 21:31:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 21:31:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 21:31:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 21:31:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 21:31:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 21:31:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 21:31:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 21:31:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 21:31:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 21:31:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 21:31:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 21:39:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 21:39:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 21:39:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 21:39:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 21:39:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 21:39:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 21:39:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 21:39:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 21:39:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 21:39:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 21:39:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 21:39:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 21:39:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 21:39:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 21:39:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 21:39:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 21:39:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 21:39:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 21:39:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 21:39:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 21:39:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 21:39:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 21:39:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 21:39:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 21:39:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 21:39:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 21:39:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 21:39:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 21:39:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 21:39:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 21:39:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 21:39:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 21:39:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 21:39:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 21:39:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 21:39:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 21:39:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 21:39:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 21:39:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 21:39:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 21:39:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 15:42:28 --> 404 Page Not Found: Assets/img
ERROR - 2023-12-04 21:42:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 21:42:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 21:42:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 21:42:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 21:42:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 21:42:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 21:42:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 21:42:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 21:42:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 21:42:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 21:42:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 21:42:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 21:42:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 21:42:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 21:42:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 21:42:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 21:42:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 21:42:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 21:42:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 21:42:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 21:42:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 21:42:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 21:42:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 21:42:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 21:42:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 21:42:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 21:42:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 21:42:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 21:42:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 21:42:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 21:42:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 21:42:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 21:42:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 21:42:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 21:42:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 21:42:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 21:42:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 21:42:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 21:42:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 21:42:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 21:42:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 21:43:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 21:43:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 21:43:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 21:43:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 21:43:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 21:43:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 21:43:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 21:43:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 21:43:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 21:43:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 21:43:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 21:43:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 21:43:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 21:43:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 21:43:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 21:43:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 21:43:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 21:43:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 21:43:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 21:43:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 21:43:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 21:43:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 21:43:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 21:43:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 21:43:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 21:43:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 21:43:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 21:43:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 21:43:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 21:43:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 21:43:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 21:43:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 21:43:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 21:43:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 21:43:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 21:43:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 21:43:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 21:43:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 21:43:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 21:43:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 21:43:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 21:44:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 21:44:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 21:44:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 21:44:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 21:44:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 21:44:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 21:44:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 21:44:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 21:44:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 21:44:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 21:44:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 21:44:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 21:44:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 21:44:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 21:44:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 21:44:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 21:44:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 21:44:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 21:44:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 21:44:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 21:44:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 21:44:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 21:44:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 21:44:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 21:44:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 21:44:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 21:44:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 21:44:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 21:44:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 21:44:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 21:44:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 21:44:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 21:44:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 21:44:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 21:44:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 21:44:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 21:44:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 21:44:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 21:44:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 21:44:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 21:44:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 21:45:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 21:45:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 21:45:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 21:45:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 21:45:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 21:45:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 21:45:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 21:45:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 21:45:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 21:45:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 21:45:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 21:45:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 21:45:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 21:45:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 21:45:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 21:45:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 21:45:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 21:45:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 21:45:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 21:45:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 21:45:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 21:45:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 21:45:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 21:45:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 21:45:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 21:45:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 21:45:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 21:45:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 21:45:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 21:45:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 21:45:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 21:45:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 21:45:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 21:45:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 21:45:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 21:45:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 21:45:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 21:45:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 21:45:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 21:45:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 21:45:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 21:48:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 21:48:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 21:48:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 21:48:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 21:48:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 21:48:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 21:48:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 21:48:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 21:48:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 21:48:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 21:48:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 21:48:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 21:48:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 21:48:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 21:48:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 21:48:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 21:48:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 21:48:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 21:48:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 21:48:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 21:48:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 21:48:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 21:48:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 21:48:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 21:48:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 21:48:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 21:48:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 21:48:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 21:48:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 21:48:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 21:48:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 21:48:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 21:48:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 21:48:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 21:48:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 21:48:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 21:48:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 21:48:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 21:48:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 21:48:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 21:48:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 21:48:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 21:48:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 21:48:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 21:48:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 21:48:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 21:48:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 21:48:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 21:48:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 21:48:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 21:48:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 21:48:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 21:48:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 21:48:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 21:48:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 21:48:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 21:48:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 21:48:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 21:48:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 21:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 21:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 21:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 21:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 21:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 21:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 21:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 21:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 21:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 21:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 21:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 21:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 21:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 21:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 21:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 21:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 21:48:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 21:48:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 21:48:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 21:48:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 21:48:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 21:48:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 21:48:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 21:49:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1681
ERROR - 2023-12-04 21:49:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1682
ERROR - 2023-12-04 21:49:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1683
ERROR - 2023-12-04 21:49:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1684
ERROR - 2023-12-04 21:49:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1685
ERROR - 2023-12-04 21:49:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1686
ERROR - 2023-12-04 21:49:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1687
ERROR - 2023-12-04 21:49:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1689
ERROR - 2023-12-04 21:49:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1692
ERROR - 2023-12-04 21:49:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1696
ERROR - 2023-12-04 21:49:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1697
ERROR - 2023-12-04 21:49:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1703
ERROR - 2023-12-04 21:49:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1704
ERROR - 2023-12-04 21:49:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1705
ERROR - 2023-12-04 21:49:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1706
ERROR - 2023-12-04 21:49:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1707
ERROR - 2023-12-04 21:49:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1708
ERROR - 2023-12-04 21:49:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1709
ERROR - 2023-12-04 21:49:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1710
ERROR - 2023-12-04 21:49:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1711
ERROR - 2023-12-04 21:49:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1712
ERROR - 2023-12-04 21:49:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1713
ERROR - 2023-12-04 21:49:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1714
ERROR - 2023-12-04 21:49:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1715
ERROR - 2023-12-04 21:49:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1716
ERROR - 2023-12-04 21:49:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1717
ERROR - 2023-12-04 21:49:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1718
ERROR - 2023-12-04 21:49:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1719
ERROR - 2023-12-04 21:49:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1720
ERROR - 2023-12-04 21:49:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1721
ERROR - 2023-12-04 21:49:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1722
ERROR - 2023-12-04 21:49:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1723
ERROR - 2023-12-04 21:49:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1727
ERROR - 2023-12-04 21:49:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1728
ERROR - 2023-12-04 21:49:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1734
ERROR - 2023-12-04 21:49:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1735
ERROR - 2023-12-04 21:49:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1736
ERROR - 2023-12-04 21:49:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1737
ERROR - 2023-12-04 21:49:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\models\M_panitia\M_panitia.php 451
ERROR - 2023-12-04 21:49:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-04 21:49:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\jmto-eproc\system\core\Exceptions.php:272) C:\xampp\htdocs\jmto-eproc\system\core\Common.php 571
ERROR - 2023-12-04 22:01:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1205
ERROR - 2023-12-04 22:01:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1252
ERROR - 2023-12-04 22:01:54 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 283
ERROR - 2023-12-04 22:01:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-04 22:02:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-04 22:02:06 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 283
ERROR - 2023-12-04 22:02:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1205
ERROR - 2023-12-04 22:02:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1252
ERROR - 2023-12-04 22:03:31 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 283
ERROR - 2023-12-04 22:03:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-04 22:03:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1205
ERROR - 2023-12-04 22:03:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1252
ERROR - 2023-12-04 22:07:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1205
ERROR - 2023-12-04 22:07:01 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 283
ERROR - 2023-12-04 22:07:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1490
ERROR - 2023-12-04 22:07:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1252
ERROR - 2023-12-04 22:32:47 --> Severity: Notice --> Undefined variable: count_tender_umum C:\xampp\htdocs\jmto-eproc\application\views\administrator\penilaian_kinerja\index.php 33
ERROR - 2023-12-04 22:32:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\jmto-eproc\application\views\administrator\penilaian_kinerja\index.php 33
ERROR - 2023-12-04 22:32:47 --> Severity: Notice --> Undefined variable: count_tender_terbatas C:\xampp\htdocs\jmto-eproc\application\views\administrator\penilaian_kinerja\index.php 37
ERROR - 2023-12-04 22:32:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\jmto-eproc\application\views\administrator\penilaian_kinerja\index.php 37
ERROR - 2023-12-04 22:33:10 --> Severity: Notice --> Undefined variable: count_tender_umum C:\xampp\htdocs\jmto-eproc\application\views\administrator\penilaian_kinerja\index.php 33
ERROR - 2023-12-04 22:33:10 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\jmto-eproc\application\views\administrator\penilaian_kinerja\index.php 33
ERROR - 2023-12-04 22:33:10 --> Severity: Notice --> Undefined variable: count_tender_terbatas C:\xampp\htdocs\jmto-eproc\application\views\administrator\penilaian_kinerja\index.php 37
ERROR - 2023-12-04 22:33:10 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\jmto-eproc\application\views\administrator\penilaian_kinerja\index.php 37
ERROR - 2023-12-04 22:33:32 --> Severity: Notice --> Undefined variable: count_tender_umum C:\xampp\htdocs\jmto-eproc\application\views\administrator\penilaian_kinerja\index.php 33
ERROR - 2023-12-04 22:33:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\jmto-eproc\application\views\administrator\penilaian_kinerja\index.php 33
ERROR - 2023-12-04 22:33:32 --> Severity: Notice --> Undefined variable: count_tender_terbatas C:\xampp\htdocs\jmto-eproc\application\views\administrator\penilaian_kinerja\index.php 37
ERROR - 2023-12-04 22:33:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\jmto-eproc\application\views\administrator\penilaian_kinerja\index.php 37
ERROR - 2023-12-04 22:33:47 --> Severity: Notice --> Undefined variable: count_tender_umum C:\xampp\htdocs\jmto-eproc\application\views\administrator\penilaian_kinerja\index.php 33
ERROR - 2023-12-04 22:33:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\jmto-eproc\application\views\administrator\penilaian_kinerja\index.php 33
ERROR - 2023-12-04 22:33:47 --> Severity: Notice --> Undefined variable: count_tender_terbatas C:\xampp\htdocs\jmto-eproc\application\views\administrator\penilaian_kinerja\index.php 37
ERROR - 2023-12-04 22:33:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\jmto-eproc\application\views\administrator\penilaian_kinerja\index.php 37
ERROR - 2023-12-04 22:34:24 --> Severity: Notice --> Undefined property: Penilaian_kinerja::$M_count C:\xampp\htdocs\jmto-eproc\application\controllers\administrator\Penilaian_kinerja.php 25
ERROR - 2023-12-04 22:34:24 --> Severity: error --> Exception: Call to a member function count_tender_umum() on null C:\xampp\htdocs\jmto-eproc\application\controllers\administrator\Penilaian_kinerja.php 25
ERROR - 2023-12-04 22:35:09 --> Severity: Notice --> Undefined property: Penilaian_kinerja::$M_count C:\xampp\htdocs\jmto-eproc\application\controllers\administrator\Penilaian_kinerja.php 25
ERROR - 2023-12-04 22:35:09 --> Severity: error --> Exception: Call to a member function count_tender_umum() on null C:\xampp\htdocs\jmto-eproc\application\controllers\administrator\Penilaian_kinerja.php 25
ERROR - 2023-12-04 16:52:20 --> 404 Page Not Found: Admin/penilaian_kinerja
ERROR - 2023-12-04 23:05:42 --> Query error: Duplicate column name 'kualifikasi_usaha' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM (
SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_vendor` ON `tbl_rup`.`id_vendor_pemenang` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_vendor_mengikuti_paket` ON `tbl_rup`.`id_rup` = `tbl_vendor_mengikuti_paket`.`id_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `tbl_rup`.`status_paket_panitia` = 1
AND `tbl_rup`.`id_metode_pengadaan` = 1
AND `tbl_rup`.`id_vendor_pemenang` IS NOT NULL
GROUP BY `tbl_rup`.`id_rup`
) CI_count_all_results
ERROR - 2023-12-04 23:07:41 --> Query error: Unknown column 'tbl_rup.id_metode_pengadaan' in 'where clause' - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
WHERE `tbl_rup`.`id_metode_pengadaan` = 1
AND `tbl_rup`.`status_paket_diumumkan` = 1
AND `tbl_rup`.`id_departemen` = '25'
GROUP BY `tbl_rup`.`id_rup`
ERROR - 2023-12-04 23:09:21 --> Query error: Duplicate column name 'id_vendor' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM (
SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `tbl_rup`.`status_paket_panitia` = 1
AND `tbl_rup`.`id_metode_pengadaan` = 1
AND `tbl_rup`.`id_vendor_pemenang` IS NOT NULL
GROUP BY `tbl_rup`.`id_rup`
) CI_count_all_results
ERROR - 2023-12-04 23:10:02 --> Query error: Unknown column 'tbl_vendor_mengikuti_paket.id_rup' in 'group statement' - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_metode_pengadaan` = 1
AND `tbl_rup`.`status_paket_diumumkan` = 1
AND `tbl_rup`.`id_departemen` = '25'
GROUP BY `tbl_vendor_mengikuti_paket`.`id_rup`
ERROR - 2023-12-04 23:11:26 --> Query error: Unknown column 'tbl_rup.id_vendor' in 'on clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tbl_rup`
LEFT JOIN `tbl_vendor` ON `tbl_rup`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_rup`.`status_paket_panitia` = 1
AND `tbl_rup`.`id_metode_pengadaan` = 1
AND `tbl_rup`.`id_vendor_pemenang` IS NOT NULL
ERROR - 2023-12-04 23:11:34 --> Query error: Unknown column 'tbl_rup.id_vendor' in 'on clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tbl_rup`
LEFT JOIN `tbl_vendor` ON `tbl_rup`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_rup`.`status_paket_panitia` = 1
AND `tbl_rup`.`id_metode_pengadaan` = 1
AND `tbl_rup`.`id_vendor_pemenang` IS NOT NULL
ERROR - 2023-12-04 23:11:39 --> Query error: Unknown column 'tbl_rup.id_vendor' in 'on clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tbl_rup`
LEFT JOIN `tbl_vendor` ON `tbl_rup`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_rup`.`status_paket_panitia` = 1
AND `tbl_rup`.`id_metode_pengadaan` = 1
AND `tbl_rup`.`id_vendor_pemenang` IS NOT NULL
ERROR - 2023-12-04 23:12:38 --> Query error: Unknown column 'tbl_rup.id_vendor' in 'on clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tbl_rup`
LEFT JOIN `tbl_vendor` ON `tbl_rup`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_rup`.`status_paket_panitia` = 1
AND `tbl_rup`.`id_metode_pengadaan` = 1
AND `tbl_rup`.`id_vendor_pemenang` IS NOT NULL
ERROR - 2023-12-04 23:16:07 --> Query error: Duplicate column name 'id_rup' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM (
SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_vendor_mengikuti_paket` ON `tbl_rup`.`id_rup` = `tbl_vendor_mengikuti_paket`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_rup`.`status_paket_panitia` = 1
AND `tbl_rup`.`id_metode_pengadaan` = 1
AND `tbl_rup`.`id_vendor_pemenang` IS NOT NULL
GROUP BY `tbl_rup`.`id_rup`
) CI_count_all_results
ERROR - 2023-12-04 23:16:20 --> Query error: Duplicate column name 'id_rup' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM (
SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_vendor_mengikuti_paket` ON `tbl_rup`.`id_rup` = `tbl_vendor_mengikuti_paket`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_rup`.`status_paket_panitia` = 1
AND `tbl_rup`.`id_metode_pengadaan` = 1
AND `tbl_rup`.`id_vendor_pemenang` IS NOT NULL
GROUP BY `tbl_rup`.`id_rup`
) CI_count_all_results
ERROR - 2023-12-04 23:17:16 --> Query error: Unknown column 'tbl_vendor_mengikuti_paket.id_vendor_mengikuti_paket' in 'group statement' - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_metode_pengadaan` = 1
AND `tbl_rup`.`status_paket_diumumkan` = 1
AND `tbl_rup`.`id_departemen` = '25'
GROUP BY `tbl_vendor_mengikuti_paket`.`id_vendor_mengikuti_paket`
ERROR - 2023-12-04 23:21:56 --> Query error: Duplicate column name 'id_rup' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM (
SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_rup`.`id_rup` = `tbl_vendor_mengikuti_paket`.`id_rup`
WHERE `tbl_rup`.`status_paket_panitia` = 1
AND `tbl_rup`.`id_metode_pengadaan` = 1
AND `tbl_rup`.`id_vendor_pemenang` IS NOT NULL
GROUP BY `tbl_vendor_mengikuti_paket`.`id_rup`
) CI_count_all_results
ERROR - 2023-12-04 17:40:47 --> 404 Page Not Found: administrator/Buat_penilaian/48
ERROR - 2023-12-04 23:41:11 --> Severity: error --> Exception: Call to undefined method M_Dashboard::get_row_vendor_mengikuti_paket() C:\xampp\htdocs\jmto-eproc\application\controllers\administrator\Penilaian_kinerja.php 49

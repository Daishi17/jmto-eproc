<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-31 20:58:21 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 20:58:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 20:58:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 20:58:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 20:58:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 20:58:31 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 20:58:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 20:58:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 20:58:35 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 20:58:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 20:58:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 20:58:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:00:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:00:20 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:00:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:00:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:05:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:05:34 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:05:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:05:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:05:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:05:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:05:38 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:05:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:05:44 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:05:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:05:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:05:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:07:54 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:07:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:07:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:07:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:08:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:08:10 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:08:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:08:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:08:40 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:08:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:08:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:08:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:08:48 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:08:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:08:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:08:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:08:54 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:08:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:08:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:08:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:09:00 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:00 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:00 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:00 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:00 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:00 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:00 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:00 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:00 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:00 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 781
ERROR - 2023-10-31 21:09:00 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 782
ERROR - 2023-10-31 21:09:00 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 782
ERROR - 2023-10-31 21:09:01 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 39
ERROR - 2023-10-31 21:09:01 --> Severity: Notice --> Undefined index: draw C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 62
ERROR - 2023-10-31 21:09:01 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:01 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:01 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:01 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:01 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:01 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:01 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:01 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:01 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 752
ERROR - 2023-10-31 21:09:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:09:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:09:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:09:32 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:09:42 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:42 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:42 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:42 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:42 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:42 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:42 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:42 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:42 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:42 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 57
ERROR - 2023-10-31 21:09:42 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 58
ERROR - 2023-10-31 21:09:42 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 58
ERROR - 2023-10-31 21:09:42 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 146
ERROR - 2023-10-31 21:09:42 --> Severity: Notice --> Undefined index: draw C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 162
ERROR - 2023-10-31 21:09:43 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:43 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:43 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:43 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:43 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:43 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:43 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:43 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:43 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:09:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:10:06 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:10:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:10:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:10:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:10:49 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:10:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:10:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:10:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:11:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:11:15 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:11:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:11:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:11:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:11:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:11:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:11:42 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:12:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:12:23 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:12:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:12:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:12:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:12:30 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:12:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:12:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:12:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:12:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:12:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:12:33 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:12:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:12:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:12:40 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:12:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:12:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:12:45 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:12:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:12:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:13:06 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:13:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:13:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:13:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:13:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:13:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:13:10 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:13:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 57
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 58
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 58
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 146
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Undefined index: draw C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 162
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 57
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 58
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 58
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 146
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Undefined index: draw C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 162
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:13:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:13:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:13:46 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:13:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:14:24 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:14:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:14:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:14:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:14:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:14:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:14:33 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:14:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:14:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:14:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:14:40 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:14:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:14:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:14:48 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:14:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:14:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:15:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:15:06 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:15:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:15:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:15:07 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:15:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:15:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:15:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:15:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:15:36 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:15:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:15:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:15:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:15:47 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:15:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:15:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 57
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 58
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 58
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 146
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Undefined index: draw C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 162
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:15:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 28
ERROR - 2023-10-31 21:16:30 --> Query error: Column 'id_rup' in where clause is ambiguous - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_panitia` ON `tbl_rup`.`id_rup` = `tbl_panitia`.`id_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `tbl_rup`.`sts_rup_buat_paket` = 2
AND `tbl_panitia`.`id_manajemen_user` = '26'
AND   (
`id_rup` LIKE '%a%' ESCAPE '!'
OR  `kode_rup` LIKE '%a%' ESCAPE '!'
OR  `tahun_rup` LIKE '%a%' ESCAPE '!'
OR  `nama_program_rup` LIKE '%a%' ESCAPE '!'
OR  `kode_departemen` LIKE '%a%' ESCAPE '!'
OR  `total_pagu_rup` LIKE '%a%' ESCAPE '!'
OR  `id_rup` LIKE '%a%' ESCAPE '!'
OR  `id_rup` LIKE '%a%' ESCAPE '!'
OR  `id_rup` LIKE '%a%' ESCAPE '!'
 )
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2023-10-31 21:16:32 --> Query error: Column 'id_rup' in where clause is ambiguous - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_panitia` ON `tbl_rup`.`id_rup` = `tbl_panitia`.`id_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `tbl_rup`.`sts_rup_buat_paket` = 2
AND `tbl_panitia`.`id_manajemen_user` = '26'
AND   (
`id_rup` LIKE '%asd%' ESCAPE '!'
OR  `kode_rup` LIKE '%asd%' ESCAPE '!'
OR  `tahun_rup` LIKE '%asd%' ESCAPE '!'
OR  `nama_program_rup` LIKE '%asd%' ESCAPE '!'
OR  `kode_departemen` LIKE '%asd%' ESCAPE '!'
OR  `total_pagu_rup` LIKE '%asd%' ESCAPE '!'
OR  `id_rup` LIKE '%asd%' ESCAPE '!'
OR  `id_rup` LIKE '%asd%' ESCAPE '!'
OR  `id_rup` LIKE '%asd%' ESCAPE '!'
 )
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2023-10-31 21:17:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:17:05 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:17:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:17:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:17:10 --> Query error: Column 'id_rup' in order clause is ambiguous - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_panitia` ON `tbl_rup`.`id_rup` = `tbl_panitia`.`id_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `tbl_rup`.`sts_rup_buat_paket` = 2
AND `tbl_panitia`.`id_manajemen_user` = '26'
ORDER BY `id_rup` ASC
 LIMIT 10
ERROR - 2023-10-31 21:17:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:17:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:17:51 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:17:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:18:00 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:18:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:18:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:18:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:18:06 --> Query error: Column 'id_rup' in order clause is ambiguous - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_panitia` ON `tbl_rup`.`id_rup` = `tbl_panitia`.`id_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `tbl_rup`.`sts_rup_buat_paket` = 2
AND `tbl_panitia`.`id_manajemen_user` = '26'
ORDER BY `id_rup` ASC
 LIMIT 10
ERROR - 2023-10-31 21:19:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:19:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:19:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:19:22 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:19:27 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:19:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:19:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:19:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:19:35 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:19:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:19:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:19:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:19:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:19:54 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:19:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:19:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:20:03 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:20:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:20:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:20:06 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:20:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:20:15 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:20:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:20:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:20:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 14:20:51 --> 404 Page Not Found: panitia/daftar_paket/Daftar_paket/by_id_rup
ERROR - 2023-10-31 21:20:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:20:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:20:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:21:04 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:21:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:21:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:21:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:21:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:21:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:21:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:21:45 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:21:49 --> Query error: Column 'id_rup' in where clause is ambiguous - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_panitia` ON `tbl_rup`.`id_rup` = `tbl_panitia`.`id_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `tbl_rup`.`status_paket_panitia` IN(1, 2)
AND `tbl_panitia`.`id_manajemen_user` = '26'
AND   (
`id_rup` LIKE '%A%' ESCAPE '!'
OR  `kode_rup` LIKE '%A%' ESCAPE '!'
OR  `tahun_rup` LIKE '%A%' ESCAPE '!'
OR  `nama_program_rup` LIKE '%A%' ESCAPE '!'
OR  `kode_departemen` LIKE '%A%' ESCAPE '!'
OR  `total_pagu_rup` LIKE '%A%' ESCAPE '!'
OR  `id_rup` LIKE '%A%' ESCAPE '!'
OR  `id_rup` LIKE '%A%' ESCAPE '!'
OR  `id_rup` LIKE '%A%' ESCAPE '!'
 )
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2023-10-31 21:21:50 --> Query error: Column 'id_rup' in where clause is ambiguous - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_panitia` ON `tbl_rup`.`id_rup` = `tbl_panitia`.`id_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `tbl_rup`.`status_paket_panitia` IN(1, 2)
AND `tbl_panitia`.`id_manajemen_user` = '26'
AND   (
`id_rup` LIKE '%ASD%' ESCAPE '!'
OR  `kode_rup` LIKE '%ASD%' ESCAPE '!'
OR  `tahun_rup` LIKE '%ASD%' ESCAPE '!'
OR  `nama_program_rup` LIKE '%ASD%' ESCAPE '!'
OR  `kode_departemen` LIKE '%ASD%' ESCAPE '!'
OR  `total_pagu_rup` LIKE '%ASD%' ESCAPE '!'
OR  `id_rup` LIKE '%ASD%' ESCAPE '!'
OR  `id_rup` LIKE '%ASD%' ESCAPE '!'
OR  `id_rup` LIKE '%ASD%' ESCAPE '!'
 )
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2023-10-31 21:22:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:22:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:22:38 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:22:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:22:51 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-31 21:22:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 894
ERROR - 2023-10-31 21:22:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-31 21:22:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 941
ERROR - 2023-10-31 21:24:48 --> Severity: Notice --> Undefined variable: jumlah_peserta C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 62
ERROR - 2023-10-31 21:24:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 62
ERROR - 2023-10-31 21:25:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 62
ERROR - 2023-10-31 14:28:41 --> 404 Page Not Found: File_paket/PAKET%20TESTING%20TENDER%20UMUM
ERROR - 2023-10-31 14:32:57 --> 404 Page Not Found: File_paket/PAKET%20TESTING%20TENDER%20UMUM
ERROR - 2023-10-31 14:53:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-10-31 14:53:49 --> Unable to connect to the database
ERROR - 2023-10-31 14:53:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-10-31 14:53:54 --> Unable to connect to the database
ERROR - 2023-10-31 22:30:01 --> Severity: error --> Exception: Call to undefined method M_panitia::count_all_evaluasi() C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 81
ERROR - 2023-10-31 22:30:24 --> Severity: error --> Exception: Call to undefined method M_panitia::count_all_evaluasi() C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 87
ERROR - 2023-10-31 22:30:29 --> Severity: error --> Exception: Call to undefined method M_panitia::count_all_evaluasi() C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 87
ERROR - 2023-10-31 22:50:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 3
ERROR - 2023-10-31 22:50:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 10
ERROR - 2023-10-31 22:50:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 13
ERROR - 2023-10-31 22:50:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 16
ERROR - 2023-10-31 22:50:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 19
ERROR - 2023-10-31 22:50:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 22
ERROR - 2023-10-31 22:50:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 25
ERROR - 2023-10-31 22:50:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 147
ERROR - 2023-10-31 22:50:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 148
ERROR - 2023-10-31 22:50:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 215
ERROR - 2023-10-31 22:50:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 216
ERROR - 2023-10-31 22:50:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 3
ERROR - 2023-10-31 22:50:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 10
ERROR - 2023-10-31 22:50:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 13
ERROR - 2023-10-31 22:50:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 16
ERROR - 2023-10-31 22:50:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 19
ERROR - 2023-10-31 22:50:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 22
ERROR - 2023-10-31 22:50:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 25
ERROR - 2023-10-31 22:50:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 147
ERROR - 2023-10-31 22:50:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 148
ERROR - 2023-10-31 22:50:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 215
ERROR - 2023-10-31 22:50:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 216
ERROR - 2023-10-31 22:50:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 3
ERROR - 2023-10-31 22:50:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 10
ERROR - 2023-10-31 22:50:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 13
ERROR - 2023-10-31 22:50:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 16
ERROR - 2023-10-31 22:50:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 19
ERROR - 2023-10-31 22:50:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 22
ERROR - 2023-10-31 22:50:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 25
ERROR - 2023-10-31 22:50:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 147
ERROR - 2023-10-31 22:50:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 148
ERROR - 2023-10-31 22:50:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 215
ERROR - 2023-10-31 22:50:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 216
ERROR - 2023-10-31 15:51:17 --> 404 Page Not Found: panitia/daftar_paket/Daftar_paket/get_byid_mengikuti
ERROR - 2023-10-31 23:03:33 --> Severity: Notice --> Undefined offset: 9 C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 967
ERROR - 2023-10-31 23:03:34 --> Severity: Notice --> Undefined offset: 9 C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 967
ERROR - 2023-10-31 23:35:16 --> Severity: Notice --> Undefined property: stdClass::$ev_akhir C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 92
ERROR - 2023-10-31 23:35:16 --> Severity: Notice --> Undefined property: stdClass::$ev_akhir C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 92
ERROR - 2023-10-31 23:35:22 --> Severity: Notice --> Undefined property: stdClass::$ev_akhir C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 92
ERROR - 2023-10-31 23:35:22 --> Severity: Notice --> Undefined property: stdClass::$ev_akhir C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 92
ERROR - 2023-10-31 23:35:27 --> Severity: Notice --> Undefined property: stdClass::$ev_akhir C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 92
ERROR - 2023-10-31 23:35:27 --> Severity: Notice --> Undefined property: stdClass::$ev_akhir C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 92
ERROR - 2023-10-31 23:43:59 --> Severity: Notice --> Undefined index: nama_metode_pemilihan C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 49
ERROR - 2023-10-31 23:44:59 --> Severity: Notice --> Undefined index: nama_metode_pemilihan C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\evaluasi.php 49
ERROR - 2023-10-31 17:19:39 --> 404 Page Not Found: panitia/info_tender/Informasi_tender/simpan_evaluasi_penawaran
ERROR - 2023-10-31 17:19:45 --> 404 Page Not Found: panitia/info_tender/Informasi_tender/simpan_evaluasi_penawaran

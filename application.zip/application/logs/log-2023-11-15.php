<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-15 14:32:39 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\laragon\www\jmto-eproc\application\libraries\Role_login.php 21
ERROR - 2023-11-15 19:54:12 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\laragon\www\jmto-eproc\application\libraries\Role_login.php 21
ERROR - 2023-11-15 19:57:27 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 171
ERROR - 2023-11-15 19:57:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 968
ERROR - 2023-11-15 19:57:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 921
ERROR - 2023-11-15 19:57:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1194
ERROR - 2023-11-15 20:09:48 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 171
ERROR - 2023-11-15 20:09:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1194
ERROR - 2023-11-15 20:09:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 968
ERROR - 2023-11-15 20:09:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 921
ERROR - 2023-11-15 20:10:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 968
ERROR - 2023-11-15 20:10:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 921
ERROR - 2023-11-15 20:10:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1194
ERROR - 2023-11-15 20:10:22 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 171
ERROR - 2023-11-15 20:13:35 --> Severity: Notice --> Array to string conversion C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 57
ERROR - 2023-11-15 20:14:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 58
ERROR - 2023-11-15 20:49:47 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 367
ERROR - 2023-11-15 20:49:47 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 367
ERROR - 2023-11-15 20:51:12 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 367
ERROR - 2023-11-15 20:51:12 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 367
ERROR - 2023-11-15 20:51:29 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 367
ERROR - 2023-11-15 20:51:29 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 367
ERROR - 2023-11-15 20:51:45 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 367
ERROR - 2023-11-15 20:51:45 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 367
ERROR - 2023-11-15 20:52:07 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 367
ERROR - 2023-11-15 20:52:07 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 367
ERROR - 2023-11-15 20:56:38 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 367
ERROR - 2023-11-15 20:56:38 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 367
ERROR - 2023-11-15 20:56:41 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 411
ERROR - 2023-11-15 20:56:41 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 411
ERROR - 2023-11-15 20:56:49 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 411
ERROR - 2023-11-15 20:56:49 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 411
ERROR - 2023-11-15 20:56:53 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 411
ERROR - 2023-11-15 20:56:53 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 411
ERROR - 2023-11-15 20:56:59 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 367
ERROR - 2023-11-15 20:56:59 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 367
ERROR - 2023-11-15 20:57:08 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 367
ERROR - 2023-11-15 20:57:08 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 367
ERROR - 2023-11-15 20:57:15 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 367
ERROR - 2023-11-15 20:57:15 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 367
ERROR - 2023-11-15 20:57:28 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 367
ERROR - 2023-11-15 20:57:28 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 367
ERROR - 2023-11-15 20:57:35 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 367
ERROR - 2023-11-15 20:57:35 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 367
ERROR - 2023-11-15 21:22:56 --> Severity: Notice --> Undefined variable: jadwal_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 394
ERROR - 2023-11-15 21:22:56 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 394
ERROR - 2023-11-15 21:23:04 --> Severity: Notice --> Undefined variable: jadwal_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 394
ERROR - 2023-11-15 21:23:04 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 394
ERROR - 2023-11-15 21:43:05 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:43:05 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:43:05 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:43:05 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:43:05 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:43:05 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:43:05 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:43:05 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:43:05 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:43:05 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:43:05 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:43:05 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:43:05 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:43:05 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:43:05 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:43:05 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:43:05 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:43:05 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:43:06 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:43:06 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:43:06 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:43:06 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:43:06 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:43:06 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:43:06 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:43:06 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:43:06 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:43:06 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:43:06 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:43:06 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:43:06 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:43:06 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:43:06 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:43:06 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:43:06 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:43:06 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:43:06 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:43:06 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:43:06 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:43:06 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:43:06 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:43:06 --> Severity: Notice --> Uninitialized string offset: 0 C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:17 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 390
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 390
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 390
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 390
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 390
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 390
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 390
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 390
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 390
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 390
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 390
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 390
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 390
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 390
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 390
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 390
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 390
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 390
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 390
ERROR - 2023-11-15 21:47:51 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:52 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 390
ERROR - 2023-11-15 21:47:52 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:52 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 390
ERROR - 2023-11-15 21:47:52 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:47:52 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 390
ERROR - 2023-11-15 21:47:52 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 391
ERROR - 2023-11-15 21:49:34 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 21:58:27 --> Severity: error --> Exception: Call to undefined method M_panitia::update_jadwal_rup_tender_terbatas_18_jadwal() C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 54
ERROR - 2023-11-15 21:58:32 --> Severity: error --> Exception: Call to undefined method M_panitia::update_jadwal_rup_tender_terbatas_18_jadwal() C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 54
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 393
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 393
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 393
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 393
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 393
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 393
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 393
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 393
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 393
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 393
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 393
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 393
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 393
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 393
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 393
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 393
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 393
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 393
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 393
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 393
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_mulai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 392
ERROR - 2023-11-15 22:06:40 --> Severity: Notice --> Undefined index: waktu_selesai C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 393
ERROR - 2023-11-15 15:18:40 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-15 22:18:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1367
ERROR - 2023-11-15 22:18:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1368
ERROR - 2023-11-15 22:18:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1367
ERROR - 2023-11-15 22:18:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1368
ERROR - 2023-11-15 22:18:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1367
ERROR - 2023-11-15 22:18:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1368
ERROR - 2023-11-15 22:18:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1367
ERROR - 2023-11-15 22:18:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1368
ERROR - 2023-11-15 22:18:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 935
ERROR - 2023-11-15 22:18:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 936
ERROR - 2023-11-15 22:18:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 935
ERROR - 2023-11-15 22:18:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 936
ERROR - 2023-11-15 22:18:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 935
ERROR - 2023-11-15 22:18:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 936
ERROR - 2023-11-15 22:18:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 935
ERROR - 2023-11-15 22:18:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 936
ERROR - 2023-11-15 22:18:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 946
ERROR - 2023-11-15 22:18:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 947
ERROR - 2023-11-15 22:18:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 946
ERROR - 2023-11-15 22:18:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 947
ERROR - 2023-11-15 22:18:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 946
ERROR - 2023-11-15 22:18:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 947
ERROR - 2023-11-15 22:18:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 946
ERROR - 2023-11-15 22:18:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 947
ERROR - 2023-11-15 15:18:49 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-15 22:19:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\aanwijzing.php 499
ERROR - 2023-11-15 22:19:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\aanwijzing.php 499
ERROR - 2023-11-15 22:19:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\aanwijzing.php 517
ERROR - 2023-11-15 22:19:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\aanwijzing.php 520
ERROR - 2023-11-15 15:19:42 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-15 22:20:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 922
ERROR - 2023-11-15 22:20:15 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 172
ERROR - 2023-11-15 22:20:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1195
ERROR - 2023-11-15 22:20:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 969
ERROR - 2023-11-15 22:21:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 969
ERROR - 2023-11-15 22:21:39 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 172
ERROR - 2023-11-15 22:21:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 922
ERROR - 2023-11-15 22:21:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1195
ERROR - 2023-11-15 22:21:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 694
ERROR - 2023-11-15 22:21:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 695
ERROR - 2023-11-15 22:21:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 694
ERROR - 2023-11-15 22:21:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 695
ERROR - 2023-11-15 22:21:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 694
ERROR - 2023-11-15 22:21:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 695
ERROR - 2023-11-15 22:21:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 694
ERROR - 2023-11-15 22:21:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 695
ERROR - 2023-11-15 15:25:50 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-15 22:26:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 694
ERROR - 2023-11-15 22:26:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 695
ERROR - 2023-11-15 22:26:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 694
ERROR - 2023-11-15 22:26:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 695
ERROR - 2023-11-15 22:26:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 694
ERROR - 2023-11-15 22:26:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 695
ERROR - 2023-11-15 22:26:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 694
ERROR - 2023-11-15 22:26:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 695
ERROR - 2023-11-15 22:27:53 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 172
ERROR - 2023-11-15 22:27:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 969
ERROR - 2023-11-15 22:27:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 922
ERROR - 2023-11-15 22:27:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1195
ERROR - 2023-11-15 22:33:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 694
ERROR - 2023-11-15 22:33:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 695
ERROR - 2023-11-15 22:33:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 694
ERROR - 2023-11-15 22:33:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 695
ERROR - 2023-11-15 22:33:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 694
ERROR - 2023-11-15 22:33:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 695
ERROR - 2023-11-15 22:33:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 694
ERROR - 2023-11-15 22:33:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 695

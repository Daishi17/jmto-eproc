<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-29 01:10:05 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 171
ERROR - 2023-10-29 01:10:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1167
ERROR - 2023-10-29 01:10:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 940
ERROR - 2023-10-29 01:10:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 893
ERROR - 2023-10-29 15:02:54 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\laragon\www\jmto-eproc\application\libraries\Role_login.php 21
ERROR - 2023-10-29 15:03:02 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\laragon\www\jmto-eproc\application\libraries\Role_login.php 21
ERROR - 2023-10-29 11:00:35 --> 404 Page Not Found: File_paket/DOKUMEN_PENGADAAN
ERROR - 2023-10-29 11:01:28 --> 404 Page Not Found: File_paket/DOKUMEN_PENGADAAN
ERROR - 2023-10-29 11:01:32 --> 404 Page Not Found: File_paket/DOKUMEN_PENGADAAN
ERROR - 2023-10-29 19:53:17 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-29 19:53:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 939
ERROR - 2023-10-29 19:53:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1165
ERROR - 2023-10-29 19:53:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 892
ERROR - 2023-10-29 12:53:36 --> 404 Page Not Found: panitia/daftar_paket/Daftar_paket/url_download_syarat_tambahan8
ERROR - 2023-10-29 13:00:12 --> 404 Page Not Found: panitia/daftar_paket/Daftar_paket/url_download_syarat_tambahan10
ERROR - 2023-10-29 13:01:13 --> 404 Page Not Found: panitia/daftar_paket/Daftar_paket/url_download_syarat_tambahan10
ERROR - 2023-10-29 20:01:36 --> Query error: Table 'u1064384_eprocjmto.tbl_paket' doesn't exist - Invalid query: SELECT *
FROM `tbl_syarat_tambahan_rup`
LEFT JOIN `tbl_paket` ON `tbl_syarat_tambahan_rup`.`id_rup` = `tbl_paket`.`id_rup`
WHERE `tbl_syarat_tambahan_rup`.`id_syarat_tambahan` = '10'
ERROR - 2023-10-29 20:02:07 --> Query error: Table 'u1064384_eprocjmto.tbl_paket' doesn't exist - Invalid query: SELECT *
FROM `tbl_syarat_tambahan_rup`
LEFT JOIN `tbl_paket` ON `tbl_syarat_tambahan_rup`.`id_rup` = `tbl_paket`.`id_rup`
WHERE `tbl_syarat_tambahan_rup`.`id_syarat_tambahan` = '10'
ERROR - 2023-10-29 13:02:23 --> 404 Page Not Found: File_paket/PAKET%20TESTING%20TENDER%20UMUM
ERROR - 2023-10-29 20:50:27 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-29 20:50:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 892
ERROR - 2023-10-29 20:50:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 939
ERROR - 2023-10-29 20:50:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1165
ERROR - 2023-10-29 20:50:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 939
ERROR - 2023-10-29 20:50:35 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-29 20:50:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 892
ERROR - 2023-10-29 20:50:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1165
ERROR - 2023-10-29 20:51:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 892
ERROR - 2023-10-29 20:51:01 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 170
ERROR - 2023-10-29 20:51:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1165
ERROR - 2023-10-29 20:51:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 939
ERROR - 2023-10-29 15:08:00 --> 404 Page Not Found: panitia/info_tender/Informasi_tender/index

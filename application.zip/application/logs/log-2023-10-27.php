<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-27 16:41:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 141
ERROR - 2023-10-27 16:41:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 142
ERROR - 2023-10-27 16:41:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 844
ERROR - 2023-10-27 16:41:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 797
ERROR - 2023-10-27 16:41:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1070

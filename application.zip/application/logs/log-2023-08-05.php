<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-05 00:24:15 --> Severity: error --> Exception: Too few arguments to function Fm_unit_kerja::byid(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_kerja.php 135
ERROR - 2023-08-05 00:24:27 --> Severity: error --> Exception: Too few arguments to function Fm_unit_kerja::byid(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Fm_unit_kerja.php 135

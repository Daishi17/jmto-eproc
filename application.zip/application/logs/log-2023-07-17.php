<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-17 02:58:38 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-17 03:02:40 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-17 03:28:17 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-17 05:27:42 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-17 05:37:16 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-17 05:49:16 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-17 06:14:58 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-17 07:33:35 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-17 07:56:47 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-17 07:57:39 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-17 07:58:59 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-17 07:59:27 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-17 08:29:19 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-17 08:29:33 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-17 09:26:44 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-17 09:26:59 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-17 09:48:03 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-17 09:50:05 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-17 09:50:47 --> 404 Page Not Found: Images/bg

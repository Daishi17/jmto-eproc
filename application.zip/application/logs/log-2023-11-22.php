<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-22 00:20:45 --> Severity: error --> Exception: Call to undefined method M_panitia::data_vendor_lolos_skdp_kbli() C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 427
ERROR - 2023-11-22 00:20:54 --> Severity: error --> Exception: Call to undefined method M_panitia::data_vendor_lolos_skdp_kbli() C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 427
ERROR - 2023-11-22 00:21:54 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 262
ERROR - 2023-11-22 00:21:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1032
ERROR - 2023-11-22 00:21:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1079
ERROR - 2023-11-22 00:21:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1310
ERROR - 2023-11-22 00:22:08 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 262
ERROR - 2023-11-22 00:22:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1032
ERROR - 2023-11-22 00:22:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1079
ERROR - 2023-11-22 00:22:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1310
ERROR - 2023-11-22 00:22:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1079
ERROR - 2023-11-22 00:22:27 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 262
ERROR - 2023-11-22 00:22:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1032
ERROR - 2023-11-22 00:22:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1310
ERROR - 2023-11-22 00:24:42 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 262
ERROR - 2023-11-22 00:24:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1079
ERROR - 2023-11-22 00:24:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1032
ERROR - 2023-11-22 00:24:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1310
ERROR - 2023-11-22 06:12:30 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-22 06:12:32 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-22 06:26:02 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-22 13:26:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1468
ERROR - 2023-11-22 13:26:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1469
ERROR - 2023-11-22 13:26:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1468
ERROR - 2023-11-22 13:26:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1469
ERROR - 2023-11-22 13:26:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1468
ERROR - 2023-11-22 13:26:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1469
ERROR - 2023-11-22 13:26:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1468
ERROR - 2023-11-22 13:26:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1469
ERROR - 2023-11-22 06:38:51 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-22 06:43:10 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1329
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1330
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1330
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 426
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Undefined index: draw C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 474
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:45:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1300
ERROR - 2023-11-22 13:47:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 992
ERROR - 2023-11-22 13:47:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 993
ERROR - 2023-11-22 13:47:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 992
ERROR - 2023-11-22 13:47:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 993
ERROR - 2023-11-22 13:47:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 992
ERROR - 2023-11-22 13:47:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 993
ERROR - 2023-11-22 13:47:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 992
ERROR - 2023-11-22 13:47:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 993
ERROR - 2023-11-22 13:47:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 13:47:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 13:47:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 13:47:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 13:47:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 13:47:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 13:47:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 13:47:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 13:47:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 992
ERROR - 2023-11-22 13:47:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 993
ERROR - 2023-11-22 13:47:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 992
ERROR - 2023-11-22 13:47:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 993
ERROR - 2023-11-22 13:47:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 992
ERROR - 2023-11-22 13:47:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 993
ERROR - 2023-11-22 13:47:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 992
ERROR - 2023-11-22 13:47:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 993
ERROR - 2023-11-22 13:48:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 13:48:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 13:48:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 13:48:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 13:48:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 13:48:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 13:48:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 13:48:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 06:48:33 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-22 13:48:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 13:48:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 13:48:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 13:48:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 13:48:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 13:48:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 13:48:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 13:48:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 13:48:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 13:48:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 13:48:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 13:48:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 13:48:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 13:48:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 13:48:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 13:48:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 13:49:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 13:49:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 13:49:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 13:49:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 13:49:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 13:49:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 13:49:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 13:49:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 13:49:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 992
ERROR - 2023-11-22 13:49:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 993
ERROR - 2023-11-22 13:49:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 992
ERROR - 2023-11-22 13:49:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 993
ERROR - 2023-11-22 13:49:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 992
ERROR - 2023-11-22 13:49:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 993
ERROR - 2023-11-22 13:49:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 992
ERROR - 2023-11-22 13:49:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 993
ERROR - 2023-11-22 13:49:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1003
ERROR - 2023-11-22 13:49:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1004
ERROR - 2023-11-22 13:49:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1003
ERROR - 2023-11-22 13:49:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1004
ERROR - 2023-11-22 13:49:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1003
ERROR - 2023-11-22 13:49:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1004
ERROR - 2023-11-22 13:49:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1003
ERROR - 2023-11-22 13:49:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1004
ERROR - 2023-11-22 13:49:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 992
ERROR - 2023-11-22 13:49:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 993
ERROR - 2023-11-22 13:49:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 992
ERROR - 2023-11-22 13:49:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 993
ERROR - 2023-11-22 13:49:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 992
ERROR - 2023-11-22 13:49:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 993
ERROR - 2023-11-22 13:49:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 13:49:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 13:49:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 13:49:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 13:49:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 992
ERROR - 2023-11-22 13:49:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 993
ERROR - 2023-11-22 13:49:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 992
ERROR - 2023-11-22 13:49:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 993
ERROR - 2023-11-22 13:49:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 992
ERROR - 2023-11-22 13:49:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 993
ERROR - 2023-11-22 13:49:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 992
ERROR - 2023-11-22 13:49:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 993
ERROR - 2023-11-22 13:49:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 13:49:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 13:49:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 13:49:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 13:49:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 13:49:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 13:49:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 13:49:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 06:59:26 --> 404 Page Not Found: panitia/info_tender/Dokumen_tender/dokumen_prakualifikasi
ERROR - 2023-11-22 06:59:33 --> 404 Page Not Found: panitia/info_tender/Dokumen_tender/dokumen_prakualifikasi
ERROR - 2023-11-22 06:59:47 --> 404 Page Not Found: panitia/info_tender/Dokumen_tender/dokumen_prakualifikasi
ERROR - 2023-11-22 07:00:41 --> 404 Page Not Found: panitia/info_tender/Dokumen_tender/test
ERROR - 2023-11-22 07:02:30 --> 404 Page Not Found: panitia/info_tender/Dokumen_tender/dokumen_prakualifikasi
ERROR - 2023-11-22 07:02:38 --> 404 Page Not Found: panitia/info_tender/Dokumen_tender/dokumen_prakualifikasi
ERROR - 2023-11-22 07:02:40 --> 404 Page Not Found: panitia/info_tender/Dokumen_tender/test
ERROR - 2023-11-22 14:02:46 --> Severity: error --> Exception: Call to undefined function force_download() C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 12
ERROR - 2023-11-22 14:23:53 --> Severity: error --> Exception: Too few arguments to function Dokumen_tender::prakualifikasi(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 17
ERROR - 2023-11-22 07:24:04 --> 404 Page Not Found: panitia/info_tender/Dokumen_tender/test
ERROR - 2023-11-22 14:24:04 --> Severity: error --> Exception: Too few arguments to function Dokumen_tender::prakualifikasi(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 17
ERROR - 2023-11-22 14:24:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 14:24:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 14:24:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 14:24:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 14:24:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 14:24:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 14:24:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 14:24:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 14:34:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 20
ERROR - 2023-11-22 14:34:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 21
ERROR - 2023-11-22 14:34:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 21
ERROR - 2023-11-22 14:36:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 20
ERROR - 2023-11-22 14:36:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 21
ERROR - 2023-11-22 14:36:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 21
ERROR - 2023-11-22 14:37:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 20
ERROR - 2023-11-22 14:37:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 21
ERROR - 2023-11-22 14:37:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 21
ERROR - 2023-11-22 14:38:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 20
ERROR - 2023-11-22 14:38:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 21
ERROR - 2023-11-22 14:38:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 21
ERROR - 2023-11-22 14:38:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 20
ERROR - 2023-11-22 14:38:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 21
ERROR - 2023-11-22 14:38:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 21
ERROR - 2023-11-22 14:39:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 20
ERROR - 2023-11-22 14:39:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 21
ERROR - 2023-11-22 14:39:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 21
ERROR - 2023-11-22 14:39:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 20
ERROR - 2023-11-22 14:39:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 21
ERROR - 2023-11-22 14:39:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 21
ERROR - 2023-11-22 14:40:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 20
ERROR - 2023-11-22 14:40:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 21
ERROR - 2023-11-22 14:40:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 21
ERROR - 2023-11-22 14:42:55 --> Severity: error --> Exception: Too few arguments to function Dokumen_tender::syarat_tambahan(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 31
ERROR - 2023-11-22 14:50:05 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 262
ERROR - 2023-11-22 14:50:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1032
ERROR - 2023-11-22 14:50:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1079
ERROR - 2023-11-22 14:50:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1310
ERROR - 2023-11-22 07:52:24 --> 404 Page Not Found: File_paket/Paket%20Tahun%20Baru%202024
ERROR - 2023-11-22 07:52:32 --> 404 Page Not Found: File_paket/Paket%20Tahun%20Baru%202024
ERROR - 2023-11-22 07:56:04 --> 404 Page Not Found: PEKERJAAN_BONGKAR_PASANG_ATAP_RUMAH_WALET_DI_BALIpdf/index
ERROR - 2023-11-22 07:56:06 --> 404 Page Not Found: PEKERJAAN_BONGKAR_PASANG_ATAP_RUMAH_WALET_DI_BALIpdf/index
ERROR - 2023-11-22 07:56:11 --> 404 Page Not Found: PEKERJAAN_BONGKAR_PASANG_ATAP_RUMAH_WALET_DI_BALIpdf/index
ERROR - 2023-11-22 08:02:09 --> 404 Page Not Found: PEKERJAAN_BONGKAR_PASANG_ATAP_RUMAH_WALET_DI_BALIpdf/index
ERROR - 2023-11-22 15:08:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 47
ERROR - 2023-11-22 15:08:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Dokumen_tender.php 47
ERROR - 2023-11-22 08:29:44 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-22 08:29:45 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-22 15:29:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 15:29:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 15:29:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 15:29:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 15:29:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1497
ERROR - 2023-11-22 15:29:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1498
ERROR - 2023-11-22 15:29:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1003
ERROR - 2023-11-22 15:29:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1004
ERROR - 2023-11-22 15:29:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1003
ERROR - 2023-11-22 15:29:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1004
ERROR - 2023-11-22 15:29:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1003
ERROR - 2023-11-22 15:29:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1004
ERROR - 2023-11-22 15:29:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1003
ERROR - 2023-11-22 15:29:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1004
ERROR - 2023-11-22 15:29:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 992
ERROR - 2023-11-22 15:29:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 993
ERROR - 2023-11-22 15:29:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 992
ERROR - 2023-11-22 15:29:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 993
ERROR - 2023-11-22 15:29:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 992
ERROR - 2023-11-22 15:29:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 993
ERROR - 2023-11-22 15:29:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 992
ERROR - 2023-11-22 15:29:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 993
ERROR - 2023-11-22 15:57:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 992
ERROR - 2023-11-22 15:57:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 993
ERROR - 2023-11-22 15:57:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 992
ERROR - 2023-11-22 15:57:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 993
ERROR - 2023-11-22 15:57:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 992
ERROR - 2023-11-22 15:57:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 993
ERROR - 2023-11-22 15:57:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 992
ERROR - 2023-11-22 15:57:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 993
ERROR - 2023-11-22 11:02:25 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-11-22 11:02:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-11-22 11:02:25 --> Unable to connect to the database
ERROR - 2023-11-22 11:02:25 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-11-22 11:02:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-11-22 11:02:25 --> Unable to connect to the database
ERROR - 2023-11-22 18:23:59 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1632
ERROR - 2023-11-22 18:23:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1632
ERROR - 2023-11-22 18:23:59 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1632
ERROR - 2023-11-22 18:23:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1632
ERROR - 2023-11-22 18:23:59 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1661
ERROR - 2023-11-22 18:23:59 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1662
ERROR - 2023-11-22 18:23:59 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1662
ERROR - 2023-11-22 18:23:59 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1143
ERROR - 2023-11-22 18:23:59 --> Severity: Notice --> Undefined index: draw C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1157
ERROR - 2023-11-22 18:23:59 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1632
ERROR - 2023-11-22 18:23:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1632
ERROR - 2023-11-22 18:23:59 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1632
ERROR - 2023-11-22 18:23:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1632
ERROR - 2023-11-22 18:31:27 --> Severity: Notice --> Undefined offset: 2 C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1652
ERROR - 2023-11-22 18:31:27 --> Severity: Notice --> Undefined offset: 2 C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1652
ERROR - 2023-11-22 11:42:00 --> Severity: error --> Exception: syntax error, unexpected ''" class="btn btn-info btn-sm ' (T_CONSTANT_ENCAPSED_STRING) C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1155
ERROR - 2023-11-22 18:49:46 --> Severity: Notice --> Undefined property: stdClass::$file_dokumen_pengadaan_vendor C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1199
ERROR - 2023-11-22 18:51:12 --> Query error: Unknown column 'tbl_vendor_mengikuti_paket.sts_mengikuti_paket' in 'where clause' - Invalid query: SELECT *
FROM `tbl_vendor_dokumen_pengadaan`
LEFT JOIN `tbl_rup` ON `tbl_vendor_dokumen_pengadaan`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_dokumen_pengadaan`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_dokumen_pengadaan`.`id_rup` = '166'
AND `tbl_vendor_dokumen_pengadaan`.`id_vendor` = '139'
AND `tbl_vendor_mengikuti_paket`.`sts_mengikuti_paket` = 1
ORDER BY `tbl_vendor_dokumen_pengadaan`.`id_dokumen_pengadaan_vendor` DESC
 LIMIT 10
ERROR - 2023-11-22 18:51:15 --> Query error: Unknown column 'tbl_vendor_mengikuti_paket.sts_mengikuti_paket' in 'where clause' - Invalid query: SELECT *
FROM `tbl_vendor_dokumen_pengadaan`
LEFT JOIN `tbl_rup` ON `tbl_vendor_dokumen_pengadaan`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_dokumen_pengadaan`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_dokumen_pengadaan`.`id_rup` = '166'
AND `tbl_vendor_dokumen_pengadaan`.`id_vendor` = '86'
AND `tbl_vendor_mengikuti_paket`.`sts_mengikuti_paket` = 1
ORDER BY `tbl_vendor_dokumen_pengadaan`.`id_dokumen_pengadaan_vendor` DESC
 LIMIT 10
ERROR - 2023-11-22 18:51:18 --> Query error: Unknown column 'tbl_vendor_mengikuti_paket.sts_mengikuti_paket' in 'where clause' - Invalid query: SELECT *
FROM `tbl_vendor_dokumen_pengadaan`
LEFT JOIN `tbl_rup` ON `tbl_vendor_dokumen_pengadaan`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_dokumen_pengadaan`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_dokumen_pengadaan`.`id_rup` = '166'
AND `tbl_vendor_dokumen_pengadaan`.`id_vendor` = '86'
AND `tbl_vendor_mengikuti_paket`.`sts_mengikuti_paket` = 1
ORDER BY `tbl_vendor_dokumen_pengadaan`.`id_dokumen_pengadaan_vendor` DESC
 LIMIT 10
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1597
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1598
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1598
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1098
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Undefined index: draw C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1129
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1597
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1598
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1598
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1098
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Undefined index: draw C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_2_file.php 1129
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 18:52:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1568
ERROR - 2023-11-22 19:40:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1032
ERROR - 2023-11-22 19:40:36 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 262
ERROR - 2023-11-22 19:40:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1079
ERROR - 2023-11-22 19:40:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1310
ERROR - 2023-11-22 19:50:25 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 262
ERROR - 2023-11-22 19:50:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1079
ERROR - 2023-11-22 19:50:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1032
ERROR - 2023-11-22 19:50:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1310
ERROR - 2023-11-22 19:51:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1079
ERROR - 2023-11-22 19:51:58 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 262
ERROR - 2023-11-22 19:51:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1032
ERROR - 2023-11-22 19:51:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1310
ERROR - 2023-11-22 19:52:05 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 262
ERROR - 2023-11-22 19:52:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1079
ERROR - 2023-11-22 19:52:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1032
ERROR - 2023-11-22 19:52:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1310
ERROR - 2023-11-22 19:52:44 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 262
ERROR - 2023-11-22 19:52:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1032
ERROR - 2023-11-22 19:52:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1079
ERROR - 2023-11-22 19:52:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1310
ERROR - 2023-11-22 19:52:59 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 262
ERROR - 2023-11-22 19:52:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1079
ERROR - 2023-11-22 19:52:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1032
ERROR - 2023-11-22 19:52:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1310
ERROR - 2023-11-22 20:07:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 222
ERROR - 2023-11-22 20:07:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 226
ERROR - 2023-11-22 20:07:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 226
ERROR - 2023-11-22 21:13:15 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 262
ERROR - 2023-11-22 21:13:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1032
ERROR - 2023-11-22 21:13:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1079
ERROR - 2023-11-22 21:13:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1310
ERROR - 2023-11-22 22:07:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1032
ERROR - 2023-11-22 22:07:38 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 262
ERROR - 2023-11-22 22:07:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1079
ERROR - 2023-11-22 22:07:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1310
ERROR - 2023-11-22 22:09:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1032
ERROR - 2023-11-22 22:09:21 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 262
ERROR - 2023-11-22 22:09:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1079
ERROR - 2023-11-22 22:09:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1310
ERROR - 2023-11-22 22:09:52 --> Severity: Warning --> Illegal string offset 'role_panitia' C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 511
ERROR - 2023-11-22 22:09:58 --> Severity: Warning --> Illegal string offset 'role_panitia' C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 511
ERROR - 2023-11-22 22:14:41 --> Severity: Warning --> Use of undefined constant condition - assumed 'condition' (this will throw an Error in a future version of PHP) C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 93
ERROR - 2023-11-22 22:14:41 --> Severity: Warning --> Use of undefined constant condition - assumed 'condition' (this will throw an Error in a future version of PHP) C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 93
ERROR - 2023-11-22 22:14:41 --> Severity: Warning --> Use of undefined constant condition - assumed 'condition' (this will throw an Error in a future version of PHP) C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 93
ERROR - 2023-11-22 22:14:41 --> Severity: Warning --> Use of undefined constant condition - assumed 'condition' (this will throw an Error in a future version of PHP) C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 93
ERROR - 2023-11-22 22:14:41 --> Severity: Warning --> Use of undefined constant condition - assumed 'condition' (this will throw an Error in a future version of PHP) C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 93
ERROR - 2023-11-22 22:14:41 --> Severity: Warning --> Use of undefined constant condition - assumed 'condition' (this will throw an Error in a future version of PHP) C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 93
ERROR - 2023-11-22 22:14:41 --> Severity: Warning --> Use of undefined constant condition - assumed 'condition' (this will throw an Error in a future version of PHP) C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 93
ERROR - 2023-11-22 22:14:41 --> Severity: Warning --> Use of undefined constant condition - assumed 'condition' (this will throw an Error in a future version of PHP) C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 93
ERROR - 2023-11-22 22:14:41 --> Severity: Warning --> Use of undefined constant condition - assumed 'condition' (this will throw an Error in a future version of PHP) C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 93
ERROR - 2023-11-22 22:14:41 --> Severity: Warning --> Use of undefined constant condition - assumed 'condition' (this will throw an Error in a future version of PHP) C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 93
ERROR - 2023-11-22 22:14:41 --> Severity: Warning --> Use of undefined constant condition - assumed 'condition' (this will throw an Error in a future version of PHP) C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 93
ERROR - 2023-11-22 22:14:41 --> Severity: Warning --> Use of undefined constant condition - assumed 'condition' (this will throw an Error in a future version of PHP) C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 93
ERROR - 2023-11-22 22:14:41 --> Severity: Warning --> Use of undefined constant condition - assumed 'condition' (this will throw an Error in a future version of PHP) C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 93
ERROR - 2023-11-22 22:14:41 --> Severity: Warning --> Use of undefined constant condition - assumed 'condition' (this will throw an Error in a future version of PHP) C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 93
ERROR - 2023-11-22 22:14:41 --> Severity: Warning --> Use of undefined constant condition - assumed 'condition' (this will throw an Error in a future version of PHP) C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 93
ERROR - 2023-11-22 22:14:41 --> Severity: Warning --> Use of undefined constant condition - assumed 'condition' (this will throw an Error in a future version of PHP) C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 93
ERROR - 2023-11-22 22:14:41 --> Severity: Warning --> Use of undefined constant condition - assumed 'condition' (this will throw an Error in a future version of PHP) C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 93
ERROR - 2023-11-22 22:14:41 --> Severity: Warning --> Use of undefined constant condition - assumed 'condition' (this will throw an Error in a future version of PHP) C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 93
ERROR - 2023-11-22 22:14:41 --> Severity: Warning --> Use of undefined constant condition - assumed 'condition' (this will throw an Error in a future version of PHP) C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 93
ERROR - 2023-11-22 22:14:41 --> Severity: Warning --> Use of undefined constant condition - assumed 'condition' (this will throw an Error in a future version of PHP) C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 93
ERROR - 2023-11-22 22:14:41 --> Severity: Warning --> Use of undefined constant condition - assumed 'condition' (this will throw an Error in a future version of PHP) C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 93
ERROR - 2023-11-22 22:14:41 --> Severity: Warning --> Use of undefined constant condition - assumed 'condition' (this will throw an Error in a future version of PHP) C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\jadwal_tender_terbatas\index.php 93
ERROR - 2023-11-22 22:41:04 --> Query error: Column 'id_rup' in order clause is ambiguous - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_panitia` ON `tbl_rup`.`id_rup` = `tbl_panitia`.`id_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `tbl_rup`.`status_paket_diumumkan` = 1
AND `tbl_rup`.`id_metode_pengadaan` = 4
AND `tbl_panitia`.`id_manajemen_user` = '21'
ORDER BY `id_rup` ASC
 LIMIT 10
ERROR - 2023-11-22 23:11:55 --> Severity: Warning --> mkdir(): Permission denied C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_buat_paket.php 217
ERROR - 2023-11-22 23:12:05 --> Severity: Warning --> mkdir(): Permission denied C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_buat_paket.php 217
ERROR - 2023-11-22 23:13:08 --> Severity: Warning --> mkdir(): Permission denied C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_buat_paket.php 217
ERROR - 2023-11-22 23:13:42 --> Severity: Warning --> mkdir(): Permission denied C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_buat_paket.php 217
ERROR - 2023-11-22 23:16:02 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 263
ERROR - 2023-11-22 23:16:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1033
ERROR - 2023-11-22 23:16:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1080
ERROR - 2023-11-22 23:16:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1311
ERROR - 2023-11-22 23:16:07 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 263
ERROR - 2023-11-22 23:16:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1033
ERROR - 2023-11-22 23:16:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1080
ERROR - 2023-11-22 23:16:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1311
ERROR - 2023-11-22 23:19:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1080
ERROR - 2023-11-22 23:19:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1033
ERROR - 2023-11-22 23:19:05 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 263
ERROR - 2023-11-22 23:19:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1311
ERROR - 2023-11-22 23:20:10 --> Severity: Notice --> Undefined index: id_kbli C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\form_daftar_paket.php 1034
ERROR - 2023-11-22 23:20:10 --> Severity: Notice --> Undefined index: kode_kbli C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\form_daftar_paket.php 1034
ERROR - 2023-11-22 23:20:10 --> Severity: Notice --> Undefined index: nama_kbli C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\form_daftar_paket.php 1034
ERROR - 2023-11-22 23:40:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1033
ERROR - 2023-11-22 23:40:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1080
ERROR - 2023-11-22 23:40:05 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 263
ERROR - 2023-11-22 23:40:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1311
ERROR - 2023-11-22 17:50:45 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-22 17:54:09 --> 404 Page Not Found: Assets/img

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-24 01:26:08 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-24 01:28:38 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-24 02:07:19 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-24 02:07:54 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-24 12:42:33 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-24 12:54:30 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-24 21:40:27 --> 404 Page Not Found: Images/bg

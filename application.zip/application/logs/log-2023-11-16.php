<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-16 08:16:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1367
ERROR - 2023-11-16 08:16:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1368
ERROR - 2023-11-16 08:16:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1367
ERROR - 2023-11-16 08:16:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1368
ERROR - 2023-11-16 08:16:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1367
ERROR - 2023-11-16 08:16:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1368
ERROR - 2023-11-16 08:16:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1367
ERROR - 2023-11-16 08:16:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1368
ERROR - 2023-11-16 08:16:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 935
ERROR - 2023-11-16 08:16:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 936
ERROR - 2023-11-16 08:16:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 935
ERROR - 2023-11-16 08:16:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 936
ERROR - 2023-11-16 08:16:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 935
ERROR - 2023-11-16 08:16:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 936
ERROR - 2023-11-16 08:16:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 935
ERROR - 2023-11-16 08:16:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 936
ERROR - 2023-11-16 08:16:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 946
ERROR - 2023-11-16 08:16:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 947
ERROR - 2023-11-16 08:16:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 946
ERROR - 2023-11-16 08:16:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 947
ERROR - 2023-11-16 08:16:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 946
ERROR - 2023-11-16 08:16:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 947
ERROR - 2023-11-16 08:16:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 946
ERROR - 2023-11-16 08:16:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 947
ERROR - 2023-11-16 01:16:56 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 01:17:40 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 01:17:51 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 01:20:23 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 08:20:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1367
ERROR - 2023-11-16 08:20:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1368
ERROR - 2023-11-16 08:20:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1367
ERROR - 2023-11-16 08:20:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1368
ERROR - 2023-11-16 08:20:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1367
ERROR - 2023-11-16 08:20:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1368
ERROR - 2023-11-16 08:20:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1367
ERROR - 2023-11-16 08:20:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1368
ERROR - 2023-11-16 08:20:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 935
ERROR - 2023-11-16 08:20:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 936
ERROR - 2023-11-16 08:20:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 935
ERROR - 2023-11-16 08:20:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 936
ERROR - 2023-11-16 08:20:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 935
ERROR - 2023-11-16 08:20:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 936
ERROR - 2023-11-16 08:20:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 935
ERROR - 2023-11-16 08:20:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 936
ERROR - 2023-11-16 01:20:27 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 08:20:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 946
ERROR - 2023-11-16 08:20:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 947
ERROR - 2023-11-16 08:20:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 946
ERROR - 2023-11-16 08:20:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 947
ERROR - 2023-11-16 08:20:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 946
ERROR - 2023-11-16 08:20:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 947
ERROR - 2023-11-16 08:20:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 946
ERROR - 2023-11-16 08:20:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 947
ERROR - 2023-11-16 01:20:52 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 01:20:57 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 01:21:13 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 08:21:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1367
ERROR - 2023-11-16 08:21:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1368
ERROR - 2023-11-16 08:21:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1367
ERROR - 2023-11-16 08:21:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1368
ERROR - 2023-11-16 01:22:21 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 08:27:27 --> Severity: Warning --> Use of undefined constant id_rup - assumed 'id_rup' (this will throw an Error in a future version of PHP) C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 93
ERROR - 2023-11-16 08:27:27 --> Severity: Warning --> Use of undefined constant id_rup - assumed 'id_rup' (this will throw an Error in a future version of PHP) C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 94
ERROR - 2023-11-16 08:27:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 146
ERROR - 2023-11-16 08:27:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 148
ERROR - 2023-11-16 08:27:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 148
ERROR - 2023-11-16 08:27:37 --> Severity: Warning --> Use of undefined constant id_rup - assumed 'id_rup' (this will throw an Error in a future version of PHP) C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 93
ERROR - 2023-11-16 08:27:37 --> Severity: Warning --> Use of undefined constant id_rup - assumed 'id_rup' (this will throw an Error in a future version of PHP) C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 94
ERROR - 2023-11-16 08:27:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 146
ERROR - 2023-11-16 08:27:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 148
ERROR - 2023-11-16 08:27:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 148
ERROR - 2023-11-16 01:42:46 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 08:42:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1395
ERROR - 2023-11-16 08:42:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1396
ERROR - 2023-11-16 08:42:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1395
ERROR - 2023-11-16 08:42:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1396
ERROR - 2023-11-16 01:42:51 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 01:44:21 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 01:44:22 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 01:45:06 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 01:45:18 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 08:45:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1408
ERROR - 2023-11-16 08:45:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1409
ERROR - 2023-11-16 08:45:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1408
ERROR - 2023-11-16 08:45:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1409
ERROR - 2023-11-16 08:45:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1408
ERROR - 2023-11-16 08:45:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1409
ERROR - 2023-11-16 08:45:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1408
ERROR - 2023-11-16 08:45:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1409
ERROR - 2023-11-16 08:45:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 08:45:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 08:45:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 08:45:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 08:45:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 08:45:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 08:45:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 08:45:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 08:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 08:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 08:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 08:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 08:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 08:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 08:45:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 08:45:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 01:45:25 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 08:45:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 08:45:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 08:45:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 08:45:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 08:45:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 08:45:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 08:45:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 08:45:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 01:46:00 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 01:46:01 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 08:46:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1408
ERROR - 2023-11-16 08:46:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1409
ERROR - 2023-11-16 08:46:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1408
ERROR - 2023-11-16 08:46:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1409
ERROR - 2023-11-16 08:46:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1408
ERROR - 2023-11-16 08:46:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1409
ERROR - 2023-11-16 08:46:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 08:46:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 08:46:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 08:46:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 08:46:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 08:46:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 08:46:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 08:46:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 08:46:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 08:46:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 08:46:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 08:46:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 08:46:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 08:46:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 08:46:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 08:46:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 01:46:15 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 01:46:18 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 01:47:23 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 01:47:24 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 01:47:33 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 08:49:16 --> Severity: Compile Error --> Cannot redeclare M_tender::tambah_chat() C:\laragon\www\jmto-eproc\application\models\M_tender\M_tender.php 52
ERROR - 2023-11-16 08:49:17 --> Severity: Compile Error --> Cannot redeclare M_tender::tambah_chat() C:\laragon\www\jmto-eproc\application\models\M_tender\M_tender.php 52
ERROR - 2023-11-16 08:49:18 --> Severity: Compile Error --> Cannot redeclare M_tender::tambah_chat() C:\laragon\www\jmto-eproc\application\models\M_tender\M_tender.php 52
ERROR - 2023-11-16 08:49:19 --> Severity: Compile Error --> Cannot redeclare M_tender::tambah_chat() C:\laragon\www\jmto-eproc\application\models\M_tender\M_tender.php 52
ERROR - 2023-11-16 01:52:55 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 01:52:57 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 01:52:58 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 01:53:04 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 01:53:06 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 08:53:29 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:53:30 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:53:31 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:53:32 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:53:33 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:53:34 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:53:35 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:53:36 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:53:37 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:53:38 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:53:39 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:53:40 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:53:41 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 01:53:41 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 08:53:42 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:53:43 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:53:44 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 01:53:45 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 08:53:45 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 01:53:46 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 08:53:46 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:53:47 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:53:48 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:53:50 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:53:50 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:53:52 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:53:53 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:53:54 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:53:55 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:53:56 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:53:57 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:53:58 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:53:59 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:53:59 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:00 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 01:54:01 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 01:54:04 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 08:54:04 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:05 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:06 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:07 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:08 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:09 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:10 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:11 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:12 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:13 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:14 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:15 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:16 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:17 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:18 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:19 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:20 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:21 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:22 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:23 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:24 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:25 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:26 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:27 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:28 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:29 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:30 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:31 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:32 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:33 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:34 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:35 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:36 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:37 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:38 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:39 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:40 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:41 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:42 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:43 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:44 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:45 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:46 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:47 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:48 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:49 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:50 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:51 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:52 --> Query error: Unknown column 'tbl_pesan.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:53 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:54 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 01:54:54 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 08:54:55 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:56 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:57 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:58 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:54:59 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:00 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:01 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:02 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:03 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:04 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:05 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:06 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:07 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:08 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:09 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:10 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:11 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:12 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:13 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:14 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:15 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:16 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:17 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:18 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:19 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:20 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:21 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:22 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:23 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:24 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:25 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:26 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:27 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:28 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 08:55:29 --> Query error: Unknown column 'tbl_pesan.id_pengirim' in 'on clause' - Invalid query: SELECT *
FROM `tbl_pesan_penawaran`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan_penawaran`.`id_rup` = '163'
ERROR - 2023-11-16 01:55:31 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 01:55:41 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 01:55:42 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 01:56:25 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 01:56:28 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 01:56:29 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 08:56:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 08:56:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 08:56:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 08:56:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 08:56:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 08:56:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 08:56:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 08:56:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 08:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 08:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 08:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 08:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 08:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 08:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 08:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 08:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 08:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 08:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 08:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 08:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 08:56:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 08:56:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 01:57:42 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 15:39:26 --> 404 Page Not Found: validator/Rekanan_terundang/get_rekanan_terundang
ERROR - 2023-11-16 15:43:23 --> 404 Page Not Found: validator/Rekanan_terundang/get_rekanan_terundang
ERROR - 2023-11-16 15:43:56 --> Severity: error --> Exception: Call to undefined method M_Rekanan_terundang::cek_vendor_tervalidasi_siup() C:\laragon\www\jmto-eproc\application\controllers\validator\Rekanan_terundang.php 102
ERROR - 2023-11-16 15:44:16 --> Severity: error --> Exception: Call to undefined method M_Rekanan_terundang::cek_vendor_tervalidasi_siup() C:\laragon\www\jmto-eproc\application\controllers\validator\Rekanan_terundang.php 103
ERROR - 2023-11-16 19:49:43 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\laragon\www\jmto-eproc\application\libraries\Role_login.php 21
ERROR - 2023-11-16 19:50:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 969
ERROR - 2023-11-16 19:50:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1195
ERROR - 2023-11-16 19:50:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 922
ERROR - 2023-11-16 19:50:25 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 172
ERROR - 2023-11-16 19:52:01 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\Get_rupiah.php 24
ERROR - 2023-11-16 19:52:01 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\Get_rupiah.php 24
ERROR - 2023-11-16 19:52:02 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\Get_rupiah.php 24
ERROR - 2023-11-16 19:52:02 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\Get_rupiah.php 24
ERROR - 2023-11-16 19:52:02 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\Get_rupiah.php 24
ERROR - 2023-11-16 19:52:02 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\Get_rupiah.php 24
ERROR - 2023-11-16 19:53:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 969
ERROR - 2023-11-16 19:53:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1195
ERROR - 2023-11-16 19:53:41 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 172
ERROR - 2023-11-16 19:53:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 922
ERROR - 2023-11-16 19:54:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 969
ERROR - 2023-11-16 19:54:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 922
ERROR - 2023-11-16 19:54:06 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 172
ERROR - 2023-11-16 19:54:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1195
ERROR - 2023-11-16 19:56:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 900
ERROR - 2023-11-16 19:56:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 911
ERROR - 2023-11-16 19:56:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 900
ERROR - 2023-11-16 20:13:35 --> Query error: Unknown column 'tbl_vendor.id_jenis_pengadaan' in 'where clause' - Invalid query: SELECT *
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_siup` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_siup`.`id_vendor`
LEFT JOIN `tbl_vendor_nib` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_nib`.`id_vendor`
LEFT JOIN `tbl_vendor_sbu` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_sbu`.`id_vendor`
LEFT JOIN `tbl_vendor_siujk` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_siujk`.`id_vendor`
LEFT JOIN `tbl_vendor_skdp` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_skdp`.`id_vendor`
WHERE `tbl_vendor`.`sts_terundang` = 1
AND `tbl_vendor`.`sts_daftar_hitam` IS NULL
AND  `tbl_vendor`.`id_jenis_pengadaan` LIKE '%1%' ESCAPE '!'
AND `tbl_vendor`.`kualifikasi_usaha` IN('Menengah', 'Besar')
AND `tbl_vendor`.`id_vendor` IS NULL
AND `tbl_vendor`.`id_vendor` IS NULL
AND `tbl_vendor`.`id_vendor` IS NULL
AND `tbl_vendor`.`id_vendor` IS NULL
AND `tbl_vendor`.`id_vendor` IS NULL
AND `tbl_vendor`.`id_vendor` IS NULL
AND `tbl_vendor`.`id_vendor` IS NULL
AND `tbl_vendor`.`id_vendor` IS NULL
AND `tbl_vendor`.`id_vendor` IS NULL
ERROR - 2023-11-16 22:09:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 904
ERROR - 2023-11-16 22:09:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 915
ERROR - 2023-11-16 22:09:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 904
ERROR - 2023-11-16 22:09:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 904
ERROR - 2023-11-16 22:10:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 904
ERROR - 2023-11-16 22:12:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 904
ERROR - 2023-11-16 22:12:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 915
ERROR - 2023-11-16 22:13:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 904
ERROR - 2023-11-16 22:15:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 904
ERROR - 2023-11-16 22:15:33 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=9316 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-11-16 22:15:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-11-16 22:15:33 --> Unable to connect to the database
ERROR - 2023-11-16 22:41:28 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 182
ERROR - 2023-11-16 22:41:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 932
ERROR - 2023-11-16 22:41:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 979
ERROR - 2023-11-16 22:41:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1205
ERROR - 2023-11-16 22:42:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 697
ERROR - 2023-11-16 22:42:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 698
ERROR - 2023-11-16 22:42:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 697
ERROR - 2023-11-16 22:42:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 698
ERROR - 2023-11-16 22:42:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 697
ERROR - 2023-11-16 22:42:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 698
ERROR - 2023-11-16 22:42:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 697
ERROR - 2023-11-16 22:42:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 698
ERROR - 2023-11-16 22:50:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 697
ERROR - 2023-11-16 22:50:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 698
ERROR - 2023-11-16 22:50:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 697
ERROR - 2023-11-16 22:50:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 698
ERROR - 2023-11-16 22:50:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 697
ERROR - 2023-11-16 22:50:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 698
ERROR - 2023-11-16 22:50:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 697
ERROR - 2023-11-16 22:50:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 698
ERROR - 2023-11-16 16:05:49 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:07:02 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 23:08:01 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 182
ERROR - 2023-11-16 23:08:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 932
ERROR - 2023-11-16 23:08:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 979
ERROR - 2023-11-16 23:08:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1205
ERROR - 2023-11-16 23:12:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 697
ERROR - 2023-11-16 23:12:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 698
ERROR - 2023-11-16 23:12:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 697
ERROR - 2023-11-16 23:12:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 698
ERROR - 2023-11-16 23:12:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 697
ERROR - 2023-11-16 23:12:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 698
ERROR - 2023-11-16 23:12:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 697
ERROR - 2023-11-16 23:12:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 698
ERROR - 2023-11-16 16:18:06 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:18:08 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 23:18:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:18:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:18:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:18:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:18:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:18:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:18:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:18:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:18:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 697
ERROR - 2023-11-16 23:18:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 698
ERROR - 2023-11-16 23:18:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 697
ERROR - 2023-11-16 23:18:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 698
ERROR - 2023-11-16 23:18:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 697
ERROR - 2023-11-16 23:18:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 698
ERROR - 2023-11-16 23:18:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 697
ERROR - 2023-11-16 23:18:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 698
ERROR - 2023-11-16 16:18:18 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:18:18 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 23:18:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 697
ERROR - 2023-11-16 23:18:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 698
ERROR - 2023-11-16 23:18:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 697
ERROR - 2023-11-16 23:18:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 698
ERROR - 2023-11-16 23:18:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 697
ERROR - 2023-11-16 23:18:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 698
ERROR - 2023-11-16 23:18:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 697
ERROR - 2023-11-16 23:18:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender_umum_pra_2_file\index.php 698
ERROR - 2023-11-16 16:19:27 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:19:33 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:19:34 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:20:50 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:20:52 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:21:51 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:21:51 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 23:21:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 23:21:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 23:21:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 23:21:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 23:21:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 23:21:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 23:21:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 23:21:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 23:21:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:21:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:21:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:21:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:21:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:21:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:21:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 23:21:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 23:21:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 23:21:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 23:21:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 23:21:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 23:21:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:21:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:21:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:21:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:21:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:21:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:21:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:21:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:21:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:21:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:21:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:21:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:21:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:21:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:21:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:21:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 16:21:59 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:22:00 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:22:01 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:32:58 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:32:59 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:33:31 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:33:32 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:33:37 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:33:38 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:33:39 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 23:34:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1205
ERROR - 2023-11-16 23:34:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 932
ERROR - 2023-11-16 23:34:19 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 182
ERROR - 2023-11-16 23:34:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 979
ERROR - 2023-11-16 16:42:40 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:42:41 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:43:56 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 23:44:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:44:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:44:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:44:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:44:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:44:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:44:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:44:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 16:44:23 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:44:24 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 23:44:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:44:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:44:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:44:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:44:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:44:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:44:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:44:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 16:45:01 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:45:10 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:45:11 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:45:22 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:45:23 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 23:45:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:45:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:45:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:45:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:45:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:45:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:45:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:45:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:45:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:45:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:45:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:45:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:45:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:45:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:45:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:45:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:45:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 979
ERROR - 2023-11-16 23:45:40 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 182
ERROR - 2023-11-16 23:45:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 932
ERROR - 2023-11-16 23:45:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1205
ERROR - 2023-11-16 23:46:01 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 182
ERROR - 2023-11-16 23:46:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 979
ERROR - 2023-11-16 23:46:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1205
ERROR - 2023-11-16 23:46:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 932
ERROR - 2023-11-16 23:49:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:49:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:49:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:49:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:49:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:49:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:49:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:49:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:49:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 23:49:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 23:49:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 23:49:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 23:49:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 23:49:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 23:49:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 23:49:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 23:49:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:49:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:49:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:49:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:49:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:49:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:49:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:49:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 16:49:51 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:49:52 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 23:49:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:49:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:49:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:49:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:49:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:49:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:49:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:49:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:49:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:49:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:49:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:49:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:49:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 23:49:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 23:49:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 23:49:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 23:49:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 23:49:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 23:49:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 23:49:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 23:49:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:49:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:49:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:49:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:49:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:49:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 16:50:01 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:50:01 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 23:50:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:50:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:50:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:50:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:50:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:50:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:50:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 23:50:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 23:50:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 23:50:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 23:50:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 23:50:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 23:50:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:50:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:50:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:50:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:50:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:50:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:50:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:50:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 16:50:25 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:50:26 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:50:26 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 23:51:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:51:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:51:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:51:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:51:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:51:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:51:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:51:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:51:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:51:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:51:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:51:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:51:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:51:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:51:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:51:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:51:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 23:51:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 23:51:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 23:51:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 23:51:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 23:51:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 23:51:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:51:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:51:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:51:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:51:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:51:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:51:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:51:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:51:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 23:51:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 23:51:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 23:51:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 23:51:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 23:51:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 23:52:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 23:52:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 23:52:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 23:52:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 23:52:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 23:52:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 23:52:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 963
ERROR - 2023-11-16 23:52:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 964
ERROR - 2023-11-16 23:52:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:52:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:52:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:52:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:52:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 974
ERROR - 2023-11-16 23:52:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 975
ERROR - 2023-11-16 23:52:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:52:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:52:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:52:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 23:52:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1469
ERROR - 2023-11-16 23:52:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 1470
ERROR - 2023-11-16 16:52:14 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:52:29 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:52:29 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:54:28 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:54:31 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:54:34 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:54:59 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-16 16:55:00 --> 404 Page Not Found: Assets/img

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-08 02:14:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-11-08 02:14:44 --> Unable to connect to the database
ERROR - 2023-11-08 02:41:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 895
ERROR - 2023-11-08 02:41:09 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 171
ERROR - 2023-11-08 02:41:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 942
ERROR - 2023-11-08 02:41:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1168
ERROR - 2023-11-08 02:54:07 --> Severity: Notice --> Undefined offset: 3 C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1344
ERROR - 2023-11-08 02:54:07 --> Severity: Notice --> Undefined offset: 3 C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1344
ERROR - 2023-11-08 03:31:56 --> Severity: Notice --> Array to string conversion C:\laragon\www\jmto-eproc\system\database\DB_query_builder.php 2443
ERROR - 2023-11-08 03:31:56 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `tbl_rup` SET `id_rup` = '156'
WHERE `id_rup` = Array
ERROR - 2023-11-08 03:32:16 --> Severity: Notice --> Array to string conversion C:\laragon\www\jmto-eproc\system\database\DB_query_builder.php 2443
ERROR - 2023-11-08 03:32:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '156 = ''
WHERE `id_rup` = Array' at line 1 - Invalid query: UPDATE `tbl_rup` SET 156 = ''
WHERE `id_rup` = Array
ERROR - 2023-11-08 03:32:23 --> Severity: Notice --> Array to string conversion C:\laragon\www\jmto-eproc\system\database\DB_query_builder.php 2443
ERROR - 2023-11-08 03:32:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '156 = ''
WHERE `id_rup` = Array' at line 1 - Invalid query: UPDATE `tbl_rup` SET 156 = ''
WHERE `id_rup` = Array
ERROR - 2023-11-08 04:05:47 --> Severity: Notice --> Undefined variable: variable C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 469
ERROR - 2023-11-08 04:05:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\informasi_tender\index.php 469
ERROR - 2023-11-08 14:25:55 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 171
ERROR - 2023-11-08 14:25:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 942
ERROR - 2023-11-08 14:25:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 895
ERROR - 2023-11-08 14:25:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1168
ERROR - 2023-11-08 14:26:02 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 171
ERROR - 2023-11-08 14:26:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 895
ERROR - 2023-11-08 14:26:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 942
ERROR - 2023-11-08 14:26:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1168
ERROR - 2023-11-08 07:26:18 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-08 07:27:44 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-08 14:28:39 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 171
ERROR - 2023-11-08 14:28:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 942
ERROR - 2023-11-08 14:28:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 895
ERROR - 2023-11-08 14:28:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1168
ERROR - 2023-11-08 15:45:33 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\laragon\www\jmto-eproc\application\libraries\Role_login.php 21
ERROR - 2023-11-08 15:45:49 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\laragon\www\jmto-eproc\application\libraries\Role_login.php 21
ERROR - 2023-11-08 15:53:20 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 171
ERROR - 2023-11-08 15:53:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 895
ERROR - 2023-11-08 15:53:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 942
ERROR - 2023-11-08 15:53:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1168
ERROR - 2023-11-08 15:53:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 895
ERROR - 2023-11-08 15:53:26 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 171
ERROR - 2023-11-08 15:53:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 942
ERROR - 2023-11-08 15:53:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1168
ERROR - 2023-11-08 15:55:13 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 171
ERROR - 2023-11-08 15:55:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 895
ERROR - 2023-11-08 15:55:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 942
ERROR - 2023-11-08 15:55:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1168
ERROR - 2023-11-08 15:55:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `tbl_vendor_siup`.`sts_seumur_hidup` IN(1, 2)
AND `tbl_vendor_nib`...' at line 15 - Invalid query: SELECT *
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_siup` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_siup`.`id_vendor`
LEFT JOIN `tbl_vendor_nib` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_nib`.`id_vendor`
LEFT JOIN `tbl_vendor_sbu` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_sbu`.`id_vendor`
LEFT JOIN `tbl_vendor_siujk` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_siujk`.`id_vendor`
LEFT JOIN `tbl_vendor_skdp` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_skdp`.`id_vendor`
WHERE `tbl_vendor`.`sts_terundang` = 1
AND `tbl_vendor`.`sts_daftar_hitam` IS NULL
AND `tbl_vendor`.`id_vendor` IS NULL
AND `tbl_vendor`.`id_vendor` IS NULL
AND `tbl_vendor`.`id_vendor` IS NULL
AND `tbl_vendor`.`id_vendor` IS NULL
AND `tbl_vendor`.`id_vendor` IN('54', '57')
AND `tbl_vendor_siup`.`tgl_berlaku` > `IS` `NULL`
AND `tbl_vendor_siup`.`sts_seumur_hidup` IN(1, 2)
AND `tbl_vendor_nib`.`tgl_berlaku` > `IS` `NULL`
AND `tbl_vendor_nib`.`sts_seumur_hidup` IN(1, 2)
AND `tbl_vendor_sbu`.`tgl_berlaku` > `IS` `NULL`
AND `tbl_vendor_sbu`.`sts_seumur_hidup` IN(1, 2)
AND `tbl_vendor_siujk`.`tgl_berlaku` > `IS` `NULL`
AND `tbl_vendor_siujk`.`sts_seumur_hidup` IN(1, 2)
AND `tbl_vendor_skdp`.`tgl_berlaku` > `IS` `NULL`
AND `tbl_vendor_skdp`.`sts_seumur_hidup` IN(1, 2)
ERROR - 2023-11-08 16:03:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 895
ERROR - 2023-11-08 16:03:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 942
ERROR - 2023-11-08 16:03:03 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 171
ERROR - 2023-11-08 16:03:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1168
ERROR - 2023-11-08 16:03:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `tbl_vendor_siup`.`sts_seumur_hidup` IN(1, 2)
AND `tbl_vendor_nib`...' at line 15 - Invalid query: SELECT *
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_siup` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_siup`.`id_vendor`
LEFT JOIN `tbl_vendor_nib` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_nib`.`id_vendor`
LEFT JOIN `tbl_vendor_sbu` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_sbu`.`id_vendor`
LEFT JOIN `tbl_vendor_siujk` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_siujk`.`id_vendor`
LEFT JOIN `tbl_vendor_skdp` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_skdp`.`id_vendor`
WHERE `tbl_vendor`.`sts_terundang` = 1
AND `tbl_vendor`.`sts_daftar_hitam` IS NULL
AND `tbl_vendor`.`id_vendor` IS NULL
AND `tbl_vendor`.`id_vendor` IS NULL
AND `tbl_vendor`.`id_vendor` IS NULL
AND `tbl_vendor`.`id_vendor` IS NULL
AND `tbl_vendor`.`id_vendor` IS NULL
AND `tbl_vendor_siup`.`tgl_berlaku` > `IS` `NULL`
AND `tbl_vendor_siup`.`sts_seumur_hidup` IN(1, 2)
AND `tbl_vendor_nib`.`tgl_berlaku` > `IS` `NULL`
AND `tbl_vendor_nib`.`sts_seumur_hidup` IN(1, 2)
AND `tbl_vendor_sbu`.`tgl_berlaku` > `IS` `NULL`
AND `tbl_vendor_sbu`.`sts_seumur_hidup` IN(1, 2)
AND `tbl_vendor_siujk`.`tgl_berlaku` > `IS` `NULL`
AND `tbl_vendor_siujk`.`sts_seumur_hidup` IN(1, 2)
AND `tbl_vendor_skdp`.`tgl_berlaku` > `IS` `NULL`
AND `tbl_vendor_skdp`.`sts_seumur_hidup` IN(1, 2)
ERROR - 2023-11-08 16:05:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `tbl_vendor_siup`.`sts_seumur_hidup` IN(1, 2)
AND `tbl_vendor_nib`...' at line 15 - Invalid query: SELECT *
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_siup` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_siup`.`id_vendor`
LEFT JOIN `tbl_vendor_nib` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_nib`.`id_vendor`
LEFT JOIN `tbl_vendor_sbu` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_sbu`.`id_vendor`
LEFT JOIN `tbl_vendor_siujk` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_siujk`.`id_vendor`
LEFT JOIN `tbl_vendor_skdp` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_skdp`.`id_vendor`
WHERE `tbl_vendor`.`sts_terundang` = 1
AND `tbl_vendor`.`sts_daftar_hitam` IS NULL
AND `tbl_vendor`.`id_vendor` IS NULL
AND `tbl_vendor`.`id_vendor` IS NULL
AND `tbl_vendor`.`id_vendor` IS NULL
AND `tbl_vendor`.`id_vendor` IS NULL
AND `tbl_vendor`.`id_vendor` IS NULL
AND `tbl_vendor_siup`.`tgl_berlaku` > `IS` `NULL`
AND `tbl_vendor_siup`.`sts_seumur_hidup` IN(1, 2)
AND `tbl_vendor_nib`.`tgl_berlaku` > `IS` `NULL`
AND `tbl_vendor_nib`.`sts_seumur_hidup` IN(1, 2)
AND `tbl_vendor_sbu`.`tgl_berlaku` > `IS` `NULL`
AND `tbl_vendor_sbu`.`sts_seumur_hidup` IN(1, 2)
AND `tbl_vendor_siujk`.`tgl_berlaku` > `IS` `NULL`
AND `tbl_vendor_siujk`.`sts_seumur_hidup` IN(1, 2)
AND `tbl_vendor_skdp`.`tgl_berlaku` > `IS` `NULL`
AND `tbl_vendor_skdp`.`sts_seumur_hidup` IN(1, 2)
ERROR - 2023-11-08 16:07:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 604
ERROR - 2023-11-08 16:07:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 618
ERROR - 2023-11-08 16:07:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 631
ERROR - 2023-11-08 16:07:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 644
ERROR - 2023-11-08 16:07:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 657
ERROR - 2023-11-08 16:07:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\form_daftar_paket.php 814
ERROR - 2023-11-08 16:07:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\form_daftar_paket.php 824
ERROR - 2023-11-08 16:07:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\form_daftar_paket.php 834
ERROR - 2023-11-08 16:07:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\form_daftar_paket.php 844
ERROR - 2023-11-08 16:07:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\form_daftar_paket.php 854
ERROR - 2023-11-08 16:07:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\form_daftar_paket.php 867
ERROR - 2023-11-08 16:07:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\form_daftar_paket.php 881
ERROR - 2023-11-08 16:07:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\form_daftar_paket.php 890
ERROR - 2023-11-08 16:07:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\form_daftar_paket.php 904
ERROR - 2023-11-08 16:07:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\form_daftar_paket.php 913
ERROR - 2023-11-08 16:07:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\form_daftar_paket.php 927
ERROR - 2023-11-08 16:07:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\form_daftar_paket.php 936
ERROR - 2023-11-08 16:07:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\form_daftar_paket.php 950
ERROR - 2023-11-08 16:07:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\form_daftar_paket.php 959
ERROR - 2023-11-08 16:07:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\daftar_paket\form_daftar_paket.php 973
ERROR - 2023-11-08 16:08:29 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 172
ERROR - 2023-11-08 16:08:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 899
ERROR - 2023-11-08 16:08:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 946
ERROR - 2023-11-08 16:08:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1173
ERROR - 2023-11-08 16:10:26 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\laragon\www\jmto-eproc\application\libraries\Role_login.php 21
ERROR - 2023-11-08 16:11:19 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 172
ERROR - 2023-11-08 16:11:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 899
ERROR - 2023-11-08 16:11:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 946
ERROR - 2023-11-08 16:11:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1173
ERROR - 2023-11-08 16:23:35 --> Severity: Notice --> Undefined variable: data C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 329
ERROR - 2023-11-08 16:23:49 --> Severity: Notice --> Undefined variable: data C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 329
ERROR - 2023-11-08 16:23:50 --> Severity: Notice --> Undefined variable: data C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 329
ERROR - 2023-11-08 16:23:50 --> Severity: Notice --> Undefined variable: data C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 329
ERROR - 2023-11-08 16:23:53 --> Severity: Notice --> Undefined variable: data C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 329
ERROR - 2023-11-08 09:35:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-11-08 09:35:31 --> Unable to connect to the database
ERROR - 2023-11-08 09:35:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-11-08 09:35:43 --> Unable to connect to the database
ERROR - 2023-11-08 16:54:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 35
ERROR - 2023-11-08 16:54:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 55
ERROR - 2023-11-08 16:54:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 69
ERROR - 2023-11-08 16:54:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 83
ERROR - 2023-11-08 16:54:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 97
ERROR - 2023-11-08 16:54:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 111
ERROR - 2023-11-08 16:54:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 125
ERROR - 2023-11-08 16:54:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 139
ERROR - 2023-11-08 16:54:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 153
ERROR - 2023-11-08 16:54:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 167
ERROR - 2023-11-08 16:54:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 181
ERROR - 2023-11-08 16:54:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 195
ERROR - 2023-11-08 16:54:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 209
ERROR - 2023-11-08 16:54:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 224
ERROR - 2023-11-08 16:54:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 238
ERROR - 2023-11-08 16:54:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 253
ERROR - 2023-11-08 16:54:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 267
ERROR - 2023-11-08 16:54:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 281
ERROR - 2023-11-08 16:54:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 296
ERROR - 2023-11-08 16:54:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 310
ERROR - 2023-11-08 16:54:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 325
ERROR - 2023-11-08 16:55:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 35
ERROR - 2023-11-08 16:55:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 55
ERROR - 2023-11-08 16:55:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 69
ERROR - 2023-11-08 16:55:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 83
ERROR - 2023-11-08 16:55:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 97
ERROR - 2023-11-08 16:55:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 111
ERROR - 2023-11-08 16:55:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 125
ERROR - 2023-11-08 16:55:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 139
ERROR - 2023-11-08 16:55:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 153
ERROR - 2023-11-08 16:55:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 167
ERROR - 2023-11-08 16:55:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 181
ERROR - 2023-11-08 16:55:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 195
ERROR - 2023-11-08 16:55:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 209
ERROR - 2023-11-08 16:55:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 224
ERROR - 2023-11-08 16:55:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 238
ERROR - 2023-11-08 16:55:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 253
ERROR - 2023-11-08 16:55:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 267
ERROR - 2023-11-08 16:55:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 281
ERROR - 2023-11-08 16:55:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 296
ERROR - 2023-11-08 16:55:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 310
ERROR - 2023-11-08 16:55:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 325
ERROR - 2023-11-08 16:57:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 35
ERROR - 2023-11-08 16:57:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 55
ERROR - 2023-11-08 16:57:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 69
ERROR - 2023-11-08 16:57:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 83
ERROR - 2023-11-08 16:57:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 97
ERROR - 2023-11-08 16:57:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 111
ERROR - 2023-11-08 16:57:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 125
ERROR - 2023-11-08 16:57:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 139
ERROR - 2023-11-08 16:57:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 153
ERROR - 2023-11-08 16:57:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 167
ERROR - 2023-11-08 16:57:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 181
ERROR - 2023-11-08 16:57:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 195
ERROR - 2023-11-08 16:57:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 209
ERROR - 2023-11-08 16:57:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 224
ERROR - 2023-11-08 16:57:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 238
ERROR - 2023-11-08 16:57:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 253
ERROR - 2023-11-08 16:57:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 267
ERROR - 2023-11-08 16:57:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 281
ERROR - 2023-11-08 16:57:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 296
ERROR - 2023-11-08 16:57:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 310
ERROR - 2023-11-08 16:57:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 325
ERROR - 2023-11-08 16:57:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 35
ERROR - 2023-11-08 16:57:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 55
ERROR - 2023-11-08 16:57:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 69
ERROR - 2023-11-08 16:57:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 83
ERROR - 2023-11-08 16:57:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 97
ERROR - 2023-11-08 16:57:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 111
ERROR - 2023-11-08 16:57:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 125
ERROR - 2023-11-08 16:57:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 139
ERROR - 2023-11-08 16:57:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 153
ERROR - 2023-11-08 16:57:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 167
ERROR - 2023-11-08 16:57:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 181
ERROR - 2023-11-08 16:57:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 195
ERROR - 2023-11-08 16:57:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 209
ERROR - 2023-11-08 16:57:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 224
ERROR - 2023-11-08 16:57:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 238
ERROR - 2023-11-08 16:57:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 253
ERROR - 2023-11-08 16:57:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 267
ERROR - 2023-11-08 16:57:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 281
ERROR - 2023-11-08 16:57:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 296
ERROR - 2023-11-08 16:57:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 310
ERROR - 2023-11-08 16:57:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 325
ERROR - 2023-11-08 16:57:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 35
ERROR - 2023-11-08 16:57:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 55
ERROR - 2023-11-08 16:57:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 69
ERROR - 2023-11-08 16:57:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 83
ERROR - 2023-11-08 16:57:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 97
ERROR - 2023-11-08 16:57:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 111
ERROR - 2023-11-08 16:57:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 125
ERROR - 2023-11-08 16:57:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 139
ERROR - 2023-11-08 16:57:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 153
ERROR - 2023-11-08 16:57:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 167
ERROR - 2023-11-08 16:57:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 181
ERROR - 2023-11-08 16:57:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 195
ERROR - 2023-11-08 16:57:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 209
ERROR - 2023-11-08 16:57:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 224
ERROR - 2023-11-08 16:57:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 238
ERROR - 2023-11-08 16:57:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 253
ERROR - 2023-11-08 16:57:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 267
ERROR - 2023-11-08 16:57:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 281
ERROR - 2023-11-08 16:57:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 296
ERROR - 2023-11-08 16:57:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 310
ERROR - 2023-11-08 16:57:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 325
ERROR - 2023-11-08 16:59:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 35
ERROR - 2023-11-08 16:59:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 36
ERROR - 2023-11-08 16:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 35
ERROR - 2023-11-08 16:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 36
ERROR - 2023-11-08 16:59:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 35
ERROR - 2023-11-08 17:06:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 33
ERROR - 2023-11-08 17:09:19 --> Severity: Notice --> Undefined variable: data C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 329
ERROR - 2023-11-08 17:24:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 946
ERROR - 2023-11-08 17:24:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 899
ERROR - 2023-11-08 17:24:32 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 172
ERROR - 2023-11-08 17:24:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1173
ERROR - 2023-11-08 17:24:48 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 172
ERROR - 2023-11-08 17:24:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 899
ERROR - 2023-11-08 17:24:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 946
ERROR - 2023-11-08 17:24:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1173
ERROR - 2023-11-08 10:31:24 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-08 10:32:02 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-08 10:32:34 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-08 10:34:21 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-08 17:50:04 --> 404 Page Not Found: panitia/info_tender/Informasi_tender/simpan_evaluasi_hea_tkdn
ERROR - 2023-11-08 17:50:06 --> 404 Page Not Found: panitia/info_tender/Informasi_tender/simpan_evaluasi_hea_tkdn
ERROR - 2023-11-08 17:50:09 --> 404 Page Not Found: panitia/info_tender/Informasi_tender/simpan_evaluasi_hea_tkdn
ERROR - 2023-11-08 17:50:33 --> 404 Page Not Found: panitia/info_tender/Informasi_tender/simpan_evaluasi_hea_tkdn
ERROR - 2023-11-08 17:51:30 --> 404 Page Not Found: panitia/info_tender/Informasi_tender/simpan_evaluasi_hea_tkdn
ERROR - 2023-11-08 17:54:54 --> 404 Page Not Found: panitia/info_tender/Informasi_tender/simpan_evaluasi_hea_tkdn
ERROR - 2023-11-08 17:58:06 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 608
ERROR - 2023-11-08 17:58:06 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 608
ERROR - 2023-11-08 17:58:06 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 613
ERROR - 2023-11-08 17:58:06 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `ev_akhir_hea_teknis` = '79.50', `ev_akhir_hea_hps` = 0, `ev_akhir_hea_nilai` = NAN
WHERE `id_vendor_mengikuti_paket` = '12'
ERROR - 2023-11-08 17:58:16 --> 404 Page Not Found: panitia/info_tender/Informasi_tender/simpan_evaluasi_hea_tkdn

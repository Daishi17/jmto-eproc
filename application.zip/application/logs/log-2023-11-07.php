<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-07 00:00:17 --> Severity: error --> Exception: Call to undefined method M_panitia::_get_data_query_evaluasi_() C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1170
ERROR - 2023-11-07 00:00:49 --> Severity: error --> Exception: Call to undefined method M_panitia::_get_data_query_evaluasi_() C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1170
ERROR - 2023-11-07 00:33:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-11-07 00:33:12 --> Unable to connect to the database
ERROR - 2023-11-07 00:33:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-11-07 00:33:15 --> Unable to connect to the database
ERROR - 2023-11-07 00:33:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-11-07 00:33:28 --> Unable to connect to the database
ERROR - 2023-11-07 01:43:46 --> Severity: Notice --> Undefined property: stdClass::$ev_akhir_hea_teknis C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 276
ERROR - 2023-11-07 01:43:46 --> Severity: Notice --> Undefined property: stdClass::$ev_akhir_hea_hps C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 282
ERROR - 2023-11-07 01:43:46 --> Severity: Notice --> Undefined property: stdClass::$ev_akhir_hea_nilai C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 288
ERROR - 2023-11-07 01:43:46 --> Severity: Notice --> Undefined property: stdClass::$ev_akhir_hea_akhir C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 294
ERROR - 2023-11-07 01:43:46 --> Severity: Notice --> Undefined property: stdClass::$ev_akhir_hea_peringkat C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 300
ERROR - 2023-11-07 01:43:46 --> Severity: Notice --> Undefined property: stdClass::$ev_akhir_hea_teknis C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 276
ERROR - 2023-11-07 01:43:46 --> Severity: Notice --> Undefined property: stdClass::$ev_akhir_hea_hps C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 282
ERROR - 2023-11-07 01:43:46 --> Severity: Notice --> Undefined property: stdClass::$ev_akhir_hea_nilai C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 288
ERROR - 2023-11-07 01:43:46 --> Severity: Notice --> Undefined property: stdClass::$ev_akhir_hea_akhir C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 294
ERROR - 2023-11-07 01:43:46 --> Severity: Notice --> Undefined property: stdClass::$ev_akhir_hea_peringkat C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 300
ERROR - 2023-11-07 01:43:52 --> Severity: Notice --> Undefined property: stdClass::$ev_akhir_hea_teknis C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 276
ERROR - 2023-11-07 01:43:52 --> Severity: Notice --> Undefined property: stdClass::$ev_akhir_hea_hps C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 282
ERROR - 2023-11-07 01:43:52 --> Severity: Notice --> Undefined property: stdClass::$ev_akhir_hea_nilai C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 288
ERROR - 2023-11-07 01:43:52 --> Severity: Notice --> Undefined property: stdClass::$ev_akhir_hea_akhir C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 294
ERROR - 2023-11-07 01:43:52 --> Severity: Notice --> Undefined property: stdClass::$ev_akhir_hea_peringkat C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 300
ERROR - 2023-11-07 01:43:52 --> Severity: Notice --> Undefined property: stdClass::$ev_akhir_hea_teknis C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 276
ERROR - 2023-11-07 01:43:52 --> Severity: Notice --> Undefined property: stdClass::$ev_akhir_hea_hps C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 282
ERROR - 2023-11-07 01:43:52 --> Severity: Notice --> Undefined property: stdClass::$ev_akhir_hea_nilai C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 288
ERROR - 2023-11-07 01:43:52 --> Severity: Notice --> Undefined property: stdClass::$ev_akhir_hea_akhir C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 294
ERROR - 2023-11-07 01:43:52 --> Severity: Notice --> Undefined property: stdClass::$ev_akhir_hea_peringkat C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 300
ERROR - 2023-11-07 01:48:47 --> Severity: Notice --> Undefined offset: 9 C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1241
ERROR - 2023-11-07 01:48:47 --> Severity: Notice --> Undefined offset: 9 C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1241
ERROR - 2023-11-07 02:05:39 --> Severity: Warning --> Use of undefined constant id_vendor_mengikuti_paket - assumed 'id_vendor_mengikuti_paket' (this will throw an Error in a future version of PHP) C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 547
ERROR - 2023-11-07 02:09:57 --> Severity: Warning --> Illegal string offset 'ev_akhir_hea_teknis' C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 554
ERROR - 2023-11-07 02:09:57 --> Severity: Warning --> Illegal string offset 'ev_akhir_hea_nilai' C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 554
ERROR - 2023-11-07 02:09:57 --> Severity: Warning --> Illegal string offset 'id_vendor_mengikuti_paket' C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 557
ERROR - 2023-11-07 02:11:13 --> Severity: Notice --> Undefined index: ev_akhir_hea_teknis C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 554
ERROR - 2023-11-07 02:11:13 --> Severity: Notice --> Undefined index: ev_akhir_hea_nilai C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 554
ERROR - 2023-11-07 02:11:13 --> Severity: Notice --> Undefined index: id_vendor_mengikuti_paket C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 557
ERROR - 2023-11-07 02:12:30 --> Severity: Notice --> Undefined index: ev_akhir_hea_teknis C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 554
ERROR - 2023-11-07 02:12:30 --> Severity: Notice --> Undefined index: ev_akhir_hea_nilai C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 554
ERROR - 2023-11-07 02:12:30 --> Severity: Notice --> Undefined index: id_vendor_mengikuti_paket C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 557
ERROR - 2023-11-07 02:26:00 --> Severity: Notice --> Undefined index: nilai_teknis C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 303
ERROR - 2023-11-07 02:26:00 --> Severity: Notice --> Undefined index: nilai_teknis C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender.php 303
ERROR - 2023-11-07 02:41:33 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 171
ERROR - 2023-11-07 02:41:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 895
ERROR - 2023-11-07 02:41:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 942
ERROR - 2023-11-07 02:41:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 1168
ERROR - 2023-11-07 18:57:06 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-07 19:57:22 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-07 20:09:09 --> 404 Page Not Found: File_paket/PAKET%20TESTING%20TENDER%20UMUM
ERROR - 2023-11-07 20:41:57 --> 404 Page Not Found: File_paket/Testing%20paket%20terbaru%20(november)
ERROR - 2023-11-07 21:19:40 --> 404 Page Not Found: Assets/img
ERROR - 2023-11-07 21:21:21 --> 404 Page Not Found: Assets/img

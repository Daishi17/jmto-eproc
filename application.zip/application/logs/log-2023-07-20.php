<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-20 03:33:51 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2023-07-20 06:13:59 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-20 07:38:35 --> 404 Page Not Found: Images/bg
